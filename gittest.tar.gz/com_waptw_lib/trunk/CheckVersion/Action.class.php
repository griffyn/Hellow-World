<?php
/**
 * 检查软件更新方法
 * @package keyword
 * @author mayong@ucweb.cn
 *
 */
class Waptw_CheckVersion_Action  
{
	public static function getVersion($argu)
	{
		$pos=intval($argu['pos']);//1：关键词在版本前  -1:关键词在版本后
		$key=$argu['keyWord'];
		$url=$argu['url'];
		$arrVersion=array();
		$start=$pos==1?1:0;
		$content=self::GetSource($url);
		/*
		for($i=0;$i<10;$i++)
		{
			$content=@file_get_contents($url);
			if(!empty($content))
				break;
			elseif ($i==5)
				sleep(1);			
		}
		*/
		if(empty($content))
			return '';
		/*
		$charset=mb_detect_encoding($content,"auto,GBK");
	
		if ($charset!='UTF-8') {
			$content = mb_convert_encoding($content, "UTF-8", $charset);
		}
		*/
		$arrContent= explode($key,$content);
		for($i=$start;$i<count($arrContent);$i++)
		{
			if($pos>0)
				preg_match_all('/([0-9]{1,2}(\.[0-9]+)+)/',substr(trim($arrContent[$i]),0,15), $match);
			else
				preg_match_all('/([0-9]{1,2}(\.[0-9]+)+)/',substr(trim($arrContent[$i]),-15), $match);
			
					
			foreach($match[1] as $key=>$value)
				$arrVersion[]=$value;	
		}
		if(count($arrVersion)==0)
			return '';
		$Maxversion=$arrVersion[0];	
		
		foreach ($arrVersion as $key=>$version)
			$Maxversion=self::MaxVersion($Maxversion,$version);	
		return trim($Maxversion);
	}
	public static function MaxVersion($VersionA,$VersionB)
	{
		$VerSp=explode('.',$VersionA);
		$VerSp2=explode('.',$VersionB);
		for ($i=0;$i<count($VerSp);$i++)
		{
			if(!isset($VerSp2[$i]))
				return $VersionA;
			$verNum=intval($VerSp[$i]);
			$verNum2=intval($VerSp2[$i]);
			if ($verNum2<$verNum)	
			{
				return $VersionA;
				break;
			}
			elseif($verNum2>$verNum && $verNum>0)
			{
				return $VersionB;	
			}			
		}
		return $VersionB;
		
		
	}
	public static function GetSource($url)
	{
		$content="";
		for($i=0;$i<10;$i++)
		{
			$content=@file_get_contents($url);
			if(!empty($content))
				break;
			elseif ($i==5)
				sleep(1);			
		}
		if(empty($content))	
			$content='';

		$charset=mb_detect_encoding($content,"auto,GBK");
		
		if ($charset!='UTF-8') {
			$content = mb_convert_encoding($content, "UTF-8", $charset);
		}
		
		return $content;	
		
	}
	public static function checkVersion()
	{
		$versionList=Waptw_Checkversion_Dao::GetList(0,3000,'error=0','');
		foreach ($versionList as $key=>$version)
		{
			$ver=self::getVersion($version);
			$arg=array();
			$arg['CheckTime']= time();
			if(!empty($ver))//有更新
			{
				$arg['newVersion']=$ver;
				$arg['lastUpdateTime']=time();
			}
			else {//出错了
				$arg['error']=1;
			}
			Waptw_Checkversion_Dao::Edit($arg,$version['idx']);	
			echo "{$version['title']}:";
			echo "Version:".$ver."<br>";
		}
	}
	
}