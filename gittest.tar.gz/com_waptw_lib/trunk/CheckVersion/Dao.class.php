<?php
/**
 * 后台菜单管理
 * 使用方式是，先 Waptw_Checkversion_Dao::Instance()初始化父类的表名和字段属性
 * Waptw_Account_Dao:Add 之类方法
 *
 */
class Waptw_Checkversion_Dao extends Waptw_Abstract_Dao {
	/**
	 * 获取数据库表名字
	 *
	 * @return unknown
	 */
	protected function getTable(){
		return 'checkVersion';
	}
	protected function getField(){
		return 'idx,title,url,pos,keyWord,version,newVersion, error,checkTime,lastUpdateTime,isDel';
	}
	public static function Instance(){
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 保存数据
	 *
	 * @param array $mobileArr
	 * @return unknown
	 */
	public static function Add(Array $Arg)
	{
		return Ucweb_Db_Adapter::factory('com_waptw_down')->T(self::getTable())->UcAdd($Arg);
	}
	
	/**
	 * 编辑
	 *
	 * @param array $Arg
	 * @param unknown_type $id
	 * @return unknown
	 */
	public static function Edit(Array $Arg, $idx)
	{
		return Ucweb_Db_Adapter::factory('com_waptw_down')->where("idx=".$idx)->T(self::getTable())->UcSave($Arg);
	}
	public  static function GetCount()
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		
		if (!empty($where))
			$where = $where . " AND ";
		$where .= "isDel=0";
		
		$db = $db->where($where);
		$result = $db->T(self::getTable())->field("count(*) count")->findAll();
		return $result[0]['count'];
	}
	/**
	 * 获取列表
	 *
	 * @param unknown_type $where
	 * @param unknown_type $order
	 * @return unknown
	 */
	public static function GetList($page=0,$size=10,$where='',$order='idx DESC')
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		if(empty($where))
			$where='isDel=0';
		else 
			$where .=' and isDel=0';
		if ($page!=0 || $size!=0) $db = $db->Page($page)->Size($size);	
		$result=$db->T(self::$_table)->pk("idx")->where($where)->order($order)->findAll();
		return $result;
	}
	
	public static function GetByIdx($idx){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result=$db->T(self::$_table)->pk("idx")->where("idx = $idx")->findAll();
		return $result;
	}
	public static function GetByTitle($title ,$root=0) {
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result=$db->T(self::$_table)->pk("idx")->where("title = '$title'")->findAll();
		return $result;
	}
	
}