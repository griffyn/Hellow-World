<?php
/**
 * 广告类缓存
 * @package ads
 * @author mayong
 *
 */
class Waptw_Ads_Cache {

	static public function GetList($arr,$expire=3600,$cache=true) {
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$arr);
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('waptwadsapi'.$timestamp);
			$url=PROJECT_ADS.'/secret.php?sign='.$sign.'&timestamp='.$timestamp.'&blockid='.$arr['blockid'].'&method='.$arr['method'].'&devplatformid='.$arr['devplatformid'].'&len='.$arr['len'].'&mode='.$arr['mode'].'&row='.$arr['row'].'&format='.$arr['format'];
			//var_dump($url);
			try {
				$opts = array(
				  	'http'=>array(
				    'method'=>"GET",
				    'timeout'=>5,
			 		  )
				);
				$context = stream_context_create($opts);
				$result=unserialize(@file_get_contents($url,false,$context));
				//var_dump($result);
			}
			catch (Exception $e)
			{
			}
			if ($result['rsp']['rsp_error']['code']==1000) {
				$result=$result['rsp']['rsp_data'];
			}
			else {
				$result=array();
			}
			Ucweb_Cache_Adapter::Set($key,$result,$expire);
			return $result;
		}
	}
	
	static public function GetImageList($arr,$expire=3600,$cache=true) {
		
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$arr);
		$result = Ucweb_Cache_Adapter::Get($key);
		
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('waptwadsapi'.$timestamp);
			$url=PROJECT_ADS.'/secret.php?sign='.$sign.'&timestamp='.$timestamp.'&blockid='.$arr['blockid'].'&method='.$arr['method'].'&devplatformid='.$arr['devplatformid'].'&len='.$arr['len'].'&mode='.$arr['mode'].'&row='.$arr['row'].'&format='.$arr['format'];
			//var_dump($url);
			try {
				$opts = array(
				  	'http'=>array(
				    'method'=>"GET",
				    'timeout'=>5,
			 		  )
				);
				$context = stream_context_create($opts);
				$result=unserialize(@file_get_contents($url,false,$context));
			}
			catch (Exception $e)
			{
			}
			if ($result['rsp']['rsp_error']['code']==1000) {
				$result=$result['rsp']['rsp_data'];
				foreach ($result as $k=>$v) {	
					foreach ($v as $k2=>$v2) {
							switch($v2['type']){
//								case 2:
//									$result[$k][$k2]['image']=$v2['image'][0]['image'];
//									break;
//								case 3:
								case 4:
									shuffle($v2['image']);
									
									$result[$k][$k2]['image']=$v2['image'][0]['image'];
									//print_r($result);
									break;
								case 5:		
									//print_r($result);
									foreach ($v2['image'] as $k3=>$v3){
										
										if ($v3['startDate']<time() && $v3['endDate']>time()) {
											$result[$k][$k2]['image']=$v3['image'];
											break;
										}
										else {
											$result[$k][$k2]['image']='';
										}
									}
									break;
							}
					}
				}
			}
			else {
				$result=array();
			}
			Ucweb_Cache_Adapter::Set($key,$result,$expire);
			return $result;
		}
	}
	
	static public function Get($arr,$expire=3600,$cache=true){
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$arr);
		$result = Ucweb_Cache_Adapter::Get($key);
		
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('waptwadsapi'.$timestamp);
			$url=PROJECT_ADS.'/secret.php?sign='.$sign.'&timestamp='.$timestamp.'&method='.$arr['method'].'&adid='.$arr['adid'].'&devplatformid='.$arr['devplatformid'].'&format='.$arr['format'];
			//var_dump($url);
			try {
					$opts = array(
				  	'http'=>array(
				    'method'=>"GET",
				    'timeout'=>5,
			 		  )
					);
				$context = stream_context_create($opts);
				$result=unserialize(@file_get_contents($url,false,$context));
			}
			catch (Exception $e)
			{
			}
			if ($result['rsp']['rsp_error']['code']==1000) {
				$result= $result['rsp']['rsp_data'];
			}
			else{
				$result= array();
			}
		}
		Ucweb_Cache_Adapter::Set($key,$result,$expire);
		return $result;
	}
	
	static public function GetDevPlaformIdsByEid($eid,$expire=3600,$cache=true){
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$eid);
		$result = Ucweb_Cache_Adapter::Get($key);
		
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('UcwebAPImethodMobile_Devplatform_GetIdxeid'.$eid.'timestamp'.$timestamp);
			$url=PROJECT_MOBILE.'/secret.php?method=Mobile_Devplatform_GetIdx&eid='.$eid.'&timestamp='.$timestamp.'&sign='.$sign.'&format=Serialize';
			//var_dump($url);
			try {
					$opts = array(
				  	'http'=>array(
				    'method'=>"GET",
				    'timeout'=>5,
			 		  )
					);
				$context = stream_context_create($opts);
				$result=unserialize(@file_get_contents($url,false,$opts));
			}
			catch (Exception $e)
			{
			}
			if ($result['rsp']['rsp_error']['code']==100000) {
				$result= $result['rsp']['rsp_data']['devPlatFormIds'];
			}
			else{
				$result= '';
			}
		}
		Ucweb_Cache_Adapter::Set($key,$result,$expire);
		return $result;
	}
	
	static public function GetEditionListByDevplatformId($devPlatformId,$expire=3600,$cache=true){
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$eid);
		$result = Ucweb_Cache_Adapter::Get($key);
		
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('UcwebAPImethodMobile_Devplatform_GetBrandEditionidx'.$devPlatformId.'timestamp'.$timestamp);
			$url=PROJECT_MOBILE.'/secret.php?method=Mobile_Devplatform_GetBrandEdition&idx='.$devPlatformId.'&timestamp=
			'.$timestamp.'&sign='.$sign.'&format=Serialize';
			//var_dump($url);
			try {
				$opts = array(
				  	'http'=>array(
				    'method'=>"GET",
				    'timeout'=>5,
			 		  )
					);
				$context = stream_context_create($opts);
			$result=unserialize(@file_get_contents($url,false,$context));
			}
			catch (Exception $e)
			{
			}
			if ($result['rsp']['rsp_error']['code']==100000) {
				$result= $result['rsp']['rsp_data'];
			}
			else{
				$result=array();
			}
		}
		Ucweb_Cache_Adapter::Set($key,$result,$expire);
		return $result;
	}
	
	static public function GetEditionByEid($eid,$expire=3600,$cache=true){
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$eid);
		$result = Ucweb_Cache_Adapter::Get($key);
		
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('UcwebAPImethodMobile_Edition_GetListidx'.$eid.'timestamp'.$timestamp);
			$url=PROJECT_MOBILE.'/secret.php?method=Mobile_Edition_GetList&idx='.$eid.'&timestamp=
			'.$timestamp.'&sign='.$sign.'&format=Serialize';
			try {
				$opts = array(
				  	'http'=>array(
				    'method'=>"GET",
				    'timeout'=>5,
			 		  )
					);
				$context = stream_context_create($opts);
			$result=unserialize(@file_get_contents($url,false,$context));
			}
			catch (Exception $e)
			{
			}
			if ($result['rsp']['rsp_error']['code']==100000) {
				$result=$result['rsp']['rsp_data'];
			}
			else{
				$result=array();
			}
		}
		Ucweb_Cache_Adapter::Set($key,$result,$expire);
		return $result;
	}
}
	