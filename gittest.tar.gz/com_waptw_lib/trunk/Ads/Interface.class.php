<?php
/**
 * 广告接口
 * @package ads
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Ads_Interface 
{	
	public function GetList($arr,$expire=3600,$cache=True){
		$result=Waptw_Ads_Cache::GetList($arr,$expire,$cache);
		if ($arr['mode']==1) {
			shuffle($result);
		}
		return $result;
	}
	
	public function GetImageList($arr,$expire=3600,$cache=True){
		$result=Waptw_Ads_Cache::GetImageList($arr,$expire,$cache);
		if ($arr['mode']==1) {
			shuffle($result);
		}
		return $result;
	}
	
	public function Get($arr,$expire=3600,$cache=True){
		$result=Waptw_Ads_Cache::Get($arr,$expire,$cache);
		return $result;
	}
	
	public function GetDevPlaformIdsByEid($eid,$expire=3600,$cache=true){
		$result=Waptw_Ads_Cache::GetDevPlaformIdsByEid($eid,$expire,$cache);
		return $result;
	}
	
	public function GetEditionListByDevplatformId($devPlatformId,$expire=3600,$cache=true){
		$result=Waptw_Ads_Cache::GetEditionListByDevplatformId($devPlatformId,$expire,$cache);
		return $result;
	}
	
	public function GetEditionByEid($eid,$expire=3600,$cache=true){
		$result=Waptw_Ads_Cache::GetEditionByEid($eid,$expire,$cache);
		return $result;
	}
}