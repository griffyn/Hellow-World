<?php
/**
 * 广告接口
 * @package ads
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Ads_Diaoyan_Interface 
{	
	static public function GetList($arr,$cache=True){
		$result=Waptw_Ads_Diaoyan_Cache::GetList($arr,$cache);
		return $result;
	}
}