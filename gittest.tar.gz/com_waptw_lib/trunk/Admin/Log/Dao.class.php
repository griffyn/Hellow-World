<?php
/**
 * 日志管理类
 * 
 * @ xiexh
 *
 */
class Waptw_Admin_Log_Dao extends Waptw_Abstract_Dao {
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	protected function getTable(){
		return 'log';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	protected function getField() {
		return 'idx,accountId,ip,comments,insertDate,isDel';
	}
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance() {
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	/**
	 * 查询单条信息
	 *
	 * @param int $idx 
	 * @return array
	 */
	static public function GetById($idx){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$r = $db->T(self::$_table)->where("idx=".$idx)->findAll();
		return $r;
	}
}
?>