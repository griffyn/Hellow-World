<?php
/**
 * Enter description here...
 *
 */
class Waptw_Admin_Permissions_Dao extends Waptw_Abstract_Dao
{
    /**
     * 获取表名
     *
     * @return unknown
     */
    private static function getTable()
    {
        return 'permissions';
    }
    
    /**
     * 获取字段名
     *
     * @return unknown
     */
    private static function getField()
    {
        return 'idx,uid,pwd,uright,insertDate,isDel';
    }
    
    public static function Instance()
    {
        parent::$_table = self::getTable();
        parent::$_field = self::getField();
    }
}