<?php
class  Waptw_Admin_Role_Dao extends Waptw_Abstract_Dao {
	/**
	 * 获取数据库表名字
	 *
	 * @return unknown
	 */
	protected function getTable(){
		return 'role';
	}
	
	protected function getField(){
		return 'accountId,permissions';
	}
	
	public static function Instance(){
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
}