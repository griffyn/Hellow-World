<?php
/**
 * 推荐管理类
 * 
 * @ xiexh
 *
 */
class Waptw_Recommend_Dao extends Waptw_Abstract_Dao {
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	protected function getTable(){
		return 'recommend';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	protected function getField() {
		return 'idx,title,url,channelId,page,type,platformId,orderNum,insertDate,isDel';
	}
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance() {
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	/**
	 * 随机获取记录
	 *
	 * @param int $size  要获取记录条数
	 * @param string $where
	 * @return unknown
	 */
	public static function GetRand( $size = 20,$where=''){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$db->T(self::$_table)->pk("idx")->field(self::$_field);
		if ($where) {$db->where($where);}
		$result = $db->size($size)->order('RAND()')->findAll();
		self::$_sqlStr = $db->getLastSql();
		return $result;
	}
	/**
	 * 获取指定idx的信息
	 *
	 * @param int $id
	 * @return array
	 */
	public static function GetById($id){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where('idx='.$id)->findAll();
		return $result;
	}
}
?>