<?php
/**
 * 推荐缓存类
 * 
 * @author：xiexh
 *
 */
class Waptw_Recommend_Cache extends Waptw_Recommend_Dao {
	/**
	 * 随机获取N条记录
	 *
	 * @param $platformId  机型集ID
	 * @param $channelId 获取列表类型（21为软件，22为游戏，23为主题,0为所有） 
	 * @param $page 所在页面（1为首页，2为包页，3为品牌页）
	 * @param $type 推荐类型（1为推荐，2为宝典）
	 * @param $pagesize 每页数量
	 * @param $cache 缓存开关
	 * @return array
	 */
	static public function GetList($platformId,$channelId,$page,$type,$pagesize,$cache=true){
		$key =  Ucweb_Cache_Key::Get(parent::getTable(),array($platformId,$channelId,$page,$type,$pagesize) );
		if ($cache) {
			$r = Ucweb_Cache_Adapter::Get($key);
			if(is_array($r))
				return $r;
		}
		//
		$where .= in_array( $channelId,array(21,22,23) ) ? " and channelId=".$channelId : '';
		$where .= in_array( $page,array(1,2,3) ) ? " and page=".$page : '';
		$where .= in_array( $type,array(1,2) ) ? " and type=".$type : '';
		$where .= (is_array($platformId) && count($platformId) !=0 ) ? " and platformId in (".$platformId .')' :NULL;
		Waptw_Recommend_Dao::Instance();
		$r = Waptw_Recommend_Dao::GetRand($pagesize,'isDel=0'.$where );
		//
		Ucweb_Cache_Adapter::Set($key,$r);
		return $r;
	}
	/**
	 * 获取所有记录
	 *
	 * @param $platformId  机型集ID
	 * @param $channelId 获取列表类型（21为软件，22为游戏，23为主题,0为所有） 
	 * @param $page 所在页面（1为首页，2为包页，3为品牌页）
	 * @param $type 推荐类型（1为推荐，2为宝典）
	 * @param $nowpage 当前页码
	 * @param $pagesize 每页数量
	 * @param $cache 缓存开关
	 * @return array
	 */
	public static function 	GetAllList($platformId,$channelId,$page,$type,$nowpage,$pagesize,$isCount=0,$cache=true){
		$key =  Ucweb_Cache_Key::Get(parent::getTable(),array($platformId,$channelId,$page,$type,$nowpage,$pagesize,$isCount) );
		if ($cache) {
			$r = Ucweb_Cache_Adapter::Get($key);
			if(is_array($r)) return $r;
		}
		$where = '';
		if (!is_array($channelId)) $where .= in_array( $channelId,array(21,22,23) ) ? 'AND channelId in ('.$channelId.')' : '';
		else  $where .=  " AND channelId in (".join(',',$channelId).')';
		$where .= in_array( $page,array(1,2,3) ) ? " AND page=".$page : '';
		$where .= in_array( $type,array(1,2) ) ? " AND type=".$type : '';
		$where .= ($platformId!='') ? " AND platformId in ".$platformId.' ' : '';
		Waptw_Recommend_Dao::Instance();
		if ($isCount) $r = Waptw_Recommend_Dao::Count('isDel=0  '.$where);
		else $r = Waptw_Recommend_Dao::Get($nowpage,$pagesize,'insertDate desc','isDel=0 '.$where);
		Ucweb_Cache_Adapter::Set($key,$r);
		return $r;
	}
	/**
	 * 指定id获取其url  
	 *
	 * @param unknown_type $id
	 * @param unknown_type $cache
	 * @return unknown
	 */
	public static function GetUrlById($id,$cache=true){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($id) );
		if ($cache) {
			$r = Ucweb_Cache_Adapter::Get($key);
			if(is_array($r))
				return $r;
		}
		$r_array = Waptw_Recommend_Dao::GetById($id);
		//var_dump($r_array);
		$r = $r_array[0]['url'];
		Ucweb_Cache_Adapter::Set($key,$r);
		return $r;
	}
	
	public static function GetById($id,$cache=true){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($id) );
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))) {
			return $result;
		}
		$result = Waptw_Recommend_Dao::GetById($id);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
}

?>