<?php
/**
 * 友情链接缓存类
 * @author yuwei
 */
class Waptw_FriendLink_Cache{
	/**
	 * 通过机型集来获取数据
	 *
	 * @param unknown_type $platformId
	 * @param unknown_type $flg
	 * @return unknown
	 */
	static public function GetByLinkType($linkType,$flg=true,$order = 'idx')
	{
		//$key = "Waptw_FriendLink_Cache_GetByLinkType".$linkType;
		$key = Ucweb_Cache_Key::Get('friendLink',array($linkType,$flg));
		if($flg && Ucweb_Cache_Adapter::Get($key))
		{
			return Ucweb_Cache_Adapter::Get($key);
		}
		
		$result = Waptw_FriendLink_Dao::GetByLinkType($linkType,$order);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 通过ID来获取数据
	 *
	 * @param unknown $idx
	 * @return unknown
	 */
	static public function GetByIdx($idx,$flg=true)
	{
		//$key = "Waptw_FriendLink_Cache_GetByIdx".$idx;
		$key = Ucweb_Cache_Key::Get('friendLink',array($idx,$flg));
		if($flg && Ucweb_Cache_Adapter::Get($key))
		{
			return Ucweb_Cache_Adapter::Get($key);
		}
		
		$result = Waptw_FriendLink_Dao::GetById($idx);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	public static function GetCountByType($type,$cache=TRUE){
		//$key = 'featured_count_GetCountByType_'.$type;
		$key = Ucweb_Cache_Key::Get('friendLink',array($type,$cache));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && $result) {return $result;}
		Waptw_FriendLink_Dao::Instance();
		$result = Waptw_FriendLink_Dao::GetCount($type,'');
		Ucweb_Cache_Adapter::Get($key,$result);
		return $result;
	}
	
	/**
	 * 通过链接类型来获取分页
	 *
	 * @param unknown_type $type
	 * @param unknown_type $flg
	 * @return unknown
	 */
	static public function GetPageList($type,$page,$size,$cache=true)
	{
		//$key = "friendlink_type_".$type."_page_".$page."_".$size;
		$key = Ucweb_Cache_Key::Get('friendLink',array($type,$page,$size,$cache));
		if($cache) {
			if ( is_array($result = Ucweb_Cache_Adapter::Get($key)) ){
			return $result;
			}
		}
		
		$result = Waptw_FriendLink_Dao::GetLimitListByType($type,$page,$size);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update('friendLink');
	}
}
