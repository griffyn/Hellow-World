<?php
/**
 * 友情链接类
 * @package friendLink
 * @author thetwo@yahoo.cn
 *
 */
class Waptw_FriendLink_Dao extends Waptw_Abstract_Dao {
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	protected function getTable(){
		return 'friendLink';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	protected function getField() {
		return 'idx,title,url,orderNum,linkType,isDel,insertDate';
	}
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance() {
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 获取逻辑删除字段名
	 *
	 * @return string
	 */
	private static function getDelField() {
		return 'isDel';
	}
	

	/**
	 * 按链接类型取得列表
	 *
	 */
	public static function GetByLinkType($linkType,$order = 'idx') {
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');	
		return $result=$db->T(self::getTable())->pk("idx")->where('linkType = '.$linkType.' and '.self::getDelField().'=0')->order($order)->findAll();
	}
	
	/**
	 * 取得总条数
	 *
	 * @return int
	 */
	public static function GetListPageCount($where) {
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		if (!empty($where))
			$db = $db->where($where);
		$result = $db->T(self::getTable())->field("count(*) count")->findAll();
		return $result[0]['count'];
	}
	
	/**
	 * 根据ID获取内容
	 *
	 * @param int $id
	 * @return Array
	 */
	public static function GetById($id) {
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where("idx=".$id)->findAll();
		return $result;
	}
	
	/**
	 * 内容逻辑删除
	 *
	 * @param int $id
	 */
	public static function LogicDel($id) {
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$delArr = $db->T(self::getTable())->where("idx=".$id)->findAll();
		$delArr[self::getDelField()] = 1;
		parent::Edit($id,$delArr);
	}
	
	/**
	 * 获取数据总数（没有删除滴）
	 *
	 * @return unknown
	 */
	static public function  GetCount($type,$where)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->field('count(idx) as id')->where(' linkType = '.$type.' AND isDel = 0 '.$where)->findAll();
		return $result[0]['id'];
	}
	
	static public function GetLimitListByType($type,$page,$size)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where("linkType = ".$type." AND isDel = 0 ")->order('orderNum desc')->page($page)->size($size)->findAll();
		return $result;
	}
}
?>