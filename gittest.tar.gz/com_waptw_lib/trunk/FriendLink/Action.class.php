<?php
class Waptw_FriendLink_Action  
{
	static public function Get ($order = 'idx',$flg=true) {
		return Waptw_FriendLink_Cache::GetByLinkType(35,$flg,$order);
	}
	
	static public function GetByIdx ($idx = 0) {
		return Waptw_FriendLink_Cache::GetByIdx($idx);
	}
}
