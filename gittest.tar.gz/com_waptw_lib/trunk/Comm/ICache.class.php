<?php
interface Waptw_Comm_ICache{
	
	/**
	 * 添加数据
	 *
	 * @param array $option
	 * 返回新增行的idx
	 */
	public static function Add(array $option);
	
	/**
	 * 删除数据行
	 *
	 * @param int $idx 只能是一个idx
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Del($idx);
	
	/**
	 * 修改数据
	 *
	 * @param int $idx 单个idx
	 * @param array $option 修改的数据
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Edit($idx ,array $option);
	
	/**
	 * 获取数据总行数
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Count($where='');
	
	/**
	 * 根据翻页页面获取数据
	 *
	 * @param int $page 页码，默认是第一页，不可为0
	 * @param int $size 每页的大小。默认是20条。不可小于1
	 * 返回数组
	 */
	public static function Get($page = 1 ,$size = 20 ,$order = 'idx desc' ,$where='');
}