<?php
abstract class Waptw_Comm_Model{
	public function __get($name){
		return $this->$name;
	}
	
	public function __set($name,$value){
		return $this->$name = $value;
	}
}