<?php
/**
 * 机型接口类缓存
 * @package Edition
 * @author mayong
 * @copyright uc.cn
 * @version 1.2.6
 *
 */

class Waptw_Edition_Cache {
    /**
     * 根据机型id获取机型己id集合
     * @param int $eid
     * @param boolean $cache
     * @return array
     */
    static public function GetDevPlaformIdsByEid($eid, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($eid) );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('eid'=>$eid);
            $a_result = Waptw_Edition_Dao::getResult('Mobile_Devplatform_GetIdx',$target);
            $result = $a_result['devPlatFormIds'];
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 根据约束条件获取机型集
     *
     * @author wangjun
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    static public function GetDevPlaformByCond(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Devplatform_GetList',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 按照约束获取操作系统
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    static public function getOs($target,$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Os_getOs',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 根据机型集获取机型信息
     * @param int $devPlatformId
     * @param boolean $cache
     * @return array
     */
    static public function GetEditionListByDevplatformId($devPlatformId, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($devPlatformId) );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$devPlatformId);
            $result = Waptw_Edition_Dao::getResult('Mobile_Devplatform_GetBrandEdition',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 根据机型id获取机型信息
     * @param int $eid
     * @param boolean $cache
     * @return array
     */
    static public function GetEditionByEid($eid, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($eid) );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$eid);
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_GetList',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 获取机型集字符串
     *
     * @param int $eid
     * @param boolean $cache
     * @return string $result
     * @see wangjun
     */
    static public function GetStrPf($eid, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($eid) );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('eid'=>$eid);
            $result = Waptw_Edition_Dao::getResult('Mobile_Devplatform_GetStrPf',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 获取品牌机型缩写列表
     *
     * @param int $idx
     * @param boolean $cache
     * @return string $result
     * @see wangjun
     */
    static public function getShortListByBrand($idx, $keyword = '', $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx) );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx,'key'=>$keyword);
            $result = Waptw_Edition_Dao::getResult('Mobile_Brand_getShortListByBrand',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 获取品牌列表
     *
     * @param int $idx
     * @param boolean $cache
     * @return string $result
     * @see wangjun
     */
    static public function GetBrandById($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx) );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Edition_Dao::getResult('Mobile_Brand_GetById',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 按条件获取机型列表
     *
     * @param string $where
     * @param boolean $cache
     * @param int $page
     * @param int $size
     * @param string $order
     * @return string $result
     * @see wangjun
     */
    static public function GetEditionbyCondition(array $target = array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $timestamp = time ();
            $sTarget = urlencode ( serialize ( $target ) );
            $sign = md5 ( 'UcwebAPImethodMobile_Edition_GetbyConditiontimestamp' . $timestamp );
            $url = PROJECT_MOBILE . '/secret.php?method=Mobile_Edition_GetbyCondition&target=' . $sTarget . '&timestamp=' . $timestamp . '&sign=' . $sign . '&format=Serialize';
            $result = file_get_contents ( $url );
            $result = unserialize ( $result );
            if (! isset ( $result ['rsp'] )) {
                $result ['rsp'] = $result;
            }
            if ($result ['rsp'] ['rsp_error'] ['code'] == 100000) {
                $result = $result ['rsp'] ['rsp_data'];
            } else {
                $result = array ();
            }
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 按条件获取机型数量
     *
     * @param string $where
     * @param boolean $cache
     * @return string $result
     * @see wangjun
     */
    static public function GetEditionCountbyCondition(array $target = array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $timestamp = time ();
            $sTarget = urlencode ( serialize ( $target ) );
            $sign = md5 ( 'UcwebAPImethodMobile_Edition_GetCounttimestamp' . $timestamp );
            $url = PROJECT_MOBILE . '/secret.php?method=Mobile_Edition_GetCount&target=' . $sTarget . '&timestamp=' . $timestamp . '&sign=' . $sign . '&format=Serialize';
            $result = file_get_contents ( $url );
            $result = unserialize ( $result );
            if (! isset ( $result ['rsp'] )) {
                $result ['rsp'] = $result;
            }
            if ($result ['rsp'] ['rsp_error'] ['code'] == 100000) {
                $result = $result ['rsp'] ['rsp_data'] [0] ['count'];
            } else {
                $result = array ();
            }
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 按条件获取品牌列表
     *
     * @param string $where
     * @param boolean $cache
     * @param int $page
     * @param int $size
     * @param string $order
     * @return string $result
     * @see wangjun
     */
	static public function GetBrandbyCondition(array $target = array()) {
		$key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
		$result = Ucweb_Cache_Adapter::Get ( $key );
		if ($cache && is_array($result) && count($result)) {
			return $result;
		} else {
			$timestamp = time ();
			$sTarget = urlencode ( serialize ( $target ) );
			$sign = md5 ( 'UcwebAPImethodMobile_Brand_GetListtimestamp' . $timestamp );
			$url = PROJECT_MOBILE . '/secret.php?method=Mobile_Brand_GetList&target=' . $sTarget . '&timestamp=' . $timestamp . '&sign=' . $sign . '&format=Serialize';
			$result = file_get_contents ( $url );
			$result = unserialize ( $result );
			if (! isset ( $result ['rsp'] )) {
				$result ['rsp'] = $result;
			}
			if ($result ['rsp'] ['rsp_error'] ['code'] == 100000) {
				$result = $result ['rsp'] ['rsp_data'];
			} else {
				$result = array ();
			}
		}
		Ucweb_Cache_Adapter::Set ( $key, $result );
		return $result;
	}
    /**
     * 按条件获取机型列表
     *
     * @param array $target
     * @see wangjun
     */
    static public function getEdition(array $target = array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_GetList',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 获取机型列表
     *
     * @param array $target
     * @see wangjun
     */
    static public function getEditionByCond(array $target = array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_GetList', $target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 获取约束条件机型数量
     *
     * @param array $target
     * @see wangjun
     */
    static public function getEditionCountByCond(array $target = array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_GetCount',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     *
     * 根据品牌id集合获取品牌信息
     * @author wangjun
     * @param string $ids
     * @return array $result
     */
    static public function getBrandByIds($ids, $order = 'orderNum desc,title desc',$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($ids,$order) );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('ids'=>$ids);
            $result = Waptw_Edition_Dao::getResult('Mobile_Brand_GetByIds',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 按条件获取机型数量
     *
     * @param string $where
     * @param boolean $cache
     * @return string $result
     * @see wangjun
     */
    static public function GetBrandCountbyCondition(array $target = array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $timestamp = time ();
            $sTarget = urlencode ( serialize ( $target ) );
            $sign = md5 ( 'UcwebAPImethodMobile_Brand_GetCounttimestamp' . $timestamp );
            $url = PROJECT_MOBILE . '/secret.php?method=Mobile_Brand_GetCount&target=' . $sTarget . '&timestamp=' . $timestamp . '&sign=' . $sign . '&format=Serialize';
            $result = file_get_contents ( $url );
            $result = unserialize ( $result );
            if (! isset ( $result ['rsp'] )) {
                $result ['rsp'] = $result;
            }
            if ($result ['rsp'] ['rsp_error'] ['code'] == 100000) {
                $result = $result ['rsp'] ['rsp_data'] [0] ['count'];
            } else {
                $result = array ();
            }
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 根据ua获取机型eid
     *
     * @param string $where
     * @param boolean $cache
     * @return string $result
     * @see fuqiang
     */
    static public function GetEidbyUa($target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
        	if($target['ua']){
        		$target['title'] = $target['ua'];
        	}
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_Ua_GetByTitle',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 根据品牌名和机型名获取机型信息
     * @param string $s_brandTitle
     * @param string $s_editionTitle
     * @param boolean $cache
     * @return array $result
     */
    static public function getEditionByBrandEdition($brandTitle,$editionTitle,$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($brandTitle,$editionTitle) );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('title'=>$editionTitle,'brandTitle'=>$brandTitle);
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_getEditionByBrandEdition',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 按照约束获取机型图片
     * @param array $target
     * @param boolean $cache
     * @return array
     */
    static public function getEditionPic(array $target=array(),$cache=true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($target) );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Edition_getPic',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    /**
     * 
     * ua适配缓存
     * @param array $target
     * @param boolean $cache
     * @return string $result
     */
    static public function UaMatcher(array $target=array(),$cache=true){
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($target) );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_UaMatcher_getEdition',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;    	
    }
    /**
     * 
     * 判断是否kjava
     * @param array $target
     * @param array $cache
     */
    public function GetKjavaCount(array $target = array(),$cache=true){
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($target) );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Devplatform_GetKJavaCount',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result; 
    } 
    /**
     * 
     * 获取推荐机型
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    static public function GetCommendMobile(array $target=array(),$cache=true){
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($target) );
        $result = Ucweb_Cache_Adapter::Get ( $key );
        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Edition_Dao::getResult('Mobile_Commend_getList',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;    	
    }       
}
?>