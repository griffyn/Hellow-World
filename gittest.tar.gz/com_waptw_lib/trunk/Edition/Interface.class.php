<?php
/**
 * 广告接口
 * @package Edition
 * @author mayong
 * @copyright uc.cn
 *
 */
class Waptw_Edition_Interface {
    public function GetDevPlaformIdsByEid($eid, $cache = true) {
        $result = Waptw_Edition_Cache::GetDevPlaformIdsByEid ( $eid, $cache );
        return $result;
    }
    /**
     * 根据约束条件获取机型集
     *
     * @author wangjun
     * @param array $target
     * @param unknown_type $cache
     * @return array $result
     */
    public function GetDevPlaformByCond(array $target, $cache = true) {
        $result = Waptw_Edition_Cache::GetDevPlaformByCond ( $target, $cache );
        return $result;
    }
    public function GetEditionListByDevplatformId($devPlatformId, $cache = true) {
        $result = Waptw_Edition_Cache::GetEditionListByDevplatformId ( $devPlatformId, $cache );
        return $result;
    }

    public function GetEditionByEid($eid, $cache = true) {
        $result = Waptw_Edition_Cache::GetEditionByEid ( $eid, $cache=true );
        return $result;
    }

    public function GetStrPf($eid, $cache = true) {
        $result = Waptw_Edition_Cache::GetStrPf ( $eid, $cache=true );
        return $result;
    }
    public function getShortListByBrand($idx, $keyword = '', $cache = true) {
        $result = Waptw_Edition_Cache::getShortListByBrand ( $idx, $keyword, $cache );
        return $result;
    }
    public function GetBrandCountbyCondition(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::GetBrandCountbyCondition ( $target );
        return $result;
    }
    public function GetBrandbyCondition(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::GetBrandbyCondition ( $target,$cache );
        return $result;
    }
    /**
     *
     * 按条件获取机型列表
     * @author wangjun
     * @param array $target
     * @return array $result
     */
    public function getEdition(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::getEdition ( $target,$cache );
        return $result;
    }
    /**
     *
     * 获取约束条件机型列表
     * @author wangjun
     * @param array $target
     * @return array $result
     */
    public function getEditionByCond(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::getEditionByCond ( $target,$cache );
        return $result;
    }
    /**
     *
     * 获取约束条件机型数量
     * @author wangjun
     * @param array $target
     * @return array $result
     */
    public function getEditionCountByCond(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::getEditionCountByCond ( $target,$cache );
        return $result;
    }
    /**
     *
     * 根据品牌id集合获取品牌信息
     * @author wangjun
     * @param string $ids
     * @return array $result
     */
    public function getBrandByIds($ids = 0,$order='orderNum desc,title desc',$cache=true) {
        $result = Waptw_Edition_Cache::getBrandByIds ( $ids,$order,$cache );
        return $result;
    }
    /**
     * 根据品牌名和机型名获取机型信息
     * @param string $s_brandTitle
     * @param string $s_editionTitle
     * @param boolean $cache
     * @return array $result
     */
    public function getEditionByBrandEdition($s_brandTitle,$s_editionTitle,$cache=true) {
        $result = Waptw_Edition_Cache::getEditionByBrandEdition ( $s_brandTitle,$s_editionTitle, $cache );
        return $result;
    }
    /**
     * 按照约束获取机型图片
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    public function getEditionPic(array $target,$cache=true) {
        $result = Waptw_Edition_Cache::getEditionPic ($target, $cache );
        return $result;
    }
    /**
     * 按照约束获取操作系统
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    public function getOs(array $target,$cache=true){
        $result = Waptw_Edition_Cache::getOs ($target, $cache );
        return $result;
    }
    public function GetBrandById($idx, $cache = true) {
        $result = Waptw_Edition_Cache::GetBrandById ( $idx, $cache );
        return $result;
    }
    public function GetEditionbyCondition(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::GetEditionbyCondition ( $target,$cache );
        return $result;
    }
    public function GetEditionCountbyCondition(array $target = array(),$cache=true) {
        $result = Waptw_Edition_Cache::GetEditionCountbyCondition ( $target ,$cache);
        return $result;
    }
    public function GetEidbyUa($ua, $cache = true) {
        $result = Waptw_Edition_Cache::GetEidbyUa ( $ua, $cache = true );
        return $result;
    }
    /**
     * 
     * ua适配接口
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    public function UaMatcher(array $target = array(),$cache = true){
    	$result = Waptw_Edition_Cache::UaMatcher($target,$cache);
    	return $result;
    }
    /**
     * 
     * 判断是否kjava
     * @param array $target
     * @param boolean $cache
     * @return array $result
     */
    public function GetKjavaCount(array $target = array(),$cache=true){
    	$result = Waptw_Edition_Cache::GetKjavaCount($target,$cache);
    	return $result;
    }
	/**
	 * 
	 * 获取推荐机型
	 * @param array $target
	 * @param array $cache
     * @return array $result
	 */
    public function GetCommendMobile(array $target = array(),$cache=true){
    	$result = Waptw_Edition_Cache::GetCommendMobile($target,$cache);
    	return $result;    	
    }
}