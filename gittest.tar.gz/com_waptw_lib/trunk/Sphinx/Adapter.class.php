<?php
/**
 * Sphinx类
 * @author mayong
 * @copyright uc
 */

class Waptw_Sphinx_Adapter{
	private $a_Config = array();
	private $o_Sphinx ;
	
	public function __construct($option = array()) {
		$this->a_Config =$this->getConfig($option['index']);
		if (!is_array($this->a_Config)) { return false; exit;}
		$this->o_Sphinx = new Waptw_Sphinx_Client();
		if ($this->a_Config['host'] && $this->a_Config['port'] ) {
			$this->o_Sphinx->SetServer($this->a_Config['host'], intval($this->a_Config['port']));
		}
		if (intval($this->a_Config['timeout'])) { $this->o_Sphinx->SetConnectTimeout(intval($this->a_Config['timeout']));}
		if ($this->a_Config['mode']) {$this->o_Sphinx->SetMatchMode($this->a_Config['mode']);}
		if(key_exists('sort', $option)){$this->o_Sphinx->SetSortMode(SPH_SORT_EXTENDED,$option['sort']);}
		if(key_exists('filter', $option)){foreach ($option['filter'] as $k=>$v){$this->o_Sphinx->SetFilter($k,$v);}}
		if(key_exists('page', $option) && key_exists('size', $option) && intval($option['page'])>=1 && 
			intval($option['size'])>=1){
			$this->o_Sphinx->SetLimits(($option['page']-1)*$option['size'], $option['size']);
		}
		else{
			$this->o_Sphinx->SetLimits((intval($this->a_Config['page'])-1)*intval($this->a_Config['size']),intval($this->a_Config['size']));
		}
	}
	
	/**
	 * 
	 * 获取sphinx到配置文件
	 * @index string $index
	 */
	private function getConfig($index = 'default'){
		$s_Path = CONFIG_PATH . '/' . CONFIG_TYPE. '/' .'sphinx.conf';
		if (!file_exists($s_Path)) {return false; exit;}
		$s_XmlFile = Ucweb_File_Reader::Get($s_Path);
		$o_XmlParse = new Ucweb_Xml_Reader($s_XmlFile);
		$o_xmlResult = $o_XmlParse->GetValueByPath('/config/');
		if (FALSE == $o_xmlResult) { return false; exit;}
		$a_SphinxConfig = Ucweb_Xml_Transform::ToArray($o_xmlResult);
		if (!key_exists($index, $a_SphinxConfig)) {return false; exit;}	
		return $a_SphinxConfig[$index];
	}
	
	/**
	 * 
	 * 根据关键字查询
	 * @param unknown_type $query
	 */
	public function Query($query=''){
		$a_Result =  $this->o_Sphinx->Query ( $query, $this->a_Config['index']);
		if ($a_Result['matches']) {
			$a_Ids = array_keys($a_Result['matches']);
			$a_Match['result'] = $a_Ids;
			$a_Match['count'] = $a_Result['total'];
		}
		else{
			$a_Match['result'] = array();
			$a_Match['count'] = 0;
		}
		
		return $a_Match;
	}
}