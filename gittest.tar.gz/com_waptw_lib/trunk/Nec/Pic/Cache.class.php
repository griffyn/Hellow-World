<?php
/**
 * 必备软件图片缓存类
 * @package necPic
 * @author mayong@ucweb.com
 *
 */
class Waptw_Nec_Pic_Cache  
{
	/**
	 * 获取必备图片缓存
	 * 
	 * @param 必备编号 varchar $id
	 * @return 必备详细信息 array 
	 */
	public static function Get($id)
	{
		$key = Ucweb_Cache_Key::Get('nec_pic',$id);
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	
	/**
	 * 更新必备图片缓存
	 */
	public static function Update()
	{
		Ucweb_Cache_Key::Update('nec_pic');
	}
}