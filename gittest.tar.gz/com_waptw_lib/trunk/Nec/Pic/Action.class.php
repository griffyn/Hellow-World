<?php
/**
 * 必备软件图片方法类
 * @package necPic
 * @author mayong@ucweb.com
 *
 */
class Waptw_Nec_Pic_Action
{
	/**
	 * 获取必备图片
	 * @param 必备编号 id int $id
	 */
	public static function Get($id,$cache=TRUE) 
	{
		$result=Waptw_Nec_Pic_Cache::Get($id);
		if ($cache && $result) 
		{
			return $result;
		}
		
		$option=Waptw_Nec_Pic_Dao::GetListBynecId($id);
		$key = Ucweb_Cache_Key::Get('nec_pic',$id);
		Ucweb_Cache_Adapter::Set($key,$option);	
		return $option;
	}
}