<?php
/**
 * 必备图片类
 * @package nec_pic
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Nec_Pic_Dao  extends Waptw_Nec_Abstract_Dao  
{
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	private static function getTable()
	{
		return 'necPic';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	private static function getField()
	{
		return 'idx,necId,logo,img,skyLogo,isDel,insertDate';
	}
	
	/**
	 * 获取逻辑删除条件
	 *
	 * @return string
	 */
	public static function getDelField()
	{
		return ' isDel=0 ';
	}
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 根据主键返回记录
	 * 
	 * @param int $idx
	 * @return array
	 */
	public static function GetById($idx)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_soft');
		$result = $db->T(self::getTable())->pk("idx")->getbyidx($idx);
		return $result;
	}
	
	/**
	 * 记录逻辑删除
	 *
	 * @param int $id
	 * @return 成功返回TRUE,否者返回FALSE
	 */
	public static function LogicDel($idx)
	{
		return parent::Edit($idx,array('isDel'=>1));
	}
	
	static public function GetListBynecId($necId)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_soft');
		$result=$db->T(self::getTable())->pk("idx")->where("necId=".$necId." and ".self::getDelField())->findAll();
		return $result;
	}
	
	/**
	 * 重写修改函数
	 *
	 */
	public static function Edit($idx ,array $option){
		unset($option['idx']);
		$db = Ucweb_Db_Adapter::factory('com_waptw_soft');
		$result = $db->T(self::$_table)->where("necId=".$idx)->UcSave($option);
		return $result;
	}
	
}