<?php
/**
 * 必备分类方法类
 * @package necCol
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Nec_Col_Action  
{
	/**
	 * 获取必备分类列表
	 */
	public static function GetListByMix($option1,$option2)
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$tmp[$val['idx']] = $val['title'];
		}
		
		foreach ($option1 as $key => $val) {
			$option1[$key]['osTitle'] = $tmp[$val['osId']];
		}
		return $option1;
	}
}