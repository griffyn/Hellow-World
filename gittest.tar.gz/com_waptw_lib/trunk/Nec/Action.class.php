<?php
/**
 * 必备方法类类
 * @package nec
 * @author mayong@ucweb.com
 *
 */
class Waptw_Nec_Action  
{
	/**
	 * 根据机条件获取必备列表
	 *
	 * @param 平台 $os
	 * @param 关键字 $k
	 * @param 必备分类 $colId
	 * @param 必备类型 $type
	 * @return 必备列表 $option
	 */
	public static function GetListByType($os,$k,$colId,$type)
	{
		$where=$where.($type==2)?' osId='.$os.' and type=2 ':' osId='.$os.' and (type=1 or type=0) ';
		$where=$where.(($colId<>0)?'  and colId='.$colId.' ':'');
		$where=$where.(($k<>'')?' and title like \'%'.$k.'%\' ':'');
		$where=$where.' and isDel=0';
		Waptw_Nec_Dao::Instance();
		$option1=Waptw_Nec_Dao::Get(1,Waptw_Nec_Dao::Count($where),'',$where);		
		Waptw_Nec_Col_Dao::Instance();
		$whereCol='osId='.$os.' and isDel=0';
		$option2=Waptw_Nec_Col_Dao::Get(1,Waptw_Nec_Col_Dao::Count($whereCol),'',$whereCol);
		$option=self::getListByMix($option1,$option2);
		return $option;
	}
	
	/**
	 * 获取必备列表
	 *
	 * @param 必备数组 $option1
	 * @param 必备分类数组 $option2
	 * @return 必备列表 $option1
	 */
	public static function GetListByMix($option1,$option2)
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$tmp[$val['idx']] = $val['title'];
		}
		
		foreach ($option1 as $key => $val) {
			$option1[$key]['colTitle'] = $tmp[$val['colId']];
		}
		return $option1;
	}
	
	/**
	 * 对应机型的周更新软件
	 *
	 * @param 机型 $eid
	 * @param 平台 $osid
	 * @return array
	 */
	public static function GetWeekUpdate($eid = '',$osid,$cache=TRUE) 
	{
		$devPlatform = new Mobile_Devplatform_Action();
		if ($eid) 
		{
			$kjavaCount=1;
			if ($osid==2)
			{
				$kjavaCount=$devPlatform->GetKJavaCount($eid);
			}
			$pid=$devPlatform->GetByEid($eid);
		}
		
		$result=Waptw_Nec_Cache::GetWeek($pid);
		if ($cache && is_array($result)) 
		{
			return $result;
		}	
		$result=Waptw_Nec_Dao::GetByDayDiff(30,$osid);	
		foreach ($result as $v) 
		{
			if($v['url']) 
			{
				$line[]=array(
							'url'=>urlencode($v['url']),
							'title'=>$v['title'],
							'updateTime'=>$v['updateTime'],
							'necid'=>$v['idx'],
				);
			}
			else {
				$packids=$v['packIds'];
				if (!$kjavaCount) 
				{
					//Soft_Pack_Dao::Instance();
					Soft_Pack_Dao::Instance();;
					$softwhere='isDel=0 and platformId=68 and idx in('.$packids.')';
					$softCount=Soft_Pack_Dao::CountEx($softwhere);
					if ($softCount)
					{
						//$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
						$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
						$line[]=array(
								'idx'=>$soft[0]['idx'],
								'fileSize'=>floor($soft[0]['fileSize']/1000),
								'updateTime'=>$v['updateTime'],
								'title'=>$v['title'],
								'necid'=>$v['idx'],
									);
					}
				}
				else 
				{
					
					//$weeknec=Soft_Pack_Dao::GetByPackId($packids , $pid);
					$weeknec=Soft_Pack_Dao::GetByPackId($packids , $pid);
					foreach ($weeknec as $k2=>$v2) 
					{
						if ($v2['appId']==1) 
						{
							$weeknec[0]=$v2;
							break;
						}
					}
					
					if ($weeknec) 
					{
						$line[]=array(
								'idx'=>$weeknec[0]['idx'],
								'fileSize'=>floor($weeknec[0]['fileSize']/1000),
								'updateTime'=>$v['updateTime'],
								'title'=>$v['title'],
								'necid'=>$v['idx'],
									);		
					}
					elseif ($osid==2) 
					{
						Soft_Pack_Dao::Instance();
						$softwhere='isDel=0 and platformId=68 and idx in('.$packids.')';
						$softCount=Soft_Pack_Dao::CountEx($softwhere);
						if ($softCount)
						{
							$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
							$line[]=array(
									'idx'=>$soft[0]['idx'],
									'fileSize'=>floor($soft[0]['fileSize']/1000),
									'updateTime'=>$v['updateTime'],
									'title'=>$v['title'],
									'necid'=>$v['idx'],
										);
						}	
					}	
					//elseif ($osid) 
					//{
					//	Soft_Pack_Dao::Instance();
					//	$softwhere='isDel=0  and idx in('.$packids.')';
					//	$softCount=Soft_Pack_Dao::CountEx($softwhere);
					//	if ($softCount)
					//	{
					//		$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
					//		$line[]=array(
					//				'idx'=>$soft[0]['idx'],
					//				'fileSize'=>floor($soft[0]['fileSize']/1000),
					//				'updateTime'=>$v['updateTime'],
					//				'title'=>$v['title'],
					//				'necid'=>$v['idx'],
					//					);
					//	}	
					//}						
				}
			}
		}
		if ($line) 
		{
			foreach ($line as $k=>$v) 
			{
				$line[$k]['count']=count($line);
			}
		}
		
		$key = Ucweb_Cache_Key::Get('nec',array('week',$pid));
		Ucweb_Cache_Adapter::Set($key,$line);
		return $line;
	}

	/**
	 * 获取所有分类的软件信息
	 *
	 * @param 机型id int $eid
	 * @param 机型系统id int $osid
	 */
	public static function GetColPack($eid,$osid,$cache=TRUE)
	{
		$devPlatform = new Mobile_Devplatform_Action();
		if ($eid) 
		{
			$kjavaCount=1;
			if ($osid==2)
			{
				$kjavaCount=$devPlatform->GetKJavaCount($eid);
			}
			$pid=$devPlatform->GetByEid($eid);
		}
		$result=Waptw_Nec_Cache::GetCommend($pid);
		if ($cache && is_array($result)) 
		{
			return $result;
		}	
		
		$col=Waptw_Nec_Col_Dao::GetCol($osid);//获取所有的分类
		foreach ($col as $k=>$v) 
		{
			$result=Waptw_Nec_Dao::GetByCol($v['idx']);
			$break=0;
			foreach ($result as $vv) 
			{
				if($vv['url']) 
				{
					$line[]=array(
							'url'=>urlencode($vv['url']),
							'title'=>$vv['title'],
							'updateTime'=>$vv['updateTime'],
							'necid'=>$vv['idx'],
						);
						++$break;
				}
				else 
				{
					$packids=$vv['packIds'];
					if (!$kjavaCount) 
					{
						Soft_Pack_Dao::Instance();
						$softwhere='isDel=0 and platformId=68 and idx in('.$packids.')';
						$softCount=Soft_Pack_Dao::CountEx($softwhere);
						if ($softCount) 
						{
							$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
							$line[]=array(
									'idx'=>$soft[0]['idx'],
									'title'=>$vv['title'],
									'necid'=>$vv['idx'],
									'fileSize'=>floor($soft[0]['fileSize']/1000),
									'updateTime'=>$soft['updateTime'],
								);
							++$break;
						}
					}
					else 
					{
						$weeknec=Soft_Pack_Dao::GetByPackId($packids , $pid);
						foreach ($weeknec as $k3=>$v3) 
						{
							if ($v3['appId']==1) 
							{
								$weeknec[0]=$v3;
								break;
							}
						}
						if ($weeknec) 
						{
							$line[]=array(
									'idx'=>$weeknec[0]['idx'],
									'title'=>$vv['title'],
									'necid'=>$vv['idx'],
									'fileSize'=>floor($weeknec[0]['fileSize']/1000),
									'updateTime'=>$vv['updateTime'],
								);
							++$break;
						}
						elseif ($osid==2)
						{
							Soft_Pack_Dao::Instance();
							$softwhere='isDel=0 and platformId=68 and idx in('.$packids.')';
							$softCount=Soft_Pack_Dao::CountEx($softwhere);
							if ($softCount) 
							{
								$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
								$line[]=array(
										'idx'=>$soft[0]['idx'],
										'title'=>$vv['title'],
										'necid'=>$vv['idx'],
										'fileSize'=>floor($soft[0]['fileSize']/1000),
										'updateTime'=>$soft['updateTime'],
									);
								++$break;
							}
						}
					}
			}
			if ($line) 
			{
				$nec[$v['idx']][title]=$v['title'];
				$nec[$v['idx']]['content']=$line;
				$nec[$v['idx']]['count']=$break;
			}
			}
			unset($line);
		}
		$key = Ucweb_Cache_Key::Get('nec',array('commend',$pid));
		Ucweb_Cache_Adapter::Set($key,$nec);
		return $nec;
		
	}
	
	/**
	 * 获取十大必备
	 *
	 * @param 机型编号id int $eid
	 * @param 机型平台id int $osid
	 */
	
	public static function GetMainPack($eid,$osid,$cache=TRUE) {
		$devPlatform = new Mobile_Devplatform_Action();
		if ($eid) 
		{
			$kjavaCount=1;
			if ($osid==2)
			{
				$kjavaCount=$devPlatform->GetKJavaCount($eid);
			}
			$pid=$devPlatform->GetByEid($eid);
		}
		
		$result=Waptw_Nec_Cache::GetMain($pid);
		if ($cache && is_array($result)) 
		{
			return $result;
			exit();
		}
		$result=Waptw_Nec_Dao::GetByMain($osid);
		foreach ($result as $v) {
			$packids=$v['packIds'];
			if (!$kjavaCount) 
			{
				Soft_Pack_Dao::Instance();
				$softwhere='isDel=0 and platformId=68 and idx in('.$packids.')';
				$softCount=Soft_Pack_Dao::CountEx($softwhere);
				if ($softCount)
				{
					$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
					$logo=Waptw_Nec_Pic_Dao::GetListBynecId($v['idx']);
					$line[]=array(
							'title'=>$v['title'],
							'preface'=>$v['preface'],
							'idx'=>$soft[0]['idx'],
							'filePath'=>$soft[0]['filePath'],
							'os'=>$soft[0]['fileSuffix'],
							'updateDate'=>$soft[0]['updateDate'],
							'size'=>floor($soft[0]['fileSize']/1000),
							'necid'=>$v['idx'],
							'logo'=>$logo[0]['logo'],
							'funcsortid'=>$soft[0]['funcSortId'],
							'osId'=>$soft[0]['osId'],
							'updateTime'=>$v['updateTime'],
							);
					++$break;
				}
			}
			else 
			{
				$nec=Soft_Pack_Dao::GetByPackId($packids,$pid);
				if ($nec) 
				{
					$logo=Waptw_Nec_Pic_Dao::GetListBynecId($v['idx']);
					$line[]=array(
							'title'=>$v['title'],
							'preface'=>$v['preface'],
							'idx'=>$nec[0]['idx'],
							'filePath'=>$nec[0]['filePath'],
							'os'=>$nec[0]['fileSuffix'],
							'size'=>floor($nec[0]['fileSize']/1000),
							'necid'=>$v['idx'],
							'logo'=>$logo[0]['logo'],
							'funcsortid'=>$nec[0]['funcSortId'],
							'updateDate'=>$nec[0]['updateDate'],
							'osId'=>$nec[0]['osId'],
							'updateTime'=>$v['updateTime'],
					);
					++$break;
				}
				else
				{
					Soft_Pack_Dao::Instance();
					$op= array('where'=>'isDel=0 and platformId=68 and idx in('.$packids.')');
					//$softwhere='isDel=0 and platformId=68 and idx in('.$packids.')';
					$softCount=Soft_Pack_Dao::_count($op);
					if ($softCount)
					{
						$soft=Soft_Pack_Dao::GetEx(1,1,'',$softwhere);
						$logo=Waptw_Nec_Pic_Dao::GetListBynecId($v['idx']);
						$line[]=array(
						'title'=>$v['title'],
						'preface'=>$v['preface'],
						'idx'=>$soft[0]['idx'],
						'filePath'=>$soft[0]['filePath'],
						'os'=>$soft[0]['fileSuffix'],
						'updateDate'=>$soft[0]['updateDate'],
						'size'=>floor($soft[0]['fileSize']/1000),
						'necid'=>$v['idx'],
						'logo'=>$logo[0]['logo'],
						'funcsortid'=>$soft[0]['funcSortId'],
						'osId'=>$soft[0]['osId'],
						'updateTime'=>$v['updateTime'],
						);
						++$break;
					}
				}
			}
			
			if ($break>=10) break 1;	
		}
		$key = Ucweb_Cache_Key::Get('nec',array('main',$pid));
		Ucweb_Cache_Adapter::Set($key,$line);	
		return $line;
	}
	
	/**
	 * 获取必备详细信息
	 * @param 必备编号 id int $id
	 */
	public static function Get($id,$cache=TRUE) 
	{
		$result=Waptw_Nec_Cache::Get($id);
		if ($cache && is_array($result)) 
		{
			return $result;
			exit();
		}
		
		$option=Waptw_Nec_Dao::GetById($id);
		$key = Ucweb_Cache_Key::Get('nec',array('signal',$id));
		Ucweb_Cache_Adapter::Set($key,$option);	
		return $option;
	}
	
	/**
	 * 获取模板定制分类
	 * @param 必备编号 $os int $id
	 */
	public static function GetTemplateType($os) 
	{
		$option=array(
					'1'=>array(
							'title'=>'symbian',
							'path'=>'',
							'listSize'=>'10',
							'pageBreak'=>'1',
							'image'=>array(
											'path'=>'hottw/images/',
										),
							'css'=>array(
										'style'=>'',
										'info'=>''),
							),
					'2'=>array(
							'title'=>'java',
							'path'=>'',
							'listSize'=>'10',
							'pageBreak'=>'1',
							'image'=>array(
											'path'=>'hottw/images/',
										),
							'css'=>array(
										'style'=>'',
										'info'=>''),
							),
					'3'=>array(
							'title'=>'ppc',
							'path'=>'',
							'listSize'=>'10',
							'pageBreak'=>'1',
							'image'=>array(
											'path'=>'hottw/images/',
										),
							'css'=>array(
										'style'=>'',
										'info'=>''),
							),
					'4'=>array(
							'title'=>'iphone',
							'path'=>'iphone/',
							'listSize'=>'20',
							'pageBreak'=>'2',
							'image'=>array(
											'path'=>'hottw/images/iphone/',
											'commend'=>'hottw/images/iphone/col/commend',
											'func'=>'hottw/images/iphone/col/func',
										),
							'css'=>array(
										'style'=>'hottw/css/iphone/style.css',
										'info'=>'hottw/css/iphone/info.css'),
							),
					'5'=>array(
							'title'=>'android',
							'path'=>'android/',
							'listSize'=>'20',
							'pageBreak'=>'2',
							'image'=>array(
											'path'=>'hottw/images/android/',
											'commend'=>'hottw/images/android/col/commend',
											'func'=>'hottw/images/android/col/func',
										),
							'css'=>array(
										'style'=>'hottw/css/android/style.css',
										'info'=>'hottw/css/android/info.css'),
							),
					'6'=>array(
							'title'=>'wince',
							'path'=>'wince/',
							'listSize'=>'20',
							'pageBreak'=>'2',
							'image'=>array(
											'path'=>'hottw/images/wince/',
											'commend'=>'hottw/images/wince/col/commend',
											'func'=>'hottw/images/wince/col/func',
										),
							'css'=>array(
										'style'=>'hottw/css/wince/style.css',
										'info'=>'hottw/css/wince/info.css'),
							),
					'7'=>array(
							'title'=>'blackberry',
							'path'=>'',
							'listSize'=>'10',
							'pageBreak'=>'1',
							'image'=>array(
											'path'=>'hottw/images/',
										),
							'css'=>array(
										'style'=>'',
										'info'=>''),
							),							
					);
		return $option[$os];
	}
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $os
	 */
	public static function GetPPCType($pfid) 
	{
		$option=array(
					'30'=>array('title'=>'PPC_2003','fullTitle'=>'PPC_2003'),
					'31'=>array('title'=>'PPC_2005','fullTitle'=>'PPC_2005'),
					'32'=>array('title'=>'SP_2003','fullTitle'=>'SP_2003'),
					'33'=>array('title'=>'SP_2005','fullTitle'=>'SP_2005'),
					);
		return $option[$pfid];
	}
}
