<?php
/**
 * 必备常见问题投票方法类
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Nec_Question_Avail_Action  
{
	/**
	 * 获取常见问题投票次数(前台)
	 * 
	 * @param 常见问题编号 int $id
	 * @return 好评次数 int $count
	 */
	public static function Get($id)
	{
		$count=Waptw_Nec_Question_Avail_Cache::Get($id);
		if (!$count) 
		{
			return 0;
		}
		else 
		{
			return $count;
		}
	}
	
	/**
	 * 更新常见问题投票次数(前台)
	 * 
	 * @param 常见问题编号 int $id
	 */
	public static function Set($id)
	{
		Waptw_Nec_Question_Avail_Cache::Set($id);
	}
	
	/**
	 * 获取常见问题浏览次数(前台)
	 * 
	 * @param 常见问题编号 int $id
	 * @return 好评次数 int $count
	 */
	public static function GetScan($id)
	{
		$count=Waptw_Nec_Question_Avail_Cache::GetScan($id);
		if (!$count) 
		{
			return 0;
		}
		else 
		{
			return $count;
		}
	}
	
	
	/**
	 * 更新常见问题浏览次数(前台)
	 * 
	 * @param 常见问题编号 int $id
	 */
	public static function SetScan($id)
	{
		Waptw_Nec_Question_Avail_Cache::SetScan($id);
	}
}