<?php
/**
 * 必备常见问题投票缓存类
 * @author mayong@ucweb.com
 *
 */
class Waptw_Nec_Question_Avail_Cache  
{
	/**
	 * 获取常见问题投票缓存(前台)
	 * 
	 * @param 平台 int $id
	 * @return 次数 int $count 
	 */
	public static function Get($id)
	{
		$key = Ucweb_Cache_Key::Get('necQuestion',array('avail',$id));
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	/**
	 * 更新常见问题投票缓存(前台)
	 * 
	 * @param 平台 int $id
	 */
	public static function Set($id)
	{
		
		$key=Ucweb_Cache_Key::Get('necQuestion',array('avail',$id));
		if (!Ucweb_Cache_Adapter::Get($key))
		{ 
			Ucweb_Cache_Adapter::Set($key,1);
		}
		else
		{
			Ucweb_Cache_Adapter::Inc($key,1);
		}
	}
	
	/**
	 * 获取常见问题浏览次数缓存(前台)
	 * 
	 * @param 平台 int $id
	 * @return 次数 int $count 
	 */
	public static function GetScan($id)
	{
		$key = Ucweb_Cache_Key::Get('necQuestion',array('scan',$id));
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	/**
	 * 更新常见问题浏览次数缓存(前台)
	 * 
	 * @param 平台 int $id
	 */
	public static function SetScan($id)
	{
		
		$key = Ucweb_Cache_Key::Get('necQuestion',array('scan',$id));
		if (!Ucweb_Cache_Adapter::Get($key))
		{ 
			Ucweb_Cache_Adapter::Set($key,1);
		}
		else
		{
			Ucweb_Cache_Adapter::Inc($key,1);
		}
	}
}