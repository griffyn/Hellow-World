<?php
/**
 * 必备常见问题缓存类
 * @package necQuestion
 * @author mayong@ucweb.com
 *
 */
class Waptw_Nec_Question_Cache  
{
	/**
	 * 获取常见问题列表缓存(前台)
	 * 
	 * @param 平台 int $os
	 * @return 平台列表 array 
	 */
	public static function GetList($os)
	{
		$key = Ucweb_Cache_Key::Get('necQuestion',array('list',$os));
		return Ucweb_Cache_Adapter::Get($key);
	
	}
	

	/**
	 * 获取常见问题缓存(前台)
	 * 
	 * @param 问题编号 int $id
	 * @return 问题相信信息 array 
	 */
	public static function Get($id)
	{
		$key = Ucweb_Cache_Key::Get('necQuestion',$id);
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	/**
	 * 更新常见问题缓存(前台)
	 * 
	 */
	public static function Update()
	{
		Ucweb_Cache_Key::Update('necQuestion');
	}
}