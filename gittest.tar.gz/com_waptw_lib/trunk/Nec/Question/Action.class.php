<?php
/**
 * 必备常见问题方法类
 * @package question
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Nec_Question_Action  
{
	/**
	 * 获取常见问题列表(带平台名称)
	 * 
	 * @param 常见问题列表 array $option1
	 * @param 平台列表 array $option2
	 * @return 常见问题列表(带平台名称) array $option1
	 */
	public static function GetListByMix($option1,$option2)
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$tmp[$val['idx']] = $val['title'];
		}
		
		foreach ($option1 as $key => $val) {
			$option1[$key]['osTitle'] = $tmp[$val['osId']];
		}
		return $option1;
	}
	
	/**
	 * 获取常见问题列表(前台)
	 * 
	 * @param 平台 int $os
	 * @return 常见问题列表 array $option
	 */
	public static function GetList($os)
	{
		$result=Waptw_Nec_Question_Cache::GetList($os);
		if (is_array($result)) 
		{
			return $result;
			exit();
		}
		
		$key = Ucweb_Cache_Key::Get('necQuestion',array('list',$os));
		Waptw_Nec_Question_Dao::Instance();
		$where="isDel=0 and osId=".$os;
		$option=Waptw_Nec_Question_Dao::Get(1,Waptw_Nec_Question_Dao::Count($where),'orderNum asc',$where);
		
		Ucweb_Cache_Adapter::Set($key,$option);
		
		return $option;
		
	}

	
	/**
	 * 获取常见问题(前台)
	 * 
	 * @param 常见问题编号 int $id
	 * @param 平台 int $os
	 * @return 常见问题列表 array $option
	 */
	public static function Get($id,$os)
	{
		//$result=Waptw_Nec_Question_Cache::Get($id);
		if (is_array($result)) 
		{
			return $result;
			exit();
		}
		
		$key = Ucweb_Cache_Key::Get('necQuestion',$id);
		$option1=self::GetList($os);
		$option=self::GetInfo($id,$option1);
		Ucweb_Cache_Adapter::Set($key,$option);
		
		return $option;
	}
	
	/**
	 * 获取常见问题详细信息(前台)
	 * 
	 * @param 常见问题编号 int $id
	 * @return 常见问题列表 array $option
	 */
	public static function GetInfo($id,$option)
	{
		$temp=array();
		foreach ($option as $k=>$v) 
		{
			if ($v['idx']==$id) 
			{
				$temp=$v;
				if ($k!=0) 
				{
					$temp['prevId']=$option[$k-1]['idx'];	
					$temp['prevTitle']=$option[$k-1]['title'];	
				}	
				if ($k!=(count($option)-1)) 
				{
					$temp['nextId']=$option[$k+1]['idx'];	
					$temp['nextTitle']=$option[$k+1]['title'];	
				}
				break;
			}	
		}
		return $temp;	
	}
}