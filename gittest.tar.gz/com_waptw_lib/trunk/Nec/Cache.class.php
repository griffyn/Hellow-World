<?php
/**
 * 必备软件缓存类
 * @package nec
 * @author mayong@ucweb.com
 *
 */
class Waptw_Nec_Cache  
{
	/**
	 * 获取一周更新缓存(前台)
	 * 
	 * @param 机型集 varchar $pid
	 * @return 本周更新 array 
	 */
	public static function GetWeek($pid)
	{
		$key = Ucweb_Cache_Key::Get('nec',array('week',$pid));
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	/**
	 * 获取必备缓存(前台)
	 * 
	 * @param 机型集 varchar $pid
	 * @return 必备列表 array 
	 */
	public static function GetCommend($pid)
	{
		$key = Ucweb_Cache_Key::Get('nec',array('commend',$pid));
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	
	/**
	 * 获取十大必备缓存(前台)
	 * 
	 * @param 机型集 varchar $pid
	 * @return 十大必备列表 array 
	 */
	public static function GetMain($pid)
	{
		$key = Ucweb_Cache_Key::Get('nec',array('main',$pid));
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	/**
	 * 获取必备缓存
	 * 
	 * @param 必备编号 varchar $id
	 * @return 必备详细信息 array 
	 */
	public static function Get($id)
	{
		$key = Ucweb_Cache_Key::Get('nec',array('signal',$id));
		return Ucweb_Cache_Adapter::Get($key);
	}
	
	
	/**
	 * 更新必备缓存
	 */
	public static function Update()
	{
		Ucweb_Cache_Key::Update('nec');
	}
}