<?php
/**
 * 必备软件类
 * @package nec
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Nec_Dao  extends Waptw_Nec_Abstract_Dao
{
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	private static function getTable()
	{
		return 'nec';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	private static function getField()
	{
		return 'idx,title,productId,packIds,url,type,osId,colId,colOrderNum,topOrderNum,preface,isDel,insertDate,updateTime';
	}
	
	/**
	 * 获取逻辑删除条件
	 *
	 * @return string
	 */
	public static function getDelField()
	{
		return ' isDel=0 ';
	}
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 根据主键返回记录
	 * 
	 * @param int $idx
	 * @return array
	 */
	public static function GetById($idx)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_soft');
		$result = $db->T(self::getTable())->pk("idx")->getbyidx($idx);
		return $result;
	}
	
	/**
	 * 记录逻辑删除
	 *
	 * @param int $id
	 * @return 成功返回TRUE,否者返回FALSE
	 */
	public static function LogicDel($idx)
	{
		return parent::Edit($idx,array('isDel'=>1));
	}
	
	/**
	 * 返回指定天数内的更新软件包信息
	 *
	 * @param 天数 int $diff
	 * @return array
	 */
	public static function GetByDayDiff($diff = 7,$osid=1) {
		$db = Ucweb_Db_Adapter::factory('com_waptw_soft');
		$result=$db->T(self::getTable())->pk("idx")->where('osId='.$osid.' and datediff(now(),FROM_UNIXTIME(updateTime)) < '. $diff .' and '.self::getDelField() . ' and type=1')->order("updateTime desc")->findAll();
		//echo $db->getLastSql();
		return $result;
	}
	
	/**
	 * 获取分类下的必备软件
	 *
	 * @param 分类编号 int $colid
	 * @return array
	 */
	
	public static function GetByCol($colid) {
		$where=" type=1 and isDel=0 and colId='{$colid}' ";
		self::Instance();
		return parent::Get(1,20,'colOrderNum asc',$where);
	}
		
	public static function GetByMain($osid) {
		$where="type=2 and osId='{$osid}' and isDel=0 ";
		self::Instance();
		return parent::Get(1,50,'topOrderNum asc',$where);
	}
	
}
