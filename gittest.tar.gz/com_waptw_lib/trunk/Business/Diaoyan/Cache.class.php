<?php
/**
 * 广告类缓存
 * @package ads
 * @author mayong
 *
 */
class Waptw_Business_Diaoyan_Cache {

	static public function GetList($arr,$cache=true) {
		$key=Ucweb_Cache_Key::Get(__CLASS__.''.__FUNCTION__,$arr);
		
		$result = Ucweb_Cache_Adapter::Get($key);	
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$timestamp=time();
			$sign=md5('waptwbusinessdiaoyanapi'.$timestamp);
			$url='http://may.ads.waptw.dev/diaoyan.php?sign='.$sign.'&t='.$arr['t'].'&method='.$arr['method'].'&format='.$arr['format'];
			//var_dump($url);
			$result=unserialize(file_get_contents($url));
			if ($result['rsp']['rsp_error']['code']==1000) {
				$result=$result['rsp']['rsp_data'];
			}
			else {
				$result=array();
			}
			Ucweb_Cache_Adapter::Set($key,$result,5*60);
			return $result;
		}
	}
}