<?php
/**
 * 搜索关键字缓存类
 * @package keyword
 * @author mayong@ucweb.cn
 *
 */
class Waptw_KeyWord_Cache 
{
	/**
	 * 获取关键字缓存
	 * 
	 * @param 投放位置 int $position
	 * @return 关键字数组 array  $result
	 */
	public static function Get($position)
	{
		$key = Ucweb_Cache_Key::Get("keyword",$position);
		$result = Ucweb_Cache_Adapter::Get($key);
		return $result;
	}
	
	
	/**
	 * 清除关键字缓存
	 */
	public static function Update()
	{
		Ucweb_Cache_Key::Update('keyword');
	}
	
	/**
	 * 写入关键字缓存(前台)
	 * 
	 * @param 投放位置 int $position
	 * @return 关键字数组 array  $result
	 */
	public static function Set($position,$option)
	{
		$key = Ucweb_Cache_Key::Get("keyword",$position);
		$result = Ucweb_Cache_Adapter::Set($key,$option);
	}
}
