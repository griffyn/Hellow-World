<?php
/**
 * 搜索关键字方法类
 * @package keyword
 * @author mayong@ucweb.cn
 *
 */
class Waptw_KeyWord_Action  
{
	/**
	 * 获得关键字列表
	 * 
	 * @param 关键字数组 array $option1
	 * @param 关键字投放数组 array $option2
	 * @return 关键字(含投放位)数组 array $option1
	 */
	public static function GetListByMix($option1,$option2)
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$tmp[$val['idx']] = $val['title'];
		}
		
		foreach ($option1 as $key => $val) {
			$option1[$key]['positionTitle'] = $tmp[$val['position']];
		}
		return $option1;
	}
	
	/**
	 * 获得关键字缓存
	 * 
	 * @param 关键字投放位 int $position
	 * @return 关键字数组 array $option
	 */
	public static function Get($position,$cache=TRUE)
	{
		$result=Waptw_KeyWord_Cache::Get($position);
		if ($cache && is_array($result)) 
		{
			return $result;
			exit();
		}
		
		$where='isDel=0 and position='.$position;
		Waptw_KeyWord_Dao::Instance();
		$option=Waptw_KeyWord_Dao::Get(1,Waptw_KeyWord_Dao::Count($where),'',$where);
		Waptw_KeyWord_Cache::Set($position,$option);
		return $option;
	}
}