<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Featured_Link_Dao extends Waptw_Abstract_Dao 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static private function getTable()
	{
		return "featuredLink";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,featuredId,platformId,isDel';
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	
	static private function newWhere()
	{
		return ' AND isDel = 0';
	}
	
	/**
	 * 根据机型集ID查询数据
	 *
	 * @param unknown_type $id
	 * @return unknown
	 */
	public static function GetByPlatformId($id)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where(" platformId =  ".$id.self::newWhere())->findAll();
		return $result;
	}
	
	/**
	 * 根据专辑ID来删除数据
	 *
	 * @param unknown_type $id
	 */
	static public function delByFId($id,$arr)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$db->T(self::getTable())->where(" featuredId =  ".$id.self::newWhere())->UcSave($arr);
	}
	
	/**
	 * 根据专辑ID来检索数据
	 *
	 * @param unknown_type $id
	 * @return unknown
	 */
	static public function GetByFeaturedId($id)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where(" featuredId =  ".$id.self::newWhere())->findAll();
		return $result;
	}
	
	/**
	 * 根据专辑ID来检索数据（特别版）
	 *
	 * @param unknown_type $id
	 * @return unknown
	 */
	static public function GetByFeaturedIdUn($id)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->query('SELECT title FROM platform WHERE isDel = 0 AND idx IN (SELECT platformId FROM featuredLink WHERE isDel = 0 AND featuredId ='.$id.')');
		return $result;
	}
	
		/**
	 * 通过机型集来获取数据
	 *
	 * @param unknown_type $platformId
	 * @return unknown
	 */
	static public function GetByPlatformIds($platformId)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		if($platformId != "")
		{
			$result = $db->T(self::getTable())->where("isDel = 0 AND platformId in (".$platformId.")")->findAll();
		}
		return $result;
	}
	
}
