<?php
/**
 * 专题缓存类
 * @author yuwei
 */
class Waptw_Featured_Link_Cache 
{
	/**
	 * 通过机型集来获取数据
	 *
	 * @param unknown_type $platformId
	 * @param unknown_type $flg
	 * @return unknown
	 */
	static public function GetByPlatformIds($platformId,$eid='',$flg=true)
	{
		$keyWhere = "Waptw_Featured_Link_Cache_GetByPlatformId".$eid;
		$key = Ucweb_Cache_Key::Get('featuredLink',array($keyWhere));
		$result = Ucweb_Cache_Adapter::Get($key);
		if($flg && is_array($result)) return $result;
		$result = Waptw_Featured_Link_Dao::GetByPlatformIds($platformId);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update('featuredLink');
	}
}
