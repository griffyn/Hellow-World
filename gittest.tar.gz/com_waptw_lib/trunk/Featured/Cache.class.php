<?php
/**
 * 专题缓存类
 * @author thetwo@yahoo.cn
 */
class Waptw_Featured_Cache
{
	
	public static function GetByIdx($idx ,$cache=TRUE){
		$keyWhere = 'featured_idx_'.$idx;
		$key = Ucweb_Cache_Key::Get('featured',array($keyWhere));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && $result) {return $result;}
		Waptw_Featured_Dao::Instance();
		$result = Waptw_Featured_Dao::GetById($idx);
		Ucweb_Cache_Adapter::Get($key,$result);
		return $result;
	}
	
	public static function GetCountByChannelId($idx ,$cache=TRUE){
		$keyWhere = 'featured_count_channelid_'.$idx;
		$key = Ucweb_Cache_Key::Get('featured',array($keyWhere));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && $result) {return $result;}
		Waptw_Featured_Dao::Instance();
		$result = Waptw_Featured_Dao::Count('isDel = 0 AND channelId = '.$idx);
		Ucweb_Cache_Adapter::Get($key,$result);
		return $result;
	}
	
	/**
	 * 通过频道ID来获取专题分页
	 *
	 * @param unknown_type $channelid
	 * @param unknown_type $flg
	 * @return unknown
	 */
	static public function GetPageList($channelid,$page,$size,$cache=true)
	{
		$keyWhere = "featured_channel_".$channelid."_page_".$page;
		$key = Ucweb_Cache_Key::Get('featured',array($keyWhere));
		$result = Ucweb_Cache_Adapter::Get($key);
		if($cache)
		{
			if($result) return $result;
		}
		$result = Waptw_Featured_Dao::GetLimitListByChannelId($channelid,$page,$size);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 通过频道ID、专题ID获取专题内软件、主题、游戏列表
	 *
	 * @param unknown_type $channelId
	 * @param unknown_type $featuredId
	 * @param unknown_type $packIdx
	 * @param unknown_type $cache
	 * @return unknown
	 */
	static public function GetFilePack($channelId,$idx,$packIdx,$cache=true)
	{
		$keyWhere = "featured_channel_".$channelId."_idx_pack_".$idx;
		$key = Ucweb_Cache_Key::Get('featured',array($keyWhere));
		if($cache)
		{
			$result = Ucweb_Cache_Adapter::Get($key);
			if($result)
			{
				return $result;
			}
		}
		
		switch($channelId) {
			//软件
			case 21:
				Software_Soft_Dao::Instance();
				$result = Software_Soft_Dao::Get(0,100,'','idx in ('.$packIdx.')');
				break;
			//游戏
			case 22:
				Software_Game_Dao::Instance();
				$result = Software_Game_Dao::Get(0,100,'','idx in ('.$packIdx.')');
				break;
			//主题
			case 23:
				Software_Theme_Dao::Instance();
				$result = Software_Theme_Dao::Get(0,100,'','idx in ('.$packIdx.')');
				break;
		}
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 根据idx查询
	 *
	 * @param unknown_type $channelid
	 * @param unknown_type $idx
	 * @param unknown_type $flg
	 * @return unknown
	 */
	static public function GetLimit($channelid,$idx,$size,$eid='',$flg=true)
	{
		$keyWhere = "Waptw_Featured_Cache_GetLimit".$channelid."_".$size."_".$eid;
		$key = Ucweb_Cache_Key::Get('featured',array($keyWhere));
		$result = Ucweb_Cache_Adapter::Get($key);
		if($flg && is_array($result)) return $result;
		$result = Waptw_Featured_Dao::GetLimit($channelid,$idx,$size);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update('featured');
	}
}
