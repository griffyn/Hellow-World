<?php
/**
 * action_class
 * @author yuwei
 *
 */
class Waptw_Featured_Action
{
	/**
	 * 通过机型集来获取数据
	 *
	 * @param unknown_type $platformId
	 */
	static public function GetLimit($channelid,$platformId,$size=5,$eid='')
	{
		/**
		 * 这是新思路哦，二级缓存
		 * 这里使用缓存只是暂时，以后还会改进，如果有疑问请联系我
		 */
		//$key = "Waptw_Featured_Action_GetLimit_".$channelid."_".$eid."_".$size;
		//$result = Ucweb_Cache_Adapter::Get($key); 
		//if($result) return $result;
		
		$idx = "";
		if($platformId != "")
		{
			$platformData = Waptw_Featured_Link_Cache::GetByPlatformIds($platformId,$eid);
			if(count($platformData) > 0)
			{
				//$idx .= "(";
				for($i = 0;$i < count($platformData);$i++)
				{
					if($i < count($platformData) - 1)
					{
						$idx .= $platformData[$i]['featuredId'].",";
					}
					else 
					{
						$idx .= $platformData[$i]['featuredId'];
					}
				}
				//$idx .= ")";
			}
		}
		$result = Waptw_Featured_Cache::GetLimit($channelid,$idx,$size,$eid);
		if($platformId != '' && !$result) $result = Waptw_Featured_Cache::GetLimit($channelid,'',$size,$eid);
		
		//Ucweb_Cache_Adapter::Set($key,$result);
		
		return $result;
	}
}