<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Featured_Dao extends Waptw_Abstract_Dao 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static private function getTable()
	{
		return "featured";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,title,fTitle,channelId,pic,content,preface,recommend,fRecommend,hide,isDel';
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	static protected function getWhere($where)
	{
		if($where != "")
		{
			return $where." AND isDel = 0 ";
		}
		else 
		{
			return " isDel = 0 ";
		}
	}
	
	static private function newWhere()
	{
		return ' AND isDel = 0';
	}
	
	/**
	 * 查询所有数据
	 *
	 * @param unknown_type $where
	 * @return unknown
	 */
	static public function GetAll($categoryId,$where,$page,$size)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where('channelId = '.$categoryId.' AND '.self::getWhere($where))->page($page)->size($size)->order('insertDate desc')->findAll();
		//echo $db->getLastSql();
		return $result;
	}
	
	/**
	 * 获取所有的满足条件的数据
	 *
	 * @param unknown_type $where
	 * @param unknown_type $page
	 * @param unknown_type $size
	 * @return unknown
	 */
	static public function GetAllIds($where,$page,$size)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where(self::getWhere($where))->page($page)->size($size)->findAll();
		//echo $db->getLastSql();
		return $result;
	}
	
	/**
	 * 根据主键查询数据
	 *
	 * @param unknown_type $id
	 * @return array
	 */
	static public function GetById($id)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where(" idx =  ".$id.self::newWhere())->findAll();
		return $result;
	}
	
	
	/**
	 * 获取数据总数（没有删除滴）
	 *
	 * @return unknown
	 */
	/*
	static public function  GetCount($categoryId,$where)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->field('count(idx) as id')->where(' channelId = '.$categoryId.' AND isDel = 0 '.$where)->findAll();
		return $result[0]['id'];
	}
	*/
	
	/**
	 * 根据ID来获取数据总数
	 *
	 * @param unknown_type $ids
	 * @param unknown_type $where
	 * @return unknown
	 */
	static public function GetCountByIds($categoryId,$where)
	{
		if($where == "")
		{
			$where = "1=1";
		}
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->field('count(idx) as id')->where(' channelId = '.$categoryId.' AND isDel = 0 AND '.$where)->findAll();
		//echo $db->getLastSql();
		return $result[0]['id'];
	}
	
	/**
	 * 根据ID集合来查询数据
	 *
	 * @param unknown_type $ids
	 * @return unknown
	 */
	static public function GetByIds($ids,$where)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where(" idx in  ".$ids.$where.self::newWhere())->findAll();
		return $result;
	}
	
	static public function GetLimitListByChannelId($channelid,$page,$size)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->T(self::getTable())->where("channelId = ".$channelid." AND isDel = 0 ")->order('idx desc')->page($page)->size($size)->findAll();
		return $result;
	}

	/**
	 * 分机型查询
	 *
	 * @param unknown_type $channelid
	 * @param unknown_type $idx
	 * @return unknown
	 */
	static public function GetLimit($channelid,$idx,$size)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		if($idx != "")
		{
			$result = $db->T(self::getTable())->where(" fRecommend = 1 AND channelId = ".$channelid." AND idx in (".$idx.") AND isDel = 0 ")->order('idx desc')->page(1)->size($size)->findAll();
		}
		else 
		{
			$result = $db->T(self::getTable())->where(" fRecommend = 1 AND channelId = ".$channelid." AND isDel = 0 ")->order('idx desc')->page(1)->size($size)->findAll();
		}
		return $result;
	}
}
