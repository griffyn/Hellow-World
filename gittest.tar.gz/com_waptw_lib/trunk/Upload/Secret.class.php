<?php
class Waptw_Upload_Secret{
	
	public function GetByPath(){
		$s_FilePath = Ucweb_Http_Input::GetByContent("filepath");
		$s_FileInfo = Waptw_Upload_Dao::Get(1,10,'idx DESC',"filepath='$s_FilePath'");
		return $s_FileInfo[0];
	}
}
?>