<?php
/**
 * 上传文件
 * @author xiangxs
 * @package Upload
 */

class Waptw_Upload_Dao  {
	
		protected static $_table = 'upload';
		protected static $_field = 'idx,filePath,owner,assetType,insertDate,notes,md5,uid,size,isDel';
		protected static $_sqlStr = '';
	/**
	 * 添加数据
	 *
	 * @param array $option
	 * 返回新增行的idx
	 */
	public static function Add(array $option){
		$db = Ucweb_Db_Adapter::factory('default');
		$idx = $db->T(self::$_table)->pk("idx")->UcAdd($option);
		self::$_sqlStr = $db->getLastSql();
		return $idx;
	}	
	
	/**
	 * 获取数据总行数
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Count($where=''){
		$db = Ucweb_Db_Adapter::factory('default');
		$db->T(self::$_table)->pk("idx")->field("count(*) as count");
		if ($where) $db->where($where);
		$result=$db->findAll();
		self::$_sqlStr = $db->getLastSql();
		return $result[0]['count'];
	}
	
	/**
	 * @param string $tmp
	 * @param string $filename
	 * @param string $notes
	 * @param string $type
	 * @return 资源url
	 */
	public static function Store($tmp,$filename,$account,$notes='',$type='pack') {
		$_com= date('Y') . '/' . date('m') . '/' . date('d');
		$_dir=UPLOAD_PATH .  '/' . $type . '/' . $_com;
		self::_mkdir($_dir);
		$filename=str_ireplace(' ','_',$filename);
		$md5 = md5_file($tmp);
		if (copy($tmp,$_dir . '/' . $filename)) {
			$data=array(
				'filePath' => '/' . $type . '/' . $_com . '/' . $filename,
				'owner' => $account,
				'assetType' => $type,
				'insertDate' => time(),
				'notes' => $notes,
				'md5' => $md5,
				'size' => filesize($tmp)
			);
			if($type=='pack'){
				$a_PathInfo = pathinfo($filename);
				if($a_PathInfo['extension']=='sis'||$a_PathInfo['extension']=='sisx'){
					$o_UnPackAction = new Upload_Interface_UnPackSis();
					$s_uid = $o_UnPackAction->GetPackUid($data['filePath']);
					$data['uid'] = $s_uid;
				}
			}
			self::Add($data);
			return '/' . $_com . '/' . $filename;
		}
	}
	
	/**
	 * 创建目录
	 *
	 * @param string $dir
	 */
	private static function _mkdir($dir) {
		$_dirArray=explode('/',$dir);
		foreach ($_dirArray as $k=>$v) {
			$_dirString .=$v . '/';
			if (!is_dir($_dirString)) {
				mkdir($_dirString);
			}
		}
	}
	
	/**
	 * 根据翻页页面获取数据
	 *
	 * @param int $page 页码，默认是第一页，不可为0
	 * @param int $size 每页的大小。默认是20条。不可小于1
	 * 返回数组
	 */
	public static function Get($page = 1 ,$size = 20 ,$order = 'idx desc' ,$where=''){
			$db = Ucweb_Db_Adapter::Factory("default");
		$db->T(self::$_table)->pk("idx")->field(self::$_field);
		if ($where) {$db->where($where);}
		
		$page = (1 > $page)?1:$page;
		$size = (1 > $size)?20:$size;
		$result = $db->page($page)->size($size)->order($order)->findAll();
		self::$_sqlStr = $db->getLastSql();
		return $result;
	}
	
	
	/**
	 * 逻辑删除数据库记录，重命名文件名
	 *
	 * @param idx $id
	 */
	public static function DelByIs($idx) {
		$db = Ucweb_Db_Adapter::Factory("default");
		$_result=$db->T(self::$_table)->field(self::$_field)->pk("idx")->getbyidx($idx);
		if (file_exists(UPLOAD_PATH . $_result['filePath'])) {
			rename(UPLOAD_PATH . $_result['filePath'],UPLOAD_PATH . $_result['filePath'] . '.bak');
		}
		$_isDel=array('isDel'=>1);
		self::Edit($idx,$_isDel);
	}
	
	
	/**
	 * 修改数据
	 *
	 * @param int $idx 单个idx
	 * @param array $option 修改的数据
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Edit($idx ,array $option){
		unset($option['idx']);
		$db = Ucweb_Db_Adapter::factory('default');
		$result = $db->T(self::$_table)->where("idx=".$idx)->UcSave($option);
		//echo self::$_sqlStr = $db->getLastSql();
		return $result;
	}	
	

}
