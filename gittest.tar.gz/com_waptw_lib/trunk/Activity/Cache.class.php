<?php
/**********************************************
 * 活动发布缓存
 * Author:luzg
 **********************************************/
class Waptw_Activity_Cache extends Waptw_Activity_Dao
{
	/**
	 * 取得活动发布系统链接
	 *
	 * @return Array Object
	 */
	public static function GetLinks($cache = TRUE)
	{
		$keywhere = "Waptw_Activity_Cache_GetLinks";
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($keywhere));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		$where = "isDel = 0";
		Waptw_Activity_Dao::Instance();
		$result = Waptw_Activity_Dao::Get(1,20,'',$where);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}	
	
	/**
	 * yuwei
	 *
	 * @param unknown_type $where
	 * @param unknown_type $cache
	 * @return unknown
	 */
	public static function Select($where,$cache=TRUE)
	{
		$keywhere = "Waptw_Activity_Cache_Get_".$where;
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($keywhere));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		Waptw_Activity_Dao::Instance();
		$result = Waptw_Activity_Dao::Get(1,50,'pri',$where);
		Ucweb_Cache_Adapter::Set($key,$result);

		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
}
