<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Activity_Dao extends Waptw_Activity_Abstract_Dao 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return "activity";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,title,pri,activityModelId,activityType,logo,pic,activityInfo,prize,softPackId,sofyInfo,softUpInfo,softDownList,softPic,softBetter,softOtherInfo,otherPart,winnerShow,winnerList,collectInfo,message,showPosition,startDate,endDate,extend1,extend2,extend3,extend4,extend5,insertDate,isDel';
	}
	/**
	 * 为父类属性赋值
	 * */	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	/**
	 * 根据活动编号获取记录
	 * @return Array 
	 * */
	public static function GetById($idx){
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::$_table)->pk("idx");
		if ($where) $db->where('isDel = 0');
		$result=$db->where("idx = $idx")->findAll();
		return $result;		
	}	
}
