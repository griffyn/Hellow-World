<?php
/**
 * 表activityMsg操作类
 *
 * @author yuwei
 */
class Waptw_Activity_Info_Dao extends Waptw_Activity_Abstract_Dao
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static private function getTable()
	{
		return 'activityInfo';
	}
	
	/**
	 * 获取表的字段
	 *
	 * @return unknown
	 */
	static private function getField()
	{
		return "idx,name,tel,address,activityId,insertDate,isDel";
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	public static function Update($where,$arr)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::getTable())->where($where)->UcSave($arr);
	}
}
