<?php
class Waptw_Activity_Action
{
	/**
	 * Enter description here...
	 *
	 * @author yuwei
	 * @return unknown
	 */
	static public function Select($where)
	{
		$time = mktime(0,0,0,date('m'),date('d'),date('Y'));
		$where = "isDel = 0 AND instr(concat('|',`showPosition`,'|'),concat('|',{$where},'|')) AND startDate <= ".$time." AND ".$time." <= endDate";
		return Waptw_Activity_Cache::Select($where);
	}
}