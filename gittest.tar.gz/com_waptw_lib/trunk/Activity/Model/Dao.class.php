<?php
/**
 * 表 activityModel操作类
 *
 * @author yuwei
 */
class Waptw_Activity_Model_Dao extends Waptw_Activity_Abstract_Dao
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return 'activityModel';
	}
	
	/**
	 * 获取字段名
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,modelPath,title,fileSize,insertDate,isDel';
	}
	
	public static function Instance(){
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
}
