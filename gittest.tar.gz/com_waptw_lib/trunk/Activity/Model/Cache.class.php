<?php
/**
 * yuwei
 *
 */
class Waptw_Activity_Model_Cache extends Waptw_Activity_Model_Dao
{
	/**
	 * 
	 *
	 * @param unknown_type $where
	 * @param unknown_type $cache
	 * @return unknown
	 */
	public static function Select($where,$cache=TRUE)
	{
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($where));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		Waptw_Activity_Model_Dao::Instance();
		$result = Waptw_Activity_Model_Dao::Get(1,50,'',$where);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
}
