<?php
/**
 * 表 subpage操作类
 *
 * @author yuwei
 */
class Waptw_Activity_Subpage_Dao extends Waptw_Activity_Abstract_Dao
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return 'subpage';
	}
	
	/**
	 * 获取字段名
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,title,content,activityId,insertDate,isDel';
	}
	
	public static function Instance(){
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	public static function Update($where,$arr)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::getTable())->where($where)->UcSave($arr);
	}
}
