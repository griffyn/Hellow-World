<?php
class Waptw_Notify_Cache extends Waptw_Notify_Dao {
	/**
	 * 获取评论总数
	 *
	 * @param unknown_type $where
	 * @param unknown_type $cache
	 * @return int
	 */
	public static function Count($where = NULL,$cache = TRUE){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($where));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		
		Waptw_Notify_Dao::Instance();
		$result = Waptw_Notify_Dao::Count($where);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	/**
	 * 获取评论列表
	 *
	 * @param int $page 页码
	 * @param int $size 每页数量
	 * @param string $order 排序方式
	 * @param string $where 
	 * @param string $cache
	 * @return array
	 */
	public static function Get($page = 1,$size = 20,$order ='idx desc',$where = NULL,$cache = TRUE){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($page,$size,$order,$where));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		Waptw_Notify_Dao::Instance();
		$result = Waptw_Notify_Dao::Get($page,$size,$order,$where);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
}