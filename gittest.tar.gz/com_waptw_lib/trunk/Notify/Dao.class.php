<?php
/**
 * 处理评论方面的模板
 *
 * 
 */
class Waptw_Notify_Dao extends Waptw_Abstract_Dao 
{
		/**
	 * 获取数据库表名字
	 *
	 * @return unknown
	 */
	protected function getTable(){
		return 'notify';
	}
	
	protected function getField(){
		return 'idx, content, uId, ip,insertDate';
	}
	
	public static function Instance(){
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 取得品牌列表
	 *
	 * @param string $where 约束
	 * @param string $limit 限制条数
	 * @return array
	 */
	public static function GetList($page=0, $size=1, $where='')
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		
		$db->where('isDel = 0');
		if (!empty($where)) $db->where($where);
		
		if ($page!=0 || $size!=0) $db = $db->Page($page)->Size($size);
		$result = $db->field(self::getField())->T(self::getTable())->findAll();
		//echo $db->getLastSql();
		
		return $result;
	}
	
	/**
	 * 取得总条数
	 *
	 * @return int
	 */
	public static function GetCount($where)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		
		$db->where("isDel=0");
		if (!empty($where)) $db->where($where);
		
		$result = $db->T(self::getTable())->field("count(*) count")->findAll();
		//echo $db->getLastSql();
		return $result[0]['count'];
	}
	
	/**
	 * 根据ID找
	 *
	 * @param unknown_type $id
	 * @return Array
	 */
	public static function GetById($id)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result = $db->field(self::getField())->T(self::getTable())->where("idx=".$id)->findAll();
		return $result;
	}
	
	/**
	 * 保存数据
	 *
	 * @param array $mobileArr
	 * @return unknown
	 */
	public static function Add(Array $mobileArr)
	{
		return Ucweb_Db_Adapter::factory('com_waptw_down')->T(self::getTable())->UcAdd($mobileArr);
	}
	
	/**
	 * 编辑品牌
	 *
	 * @param array $mobileArr
	 * @param unknown_type $id
	 * @return unknown
	 */
	public static function Edit(Array $mobileArr, $idx)
	{
		return Ucweb_Db_Adapter::factory('com_waptw_down')->where("idx=".$idx)->T(self::getTable())->UcSave($mobileArr);
	}
	
	/**
	 * 逻辑删除品牌
	 *
	 * @param int $id
	 */
	public static function LogicDel($idx, $isDel=1)
	{
		return self::Edit(array('isDel'=>$isDel), $idx);
	}
}