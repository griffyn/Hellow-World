<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Questionnaire_Dao extends Waptw_Questionnaire_Abstract 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return "questionnaire";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,title,depict,beginDate,endDate,isDel,insertDate';
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
}
