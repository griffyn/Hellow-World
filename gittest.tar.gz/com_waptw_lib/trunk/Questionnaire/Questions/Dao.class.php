<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Questionnaire_Questions_Dao extends Waptw_Questionnaire_Abstract 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return "questions";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,title,type,questionnaireId,orderNum,isDel,insertDate';
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	static private function newWhere()
	{
		return ' AND isDel = 0';
	}
	
	/**
	 * 根据主键查询数据
	 *
	 * @param unknown_type $id
	 * @return array
	 */
	static public function GetById($id)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result = $db->T(self::getTable())->where(" idx =  ".$id.self::newWhere())->findAll();
		return $result;
	}
	
	public static function Update($where,$arr)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::getTable())->where($where)->UcSave($arr);
	}
	
}
