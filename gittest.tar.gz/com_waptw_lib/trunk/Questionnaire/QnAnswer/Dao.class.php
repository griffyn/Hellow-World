<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Questionnaire_QnAnswer_Dao extends Waptw_Questionnaire_Abstract 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return "qnAnswer";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,questionsId,optionsId,isDel,insertDate';
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
}
