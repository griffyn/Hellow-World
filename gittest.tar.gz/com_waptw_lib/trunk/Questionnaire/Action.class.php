<?php
class Waptw_Questionnaire_Action
{
	/**
	 * Enter description here...
	 * @author yuwei
	 * @return unknown
	 */
	static public function Select()
	{
		$time = mktime(0,0,0,date('m'),date('d'),date('Y'));
		$where = "isDel = 0 AND beginDate < ".$time." AND ".$time." < endDate";
		$result = Waptw_Questionnaire_Cache::Select($where);
		return $result;
	}
}