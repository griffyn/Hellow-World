<?php
/**
 * 表 activity操作类
 *
 * @author yuwei
 */
class Waptw_Questionnaire_Options_Dao extends Waptw_Questionnaire_Abstract 
{
	/**
	 * 获取表名
	 *
	 * @return unknown
	 */
	static protected function getTable()
	{
		return "options";
	}
	
	/**
	 * 获取字段
	 *
	 * @return unknown
	 */
	protected function getField()
	{
		return 'idx,title,questionsId,orderNum,isDel,insertDate';
	}
	
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	public static function Update($where,$arr)
	{
		$db = Ucweb_Db_Adapter::factory();
		$db->T(self::getTable())->where($where)->UcSave($arr);
	}
}
