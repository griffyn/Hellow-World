<?php
/**
 * 专题缓存类
 * @author yuwei
 */
class Waptw_Questionnaire_Options_Cache extends Waptw_Questionnaire_Options_Dao
{	
	/**
	 * 查询
	 *
	 * @param unknown_type $where
	 * @param unknown_type $cache
	 * @return unknown
	 */
	public static function Select($where,$cache=TRUE)
	{
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($where));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		Waptw_Questionnaire_Options_Dao::Instance();
		$result = Waptw_Questionnaire_Options_Dao::Get(1,50,'orderNum',$where);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
}
