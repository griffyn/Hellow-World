<?php
abstract class Waptw_Questionnaire_Abstract{
	
	protected static $_table = NULL;
	protected static $_field = NULL;
	protected static $_sqlStr = NULL;
	
	/**
	 * 显示最后一次执行的sql语句
	 *
	 * @return unknown
	 */
	public static function GetSql(){
		return self::$_sqlStr;
	}
	
	/**
	 * 添加数据
	 *
	 * @param array $option
	 * 返回新增行的idx
	 */
	public static function Add(array $option){
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$idx = $db->T(self::$_table)->pk("idx")->UcAdd($option);
		self::$_sqlStr = $db->getLastSql();
		return $idx;
	}
	
	/**
	 * 删除数据行
	 *
	 * @param int $idx 只能是一个idx
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Del($idx){
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::$_table)->where("idx=".$idx)->UcDelete();
		self::$_sqlStr = $db->getLastSql();
		return TRUE;
	}
	
	/**
	 * 修改数据
	 *
	 * @param int $idx 单个idx
	 * @param array $option 修改的数据
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Edit($idx ,array $option){
		unset($option['idx']);
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result = $db->T(self::$_table)->where("idx=".$idx)->UcSave($option);
		//echo self::$_sqlStr = $db->getLastSql();
		return $result;
	}
	
	/**
	 * 获取数据总行数
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Count($where=''){
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::$_table)->pk("idx")->field("count(*) as count");
		if ($where) $db->where($where);
		$result=$db->findAll();
		self::$_sqlStr = $db->getLastSql();
		return $result[0]['count'];
	}
	
	/**
	 * 根据翻页页面获取数据
	 *
	 * @param int $page 页码，默认是第一页，不可为0
	 * @param int $size 每页的大小。默认是20条。不可小于1
	 * 返回数组
	 */
	public static function Get($page = 1 ,$size = 20 ,$order = 'idx desc' ,$where=''){
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$db->T(self::$_table)->pk("idx")->field(self::$_field);
		if ($where) {$db->where($where);}
		
		$page = (1 > $page)?1:$page;
		$size = (1 > $size)?20:$size;
		$result = $db->page($page)->size($size)->order($order)->findAll();
		self::$_sqlStr = $db->getLastSql();
		return $result;
	}
}