<?php
if (!defined('PROJECT_ACCOUNT')) {define('PROJECT_ACCOUNT','http://account.waptw.com'); }
if (!defined('PROJECT_DOMAIN')) {define('PROJECT_DOMAIN','waptw.com'); }
if (!defined('PROJECT_EDITION_AUTO')) {define('PROJECT_EDITION_AUTO',FALSE);}
if (!defined('PROJECT_UCCP_SID')) {define('PROJECT_UCCP_SID',FALSE);}
abstract class Waptw_Session_Abstract{
	static protected $_domain = PROJECT_DOMAIN;
	
	static protected function _getDomain(){
		return str_replace('.','-',self::$_domain);
	}
	
	static public function GetBySid($sid){
		if ('file' == SESSION_SAVE_HANDLER && $_SESSION['sid'] == $sid) {
			return TRUE;
		}
		if (!stristr('memcache|memcached',SESSION_SAVE_HANDLER)) { return FALSE;}
		$config = Ucweb_Session_Adapter::getConfig(SESSION_SAVE_HANDLER);
		if (array_key_exists('ip', $config['host'])) {$host = array(0=>$config['host']);}
		else {$host = $config['host'];}
		foreach ($host as $k => $v) {
			$memcache_obj = memcache_connect($v['ip'], $v['port'],10);
			$var = memcache_get($memcache_obj, $sid);
			memcache_close($memcache_obj);
			if (strstr($var,$sid)) {
				return TRUE;
			}
		}
		return FALSE;
	}

	/**
	 * 用户ID
	 *
	 * @param unknown_type $cookie
	 * @return unknown
	 */
	static public function MakeSid($option ,$cookie){
		//sid匹配过程
		//首先判断是否为uc浏览器
		if (PROJECT_UCCP_SID && 0 < sizeof($uccp = Ucweb_Http_Header::GetUccp())) {
			$pattern = '/([^0-9a-zA-Z]+)/';
			if (1 < strlen($uccp['imsi'])) {
				$sid = 'imsi'.preg_replace($pattern,'',$uccp['imsi']);
			//应业务需求，取消imei对sid的适配
			//}elseif (1 < strlen($uccp['imei'])) {
				//$sid = 'imei'.preg_replace($pattern,'',$uccp['imei']);
			}elseif (1 < strlen($uccp['sn'])) {
				$sid = 'sn'.preg_replace($pattern,'',$uccp['sn']);
			}elseif (1 < strlen($uccp['dn'])) {
				$sid = 'dn'.preg_replace($pattern,'',$uccp['dn']);
			}
			
			if (strlen($sid) > 32) { 
				return (string)md5($sid);
			}elseif (strlen($sid) > 1) {
				return (string)str_pad($sid,32, "0", STR_PAD_LEFT);
			}
		}

		//第二 判断url参数
		$input['sid'] = Ucweb_Http_Input::GetByString('sid',FALSE);
		if (FALSE != $input['sid'] && 32 == strlen($input['sid']) && self::getBySid($input['sid'])) {
			return $input['sid'];
		}
		//第二 判断url参数，兼容RESTful风格的url
		//$a_urlparam = split('/',trim($_SERVER['REQUEST_URI'],'/'));
		//if (4 < sizeof($a_urlparam) && 32 == strlen($a_urlparam[0]) && self::getBySid($a_urlparam[0])) {
		//	return $a_urlparam[0];
		//}
		if (FALSE != $option['sid'] && 32 == strlen($option['sid']) && self::getBySid($option['sid'])) {
			return $option['sid'];
		}
		
		//第三 判断cookie是否正确
		if (FALSE != $cookie['sid'] && 32 == strlen($cookie['sid'])) {
			return $cookie['sid'];
		}
		
		//第四 随机生成32为sid
		$sid = Ucweb_Session_Adapter::MakeSId();
		Ucweb_Log_Adapter::Write($sid,'newsid');
		return $sid;
	}

	static public function Get(){
		if(!isset($_SESSION)) {return array();}
		if (array_key_exists(self::_getDomain().'-sid', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-sid']) {$account['sid'] = $_SESSION[self::_getDomain().'-sid'];}
		if (array_key_exists(self::_getDomain().'-uid', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-uid']) {$account['uid'] = $_SESSION[self::_getDomain().'-uid'];}
		if (array_key_exists(self::_getDomain().'-eid', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-eid']) {$account['eid'] = $_SESSION[self::_getDomain().'-eid'];}
		if (array_key_exists(self::_getDomain().'-app', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-app']) {$account['app'] = $_SESSION[self::_getDomain().'-app'];}
		if (array_key_exists(self::_getDomain().'-brower', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-brower']) {$account['brower'] = $_SESSION[self::_getDomain().'-brower'];}
		if (array_key_exists(self::_getDomain().'-ip', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-ip']) {$account['ip'] = $_SESSION[self::_getDomain().'-ip'];}
		if (array_key_exists(self::_getDomain().'-timestamp', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-timestamp']) {$account['timestamp'] = $_SESSION[self::_getDomain().'-timestamp'];}
		if (array_key_exists(self::_getDomain().'-redirect', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-redirect']) {$account['redirect'] = $_SESSION[self::_getDomain().'-redirect'];}
		if (array_key_exists(self::_getDomain().'-permissions', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-permissions']) {$account['permissions'] = $_SESSION[self::_getDomain().'-permissions'];}
		if (array_key_exists(self::_getDomain().'-yq', $_SESSION) && NULL != $_SESSION[self::_getDomain().'-yq']) {$account['yq'] = $_SESSION[self::_getDomain().'-yq'];}//发送邀请码防止刷新
		return $account;
	}

	static public function Set($account){
		if (array_key_exists('sid', $account) && NULL != $account['sid']) $_SESSION[self::_getDomain().'-sid'] = $account['sid'];
		if (array_key_exists('uid', $account) && NULL != $account['uid']) $_SESSION[self::_getDomain().'-uid'] = $account['uid'];
		if (array_key_exists('eid', $account) && NULL != $account['eid']) $_SESSION[self::_getDomain().'-eid'] = $account['eid'];
		if (array_key_exists('app', $account) && NULL != $account['app']) $_SESSION[self::_getDomain().'-app'] = $account['app'];
		if (array_key_exists('brower', $account) && NULL != $account['brower']) $_SESSION[self::_getDomain().'-brower'] = $account['brower'];
		if (array_key_exists('ip', $account) && NULL != $account['ip']) $_SESSION[self::_getDomain().'-ip'] = $account['ip'];
		if (array_key_exists('timestamp', $account) && NULL != $account['timestamp']) $_SESSION[self::_getDomain().'-timestamp'] = $account['timestamp'];
		if (array_key_exists('redirect', $account) && NULL != $account['redirect']) $_SESSION[self::_getDomain().'-redirect'] = $account['redirect'];
		if (array_key_exists('permissions', $account) && NULL != $account['permissions']) $_SESSION[self::_getDomain().'-permissions'] = $account['permissions'];
		if (array_key_exists('yq', $account) && NULL != $account['yq']) $_SESSION[self::_getDomain().'-yq'] = $account['yq'];//发送邀请码防止刷新
		return TRUE;
	}
	
	/**
	 * 清除session中uid
	 *
	 */
	static public function Clear() {
		unset($_SESSION[self::_getDomain().'-uid']);
	}

	protected static function getUccp(){
		$uccp = Ucweb_Http_Header::GetUccp();
		if (is_array($uccp)) {
			$url = PROJECT_ACCOUNT.'/mobiletelephone.php?method=getidx';
			foreach ($uccp as $k => $v) {if ($v) $url = "&$k=$v";}
			return FALSE;
		}
		return FALSE;
	}

	protected static function checkPasswd($method,$loginname,$passwd){
		$where = "isDel = 0 AND uid = '".$loginname."' AND pwd = '".$passwd."'";
		Waptw_Admin_Permissions_Dao::Instance();
		$account = Waptw_Admin_Permissions_Dao::Get(1,20,'',$where);
		return $account[0];
	}
}