<?php

class Waptw_Session_User extends Waptw_Session_Abstract {
	public function __construct() {
	}
	
	static public function Instance($option = array()) {
		$input = $uccp = $ucnav = $account = $cookie = $session = NULL;		
		Waptw_Cookie_User::Instance ( 1 );//实例化cookie
		$cookie = Waptw_Cookie_User::Get ( parent::$_domain );
		$sid = parent::MakeSid ( $option, $cookie );
		Waptw_Cookie_User::Set ( array ('sid' => $sid ) );		
		Ucweb_Session_Adapter::Instance ();
		session_id ( $sid );
		session_start ();
		$session = parent::Get ();
		$session_time = date ( "Y-m-d H:i:s", time () );
		$session ['sid'] = $sid;
		
		//处理ip
		if ('' == $session ['ip']) {
			$session ['ip'] = Ucweb_Http_Header::GetIp ();
		}
		//处理时间
		if ('' == $session ['timestamp']) {
			$session ['timestamp'] = ( string ) mktime ();
		}
		
		//处理渠道
		$input ['app'] = Ucweb_Http_Input::GetByInt ( 'app', FALSE );
		if (FALSE != $input ['app']) {
			$url = explode ( '?', $_SERVER ['REQUEST_URI'], 1 );
			$url = explode ( '/', $url [0] );
			$input ['app'] = ($url [3]) ? $url [3] : FALSE;
		}
		if (FALSE != $input ['app']) {
			$session ['app'] = $input ['app'];
		} elseif (array_key_exists ( 'app', $option ) && '' != $option ['app']) {
			$session ['app'] = $option ['app'];
		} else {
			$session ['app'] = '0';
		}
		
		//处理浏览器
		if ('' == $session ['brower']) {
			$input ['bro'] = Ucweb_Http_Input::GetByString ( 'bro', FALSE );
			if (FALSE == $input ['bro']) {
				$session ['brower'] = Ucweb_Http_Header::GetBrower ();
				
				$msg = join ( '|', array ($session ['sid'], $session ['app'], $_SERVER ['HTTP_USER_AGENT'] ) );
				Ucweb_Log_Adapter::Write ( $msg, 'brower' );
			} else {
				$session ['brower'] = $input ['bro'];
			}
		}
		
		/**
		 * 处理机型适配为题
		 * 首先url >auto >ucnav
		 * ua 分为 导航 navua 标准 standardua UCWEB ucwebua UCCPAREA uccpua 
		 */
		
		$input ['eid'] = Ucweb_Http_Input::GetByString ( 'eid', FALSE );
		$adapt_type = Ucweb_Http_Input::GetByString ( 'sp', FALSE ) ? 4 : 0;
		if (FALSE != $input ['eid']) {
			$pfEid = $input ['eid'];
			$session ['eid'] = $input['eid'];
		}
		//url上的eid，0也是一种机型
		if (strlen($option['eid'])>0) {
			$pfEid = $option ['eid'];
			$session ['eid'] = $option ['eid'];
		}
		//ucnav
		if (array_key_exists ( 'UcNav', $_SERVER )) {
			$urlNav = Ucweb_Http_Input::GetByContent ( 'ua', FALSE );
			$ua = Mobile_Edition_Ua_Action::Filter ( $urlNav );
			$pfEid = Mobile_Edition_Ua_Action::getEditionByUa ( $ua );
			$session ['eid'] = $pfEid ? ( string ) $pfEid : 0;
			$adapt_status = $session ['eid'] ? 1 : 0;
			$msg = join ( '|', array ($session_time, 3, $session ['sid'], $session ['eid'], $session ['app'], $session ['brower'], $urlNav, $ua, $adapt_status ) );
			Ucweb_Log_Adapter::Write ( $msg, 'edition' );
		}
		
		
		//autoUA
		$switch = explode(",",PROJECT_EDITION_AUTO);
		$edition_auto = $switch[0];//自动适配
		$effect = $switch[1];//生效写入session
		if ($edition_auto == 'TRUE' &&  !strlen($pfEid)>0 && ! $option ['eid']) {
			if ($option ['edition'] != 'noauto') {
				
				if (Ucweb_Http_Header::GetUccp ()) {
					$usragnet = Ucweb_Http_Header::GetUccp ();
					$original_ua = $usragnet ['ua'];
					$matcher = Waptw_Edition_Interface::UaMatcher ( array ('useragent' => $original_ua ) );
					$ua = $matcher ['ua'];
					$pfEid = $matcher ['eid'];
					if ($pfEid && $effect == 'TRUE') {
						$session ['eid'] = $pfEid;
					}
					$adapt_status = $pfEid ? 1 : 0;
					$msg = join ( '|', array ($session_time, 1, $session ['sid'], $pfEid, $session ['app'], $session ['brower'], $original_ua, $ua, $adapt_status ) );
					Ucweb_Log_Adapter::Write ( $msg, 'edition' );
				}
				if (!strlen($pfEid)>0 && ! $option ['eid']) {
					$original_ua = $usragent = Ucweb_Http_Header::GetUa ();
					$matcher = Waptw_Edition_Interface::UaMatcher ( array ('useragent' => $usragent ) );
					$ua = $matcher ['ua'];
					$pfEid = $matcher ['eid'];
					if ($pfEid && $effect == 'TRUE') {
						$session ['eid'] = $pfEid;
					}
					$adapt_status = $pfEid ? 1 : 0;
					$msg = join ( '|', array ($session_time, 2, $session ['sid'], $pfEid, $session ['app'], $session ['brower'], $original_ua, $ua, $adapt_status ) );
					Ucweb_Log_Adapter::Write ( $msg, 'edition' );
				}
			}
		}
		
//		if ('' != $session ['eid'] && !strlen($pfEid)>0) {
//			$option ['eid'] = $session ['eid'];
//		}
		
		if (!$session['eid']) {
			$session['eid'] = (string) 0;
		}
		parent::Set ( $session );
		//$session= parent::Get();
		$session ['idx'] = (array_key_exists ( 'uid', $session )) ? $session ['uid'] : $session ['sid'];
		return $session;
	}
	
	public static function Redirect() {
		$redirect = ($redirect = Waptw_Util_UrlRewrite::Clear ( $_SERVER ['QUERY_STRING'] )) ? $_SERVER ['SCRIPT_NAME'] . '?' . $redirect : $_SERVER ['SCRIPT_NAME'];
		$account ['redirect'] = urlencode ( $redirect );
		Waptw_Cookie_User::Set ( $account );
		parent::Set ( $account );
	}
	
	public static function Login($method, $account, $passwd) {
		if (! $method) {
			return FALSE;
		}
		if (! $account) {
			return FALSE;
		}
		if (! $passwd) {
			return FALSE;
		}
		
		//if (!$account = self::checkPasswd($method,$account,$passwd)) {return FALSE;}
		$account = array ('idx' => 1, 'ename' => $account );
		
		self::Instance ( $account ['idx'] );
		$ip = Ucweb_Http_Header::GetIp ();
		self::Set ( $account );
		
		return TRUE;
	}
	
	public static function Logout() {
		self::Instance ();
		unset ( $_SESSION [self::_getDomain () . '-sid'] );
		unset ( $_SESSION [self::_getDomain () . '-uid'] );
		unset ( $_SESSION [self::_getDomain () . '-eid'] );
		unset ( $_SESSION [self::_getDomain () . '-app'] );
		unset ( $_SESSION [self::_getDomain () . '-ip'] );
		unset ( $_SESSION [self::_getDomain () . '-bro'] );
		unset ( $_SESSION [self::_getDomain () . '-timestamp'] );
		//session_destroy();
		//unset($_SESSION);
		return TRUE;
	}
}
