<?php
class Waptw_Session_Admin extends Waptw_Session_Abstract {
	public function __construct(){;}
	
	static public function Instance(){
//		Waptw_Cookie_User::Instance(1);
		Ucweb_Session_Adapter::Instance();
//		$cookie = Waptw_Cookie_User::Get();
//		if (32 == strlen($cookie['sid'])) {
//			$account['sid'] = $cookie['sid'];
//		}else {
//			$account['sid'] = Ucweb_Session_Adapter::MakeSId();
//			$account['sid'] = (string)str_pad($account['sid'],32, "0", STR_PAD_LEFT);
//		}
//		
//		Waptw_Cookie_User::Set($account);
//		
//		session_id($account['sid']);
		session_start();
		$account = parent::Get();
		$account['idx'] = ($account['uid'])?$account['uid']:$account['sid'];
		return $account;
	}
	
	static public function Login($method,$loginname,$passwd){
		if (!$method) { return FALSE;}
		if (!$loginname) { return FALSE;}
		if (!$passwd) { return FALSE;}
		
		if (!$result = self::checkPasswd($method,$loginname,$passwd)) {return FALSE;}
		//$admin = array('idx'=>1,'ename'=>$account);
		$account['uid'] = $result['idx'];
		$account['permissions'] = $result['uright'];
		if (!$account['timestamp']) {$account['timestamp'] = (string)mktime();}
		if (!$account['ip']) {$account['ip'] = Ucweb_Http_Header::GetIp();}
		
		
		
		
		
		self::Set($account);
		$option['accountId'] = $account['uid'];
		$option['ip'] = $account['ip'];
		$option['comments'] = 'login';
		$option['insertDate'] = $account['timestamp'];
		Waptw_Admin_Log_Dao::Instance();
		Waptw_Admin_Log_Dao::Add($option);
		
		return $account;
	}
	
	public static function Logout(){
		unset($_SESSION[self::_getDomain().'-uid']);
		unset($_SESSION[self::_getDomain().'-permissions']);
		//session_destroy();
		//unset($_SESSION);
		return TRUE;
	}
	
	public static function IsLogin(array $account ,$redirect = TRUE){
		$redirect = TRUE;
		if (NULL == intval($account["uid"]) && $redirect) {
			echo "<script>window.open('default.php?pAction=login','_parent')</script>";
			return ;
		}
		return TRUE;
	}
}


