<?php
class Waptw_Cookie_User extends Waptw_Cookie_Abstract{
	public static function Set(array $account){
		if (array_key_exists('sid',$account) && NULL !== $account['sid']) {self::_setcookie('sid',$account['sid']);}
//		if ($account['uid'] !== NULL) {self::_setcookie('uid',$account['uid']);}
//		if ($account['eid'] !== NULL) {self::_setcookie('eid',$account['eid']);}
//		if ($account['app'] !== NULL) {self::_setcookie('app',$account['app']);}
//		if ($account['brower'] !== NULL) {self::_setcookie('brower',$account['brower']);}
//		if ($account['ip'] !== NULL) {self::_setcookie('ip',$account['ip']);}
//		if ($account['timestamp'] !== NULL) {self::_setcookie('timestamp',$account['timestamp']);}
//		if ($account['redirect'] !== NULL) {self::_setcookie('redirect',$account['redirect']);}
		return TRUE;
	}
	
	public static function Get(){
		if (array_key_exists('sid',$_COOKIE) && NULL !== $_COOKIE['sid']) {$account['sid'] = $_COOKIE['sid'];}
//		if ($_COOKIE['uid'] !== NULL) {$account['uid'] = $_COOKIE['uid'];}
//		if ($_COOKIE['eid'] !== NULL) {$account['eid'] = $_COOKIE['eid'];}
//		if ($_COOKIE['app'] !== NULL) {$account['app'] = $_COOKIE['app'];}
//		if ($_COOKIE['brower'] !== NULL) {$account['brower'] = $_COOKIE['brower'];}
//		if ($_COOKIE['ip'] !== NULL) {$account['ip'] = $_COOKIE['ip'];}
//		if ($_COOKIE['timestamp'] !== NULL) {$account['timestamp'] = $_COOKIE['timestamp'];}
//		if ($_COOKIE['redirect'] !== NULL) {$account['redirect'] = $_COOKIE['redirect'];}
		return $account;
	}
}