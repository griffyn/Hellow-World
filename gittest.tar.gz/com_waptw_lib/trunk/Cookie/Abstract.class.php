<?php
if (!defined('PROJECT_ACCOUNT')) {define('PROJECT_ACCOUNT','http://account.waptw.com'); }
if (!defined('PROJECT_DOMAIN')) {define('PROJECT_DOMAIN','waptw.com'); }
abstract class Waptw_Cookie_Abstract{
	protected static $_domain = PROJECT_DOMAIN ;

	public static function Instance($use_cookies = 0,$cookie_path = '/'){
		//使用 COOKIE 保存 SESSION ID 的方式
		ini_set('session.cookie_domain', '.'.self::$_domain);
		ini_set('session.use_cookies',$use_cookies);

//		if (isset($_SERVER['HTTP_HOST'])) {
//			if(strpos($_SERVER['HTTP_HOST'], ':') != -1){
//				$domain = substr($_SERVER['HTTP_HOST'], 0, strpos($_SERVER['HTTP_HOST'], ':'));
//			}
//			else{
//				$domain = $_SERVER['HTTP_HOST'];
//			}
//			$domain = preg_replace('`^www.`', '', $domain);
//			// Per RFC 2109, cookie domains must contain at least one dot other than the
//			// first. For hosts such as 'localhost', we don't set a cookie domain.
//			if (count(explode('.', $domain)) > 2) {
//				ini_set('session.cookie_domain', $domain);
//			}
//		}
		//ini_set('session.cookie_domain', '.'.self::$_domain);

	}

	function _setcookie($name,$value){
		$expire = time()+3600;
		$path  = '/';
		$domain = '.'.self::$_domain;
		setcookie($name,$value,$expire,$path,$domain);
	}
}