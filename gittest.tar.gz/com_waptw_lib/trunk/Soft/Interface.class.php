<?php
/**
 * 软件仓库接口
 * @package Soft
 * @author fuqiang
 * @copyright uc.cn
 *
 */
class Waptw_Soft_Interface {
    /*
	*软件仓库接口（软件查询接口）
	*用途 根据条件返回软件信息
	*@pack	soft
	*@author  fuqiang
	*20110112
    */
    public function Search(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::Search ( $target, $cache );
        return $result;
    }
    public function GetPack(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::GetPack ( $target, $cache );
        return $result;
    }
    public function AddPack(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::AddPack ( $target, $cache );
        return $result;
    }
    public function EditPack(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::EditPack ( $target, $cache );
        return $result;
    }
    public function DelPack($idx, $cache = true) {
        $result = Waptw_Soft_Cache::DelPack ( $idx, $cache );
        return $result;
    }
    public function GetNec(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::GetNec( $target, $cache );
        return $result;
    }
    public function AddNec(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::AddNec ( $target, $cache );
        return $result;
    }
    public function EditNec(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::EditNec ( $target, $cache );
        return $result;
    }
    public function DelNec($idx, $cache = true) {
        $result = Waptw_Soft_Cache::DelNec ( $idx, $cache );
        return $result;
    }
    public function GetApp(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::GetApp( $target, $cache );
        return $result;
    }
    public function AddApp(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::AddApp ( $target, $cache );
        return $result;
    }
    public function EditApp(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::EditApp ( $target, $cache );
        return $result;
    }
    public function DelApp($idx, $cache = true) {
        $result = Waptw_Soft_Cache::DelApp ( $idx, $cache );
        return $result;
    }
    public function GetCategory(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::GetCategory( $target, $cache );
        return $result;
    }
    public function AddCategory(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::AddCategory ( $target, $cache );
        return $result;
    }
    public function EditCategory(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::EditCategory ( $target, $cache );
        return $result;
    }
    public function DelCategory($idx, $cache = true) {
        $result = Waptw_Soft_Cache::DelCategory ( $idx, $cache );
        return $result;
    }
    public function GetComment(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::GetComment( $target, $cache );
        return $result;
    }
    public function AddComment(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::AddComment ( $target, $cache );
        return $result;
    }
    public function EditComment(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::EditComment ( $target, $cache );
        return $result;
    }
    public function DelComment($idx, $cache = true) {
        $result = Waptw_Soft_Cache::DelComment ( $idx, $cache );
        return $result;
    }
    public function GetAdvice(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::GetAdvice( $target, $cache );
        return $result;
    }
    public function AddAdvice(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::AddAdvice ( $target, $cache );
        return $result;
    }
    public function EditAdvice(array $target, $cache = true) {
        $result = Waptw_Soft_Cache::EditAdvice ( $target, $cache );
        return $result;
    }
    public function DelAdvice($idx, $cache = true) {
        $result = Waptw_Soft_Cache::DelAdvice ( $idx, $cache );
        return $result;
    }
}