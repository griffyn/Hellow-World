<?php
/**
 * 软件仓库接口数据访问类
 * @package Edition
 * @author wangjun
 * @copyright uc.cn
 * @version 1.2.7
 *
 */
class Waptw_Soft_Dao {
   /**
     *
     * 获取接口数据
     * @param string $s_method
     * @param array $a_parames
     * @return array $a_result
     */
   public static function getResult($s_method,array $a_parames = array()){
        $s_sign = 'UcwebAPImethod' . $s_method;
        $s_parames = '';
        $timestamp = time ();
        foreach ( $a_parames as $key => $val ) {
            $s_sign .= $key . $val;
            $s_parames .= $key . '=' . $val . '&';
        }
        $s_parames = '&' . substr ( $s_parames, 0, - 1 );
        $s_parames = str_replace ( ' ', '%20', $s_parames );
        $s_sign = str_replace ( ' ', '', $s_sign );
        //var_dump($s_sign.'timestamp' . $timestamp);
        $s_sign = md5($s_sign.'timestamp' . $timestamp);
        $url = PROJECT_SOFT . '/secret.php?method='.$s_method . $s_parames
                . '&timestamp=' . $timestamp . '&sign=' . $s_sign . '&format=Json';
//			var_dump($url);
        $a_result = file_get_contents ( $url );
        $a_result = json_decode ( $a_result, true );
        if (!count ( $a_result ['rsp'] )) {
            $a_result ['rsp'] = $a_result;
        }
        if ($a_result ['rsp'] ['rsp_error'] ['code'] == 100000) {
            $a_result = $a_result ['rsp'] ['rsp_data'];
        } else {
            $a_result = array ();
        }
        return $a_result;
    }
}

?>
