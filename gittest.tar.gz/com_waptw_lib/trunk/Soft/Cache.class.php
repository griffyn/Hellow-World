<?php
/**
 * 软件仓库接口类缓存
 * @package Edition
 * @author fuqiang
 * @copyright uc.cn
 * @version 1.0.2
 *
 */

class Waptw_Soft_Cache {
    static public function Search(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Search_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    static public function GetPack(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Pack_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function AddPack(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Pack_Add',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function EditPack(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Pack_Edit',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function DelPack($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx)  );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Soft_Dao::getResult('Soft_Pack_Del',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    static public function GetNec(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Nec_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function AddNec(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Nec_Add',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function EditNec(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Nec_Edit',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function DelNec($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx)  );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Soft_Dao::getResult('Soft_Nec_Del',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    static public function GetApp(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_App_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function AddApp(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_App_Add',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function EditApp(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_App_Edit',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function DelApp($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx)  );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Soft_Dao::getResult('Soft_App_Del',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    static public function GetCategory(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Category_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function AddCategory(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Category_Add',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function EditCategory(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Category_Edit',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function DelCategory($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx)  );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Soft_Dao::getResult('Soft_Category_Del',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    static public function GetComment(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Comment_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function AddComment(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Comment_Add',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function EditComment(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Comment_Edit',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function DelComment($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx)  );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Soft_Dao::getResult('Soft_Comment_Del',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
    static public function GetAdvice(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Advice_Get',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function AddAdvice(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Advice_Add',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function EditAdvice(array $target, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, $target );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $result = Waptw_Soft_Dao::getResult('Soft_Advice_Edit',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }

    static public function DelAdvice($idx, $cache = true) {
        $key = Ucweb_Cache_Key::Get ( __CLASS__ . '' . __FUNCTION__, array($idx)  );
        $result = Ucweb_Cache_Adapter::Get ( $key );

        if ($cache && is_array($result) && count($result)) {
            return $result;
        } else {
            $target = array('idx'=>$idx);
            $result = Waptw_Soft_Dao::getResult('Soft_Advice_Del',$target);
        }
        Ucweb_Cache_Adapter::Set ( $key, $result );
        return $result;
    }
}
?>