<?php
class Waptw_App_Cache extends Waptw_App_Dao {
	/**
	 * 获取渠道信息
	 *
	 * @param varchar $where
	 * @param bool $cache
	 * @return int
	 */
	public static function Get($where = '',$cache = TRUE){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array($where));
		if ($cache && is_array($result = Ucweb_Cache_Adapter::Get($key))){
			return $result;
		}
		
		Waptw_App_Dao::Instance();
		$result = Waptw_App_Dao::Get(1,1,'',$where);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
}