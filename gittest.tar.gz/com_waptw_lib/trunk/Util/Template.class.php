<?php
if (!defined(TEMPLATE_CACHE)){define('TEMPLATE_CACHE',FALSE);}
class Waptw_Util_Template{
	/**
	 * 页面模板显示类
	 *
	 * @param int $sid
	 * @param string $template
	 * @param array $option
	 * @param mix $expire 当$expire = 0的时候不进行缓存 
	 */
	static public function Display($account,$template,$option,$expire = 0){
		$key = self::get($account);
		//获取品牌专区推荐 $platformId,$channelId,$page,$type,$nowpage,$pagesize,$cache=true
		//$option['partner'] = Waptw_Recommend_Cache::GetAllList(0,0,3,0,0,8,0);
		$option['account'] = $account;
		$option['account']['sid'] = self::Key();
		$option['account']['idx'] = self::Key();
		$contents = Ucweb_Template_Adapter::Render($template,$option);
		if ($expire) Ucweb_Cache_Adapter::Set($key,$contents,$expire);
		$contents = str_replace(self::Key(),$account['sid'],$contents);
		echo $contents;
		return TRUE;
	}
	
	/**
	 * 获取页面缓存并显示。并替换用户ID的链接
	 *
	 * @param unknown_type $sid
	 * @return unknown
	 */
	static public function Cache($account){
		$key = self::get($account);
		$contents = Ucweb_Cache_Adapter::Get($key);
		if (TEMPLATE_CACHE && 0 < strlen($contents)) {
			$contents = str_replace(self::Key(),$account['sid'],$contents);
			echo $contents;
			return TRUE;
		}
		return FALSE;
	}
	
	static private function get($account = NULL){
		$qs = (strstr($_SERVER["QUERY_STRING"],'&'))?substr($_SERVER["QUERY_STRING"],strpos($_SERVER["QUERY_STRING"],'&',1)):NULL;
		if(@strpos($_SERVER["REQUEST_URI"],'/',2)>=32){
			$ru = (strstr($_SERVER["REQUEST_URI"],'/'))?substr($_SERVER["REQUEST_URI"],@strpos($_SERVER["REQUEST_URI"],'/',2)):NULL;
		}else{
			$ru = $_SERVER["REQUEST_URI"];
		}
		$key = "template-".md5($_SERVER['SERVER_NAME'].$qs.$ru);
     	//var_dump($key);
     	return $key;

	}
	
	static public function Key(){
		return '[account-sid]';
	}
}