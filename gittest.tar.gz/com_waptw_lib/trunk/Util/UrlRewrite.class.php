<?php
/**
 * urlrewrite
 * 
 * @author xiangxs
 * @version 1.0
 */

if (!defined('PROJECT_WAP')) {define('PROJECT_WAP','http://wap.waptw.com');}
if (!defined('TEMPLATE_PREFIX')) {define('TEMPLATE_PREFIX','.html');}
class Waptw_Util_UrlRewrite {

	public static function Get($url,$account = array(),$node = NULL) {	
		$session = Waptw_Session_User::Get();
		if ($session) {
			$session =  $account + $session;
		} else {
			$session=$account;
		}

		if ($session){
			$sid = ((string)$session['sid'])?((string)$session['sid']):'0';
			$eid = ((string)$session['eid'])?((string)$session['eid']):'0';
			$app = ((string)$session['app'])?((string)$session['app']):'0';
			$bro = ((string)$session['brower'])?((string)$session['brower']):'other';
		}
		
	
		$url = self::Clear($url);
		$url = str_replace('//','/',$url);

		//$a_Router = Ucweb_Config_Load::GetRouterConfig($node);
		if ('downwww' == $node) {
			if(is_numeric($eid) && intval($eid)>0){
				//var_dump($_SERVER['REQUEST_URI']);
				$a_Tem = explode('?',$_SERVER['REQUEST_URI'],1);
				//if(strpos($_SERVER['REQUEST_URI'],'?')){
				//	list($brand,$edition) = explode('/',trim(substr($_SERVER['REQUEST_URI'],0,strpos($_SERVER['REQUEST_URI'],'?')),'/'));
				//}else{
				list($brand,$edition) = explode('/',trim($a_Tem[0],'/'));
				//}
				$url = "/$brand/$edition/".$url;
			}
		}else {
			$url = "/$sid/$eid/$app/$bro/$url";
		}
				
		$url = preg_replace('/[\/]{2,}/','/',$url);
		return $url;
	}
	
	public static function Clear($url){
		$url = preg_replace('/.php/',TEMPLATE_PREFIX,$url,1);
		//这里的正则表达式和.ht 重定向文件必须保持一致
		$patterns = '/sid=([a-z0-9]{0,32})(&amp;|&){1}eid=([0-9]+)(&amp;|&){1}app=([0-9]+)(&amp;|&){1}bro=([a-z0-9]+)(&amp;|&){0,1}/';
		$url = preg_replace($patterns, '', $url);
		if (substr($url,-1) == '?') {$url = str_replace('?','',$url);}
		return $url;
	}

	/**
	 * 替换旧地址参数为新参数名
	 *
	 * @param string $url
	 * @param array $parameters
	 */
	public static function Replace($url,$replaceParameters) {
		$urls = explode('.asp',$url);
		if (2 == sizeof($urls)){
			$pageName = substr($urls[0],1).".asp";
			if (true != empty($replaceParameters[$pageName])) {
				$newUrl = $replaceParameters[$pageName]['page']."?";
				$urlParamentStr = $urls[1];
				$urlParamentStr = substr($urlParamentStr,1);
				if (true != empty($urlParamentStr)) {
					$paraments = explode('&',$urlParamentStr);
					foreach ($paraments as $value) {
						$paramentsTemp = explode('=',$value);
						$paramentName = $paramentsTemp[0];
						$paramentName = $replaceParameters[$pageName][$paramentName];
						if (true != empty($paramentName)) {
							$newUrl = $newUrl.$paramentName.'='.$paramentsTemp[1].'&';
						}else {
							$newUrl = $newUrl.$paramentsTemp[0].'='.$paramentsTemp[1].'&';
						}
					}
					$newUrl = substr($newUrl,0,-1);
				}
				return $newUrl;
			}
		}else {
			return $url;
		}
	}

}