<?php
class Waptw_Util_Cache {
	
	/**
	 * 定时失效
	 *
	 * @param int $a
	 * @param int $b
	 * @return 时间戳
	 */
	public static function expiretime($a=11,$b=17) {
		$hour=date('G');
		if ($hour<$a) {
			$result=strtotime(date('Y').'-'.date('m').'-'.date('d').' '.$a.':'.'00:00');
		} elseif ($hour<$b) {
			$result=strtotime(date('Y').'-'.date('m').'-'.date('d').' '.$b.':'.'00:00');
		} else {
			$result=strtotime(date('Y').'-'.date('m').'-'.date('d').' '.$a.':'.'00:00')+86400;
		}
		return $result;
	}
	
}
