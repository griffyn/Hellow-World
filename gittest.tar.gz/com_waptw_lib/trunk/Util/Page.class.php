<?php
/**
 * 站内分页类,主要提供分页
 * 请使用对应的CSS
 * 
 * auth:鲁志刚
 * time:2009.11.3
 */
if (!defined('TEMPLATE_PREFIX')) {define('TEMPLATE_PREFIX','.html');}

class Waptw_Util_Page
{
	private $DataPerPage = 5;
	private $LinkPerPage = 19;
	private $PageChar = 'page';
	private $CurPage = 0;
	
	/**
	 * 设置每页数据条数
	 *
	 * @param int $perPage
	 */
	public function SetPerPage($perPage)
	{
		$this->DataPerPage = $perPage;
	}
	
	/**
	 * 设置每页多少链接
	 *
	 * @param int $linkPage
	 */
	public function SetLinkPerPage($linkPage)
	{
		$this->LinkPerPage = $linkPage;
	}
	
	/**
	 * 设置Url传递的页字符串
	 *
	 * @param string $pageChar
	 */
	public function SetPageChar($pageChar)
	{
		$this->PageChar = $pageChar;
	}
	
	/**
	 * 取得开始条数
	 *
	 */
	public function GetStartNo()
	{
		return ($this->CurPage - 1) * $this->DataPerPage;
	}

	/**
	 * 取得开始页面
	 *
	 * @return int
	 */
	public function GetStart()
	{
		// return ($this->CurPage - 1) * $this->DataPerPage;
		return $this->CurPage;
	}
	
	public function checkNum($page){
		if ($page < $this->CurPage) {return $page;}
		return $this->CurPage;
	}
	
	/**
	 * 构造函数
	 *
	 * @param int $dataPerPage 每页数据条数
	 * @param int $linkPerPage 下面的链接个数
	 * @param string $pageChar Url字符串
	 */

	public function __construct($dataPerPage = 5, $linkPerPage = 10, $pageChar='page')
	{
		$this->DataPerPage = $dataPerPage;
		$this->LinkPerPage = $linkPerPage;
		$this->PageChar    = $pageChar;
	}
	public function GetWapLinks2($totalData , $urlrewrite = TRUE)
	{
		
		if ($totalData < 0) return '';
		$allPages = ceil($totalData/$this->DataPerPage);
		if ($allPages == 0) return '';
		
		if (isset($_GET[$this->PageChar])) $_GET[$this->PageChar] = $_GET[$this->PageChar];
		$this->CurPage = (isset($_GET[$this->PageChar]) && intval($_GET[$this->PageChar]) > 0)?intval($_GET[$this->PageChar]) : 1;
		$this->CurPage = ($this->CurPage > 0 && $allPages >= $this->CurPage)?$this->CurPage:$allPages;
		$_GET[$this->PageChar] = $this->CurPage;
	
		$goUrl = 'http://'.$_SERVER['SERVER_NAME'].'/'.ltrim($_SERVER['PHP_SELF'], '/');
		// $getStr = ltrim($_SERVER['PHP_SELF'], '/') .'?' . $this->GetUrlJoin();
		//$getStr = substr($_SERVER['PHP_SELF'], 1, -4) .'?' . $this->GetUrlJoin();
		//$getStr = $_SERVER['PHP_SELF'].'?' . $this->GetUrlJoin();
		//$getStr = substr($_SERVER['PHP_SELF'], 1, -4).TEMPLATE_PREFIX .'?' . $this->GetUrlJoin();
		$getStr ='?' . $this->GetUrlJoin();
		$postStr = '?' . $this->GetUrlJoin(false);
		$pageString = '';
		$tmpStr = '';
		if ($this->CurPage < $allPages) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr.($this->CurPage+1)):$getStr.($this->CurPage+1);
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">下页</a> ";
		}
		if ($this->CurPage > 1) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . ($this->CurPage-1)):$getStr . ($this->CurPage-1);
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">上页</a> ";
		}
		if ($this->CurPage != 1) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . "1"):$getStr . "1";
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">首页</a> ";
		}
		if ($this->CurPage != $allPages) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . $allPages):$getStr . $allPages;
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">尾页</a> ";
		}
		$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr):$getStr;
		$tmpStrArr = explode('?',$tmpStr);
		$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
		$pageString .= "{$totalData}个<br/>{$this->CurPage}/{$allPages} 至";
		$pageString .= "<input name=\"page\" value=\"\" size=\"3\" emptyok=\"true\" />页 <anchor title=\"跳页\">跳页<go href=\"{$postStr}\" method=\"get\">";
		$urlParament = array_merge($_GET,$_POST);
		unset($urlParament['sid']);
		unset($urlParament['eid']);
		unset($urlParament['app']);
		unset($urlParament['bro']);
		foreach ($urlParament as $k => $v){
			if ($k <> $this->PageChar)
			$pageString .= "<postfield name=\"$k\" value=\"$v\" />";
		}
		$pageString .= "<postfield name=\"page\" value=\"\$(page)\" /></go></anchor>";
		return $pageString;
	}
	public function GetWapLinks($totalData , $urlrewrite = TRUE)
	{
		
		if ($totalData < 0) return '';
		$allPages = ceil($totalData/$this->DataPerPage);
		if ($allPages == 0) return '';
		
		if (isset($_GET[$this->PageChar])) $_GET[$this->PageChar] = $_GET[$this->PageChar];
		$this->CurPage = (isset($_GET[$this->PageChar]) && intval($_GET[$this->PageChar]) > 0)?intval($_GET[$this->PageChar]) : 1;
		$this->CurPage = ($this->CurPage > 0 && $allPages >= $this->CurPage)?$this->CurPage:$allPages;
		$_GET[$this->PageChar] = $this->CurPage;
	
		$goUrl = 'http://'.$_SERVER['SERVER_NAME'].'/'.ltrim($_SERVER['PHP_SELF'], '/');
		// $getStr = ltrim($_SERVER['PHP_SELF'], '/') .'?' . $this->GetUrlJoin();
		//$getStr = substr($_SERVER['PHP_SELF'], 1, -4) .'?' . $this->GetUrlJoin();
		$getStr = $_SERVER['PHP_SELF'].'?' . $this->GetUrlJoin();
		$pageString = '';
		$tmpStr = '';
		if ($this->CurPage < $allPages) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr.($this->CurPage+1)):$getStr.($this->CurPage+1);
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">下页</a> ";
		}
		if ($this->CurPage > 1) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . ($this->CurPage-1)):$getStr . ($this->CurPage-1);
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">上页</a> ";
		}
		if ($this->CurPage != 1) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . "1"):$getStr . "1";
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">首页</a> ";
		}
		if ($this->CurPage != $allPages) {
			$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . $allPages):$getStr . $allPages;
			$tmpStrArr = explode('?',$tmpStr);
			$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
			$pageString .= "<a href=\"{$tmpStr}\">尾页</a> ";
		}
		$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr):$getStr;
		$tmpStrArr = explode('?',$tmpStr);
		$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
		$pageString .= "{$totalData}个<br/>{$this->CurPage}/{$allPages} 至";
		$pageString .= "<input name=\"page\" value=\"\" size=\"3\" emptyok=\"true\" />页 <anchor title=\"跳页\">跳页<go href=\"{$tmpStr}\" method=\"get\">";
		$urlParament = array_merge($_GET,$_POST);
		unset($urlParament['sid']);
		unset($urlParament['eid']);
		unset($urlParament['app']);
		unset($urlParament['bro']);
		foreach ($urlParament as $k => $v){
			if ($k <> $this->PageChar)
			$pageString .= "<postfield name=\"$k\" value=\"$v\" />";
		}
		$pageString .= "<postfield name=\"page\" value=\"\$(page)\" /></go></anchor>";
		return $pageString;
	}
	
	public function GetHtmlLinks($totalData,$linkType,$urlrewrite = TRUE)
	{
		if ($totalData < 0) return '';
		$allPages = ceil($totalData/$this->DataPerPage);
		if ($allPages == 0) return '';
		
		if (isset($_GET[$this->PageChar])) $_GET[$this->PageChar] = $_GET[$this->PageChar];
		$this->CurPage = (isset($_GET[$this->PageChar]) && intval($_GET[$this->PageChar]) > 0)?intval($_GET[$this->PageChar]) : 1;
		$this->CurPage = ($this->CurPage > 0 && $allPages >= $this->CurPage)?$this->CurPage:$allPages;
		$_GET[$this->PageChar] = $this->CurPage;
	
		$goUrl = 'http://'.$_SERVER['SERVER_NAME'].'/'.ltrim($_SERVER['PHP_SELF'], '/');
		// $getStr = ltrim($_SERVER['PHP_SELF'], '/') .'?' . $this->GetUrlJoin();
		$getStr = substr($_SERVER['PHP_SELF'], 1, -4).TEMPLATE_PREFIX .'?' . $this->GetUrlJoin();
		$postStr = substr($_SERVER['PHP_SELF'], 1, -4).TEMPLATE_PREFIX .'?' . $this->GetUrlJoin();
		$pageString = '';
		$tmpStr = '';
		switch ($linkType)
		{
			case 1:
				if ($this->CurPage < $allPages) {
					$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr.($this->CurPage+1)):$getStr.($this->CurPage+1);
					$tmpStrArr = explode('?',$tmpStr);
					$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
					$pageString .= "<a href=\"{$tmpStr}\">下页</a> ";
				}
				if ($this->CurPage > 1) {
					$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . ($this->CurPage-1)):$getStr . ($this->CurPage-1);
					$tmpStrArr = explode('?',$tmpStr);
					$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
					$pageString .= "<a href=\"{$tmpStr}\">上页</a> ";
				}
				if ($this->CurPage != 1) {
					$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . "1"):$getStr . "1";
					$tmpStrArr = explode('?',$tmpStr);
					$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
					$pageString .= "<a href=\"{$tmpStr}\">首页</a> ";
				}
				if ($this->CurPage != $allPages) {
					$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . $allPages):$getStr . $allPages;
					$tmpStrArr = explode('?',$tmpStr);
					$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
					$pageString .= "<a href=\"{$tmpStr}\">尾页</a> ";
				}
				$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr):$getStr;
				
				$pageString .= "{$totalData}个<br/>{$this->CurPage}/{$allPages} 至";
				$pageString .= "<form name=\"page\" method=\"get\" action=\"".$postStr."\"><input name=\"page\" value=\"\" size=\"3\"  />页 ";
				$urlParament = array_merge($_GET,$_POST);
				unset($urlParament['sid']);
				unset($urlParament['eid']);
				unset($urlParament['app']);
				unset($urlParament['bro']);
				foreach ($urlParament as $k => $v){
					if ($k <> $this->PageChar)
					$pageString .= "<input name=\"".$k."\" type=\"hidden\" value=\"".$v."\">";
				}
				$pageString .= "<input type=\"submit\" value=\"跳页\"/></form>";
				break;
			case 2:
				$tmpPostStrArr = explode('?',$postStr);
				$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
				$pageString .= "<form name=\"page\" method=\"get\" action=\"".$postStr."\"> ";
				$urlParament = array_merge($_GET,$_POST);
				unset($urlParament['sid']);
				unset($urlParament['eid']);
				unset($urlParament['app']);
				unset($urlParament['bro']);
				foreach ($urlParament as $k => $v){
					if ($k <> $this->PageChar)
					$pageString .= "<input name=\"".$k."\" type=\"hidden\" value=\"".$v."\">";
				}
				if ($this->CurPage > 1) {
					$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr . ($this->CurPage-1)):$getStr . ($this->CurPage-1);
					$tmpStrArr = explode('?',$tmpStr);
					$tmpStr = $tmpStrArr[0].TEMPLATE_PREFIX.'?'.$tmpStrArr[1];
					$pageString .= "<a href=\"{$tmpStr}\"><img src=\"".PROJECT_ASSET."/hot/images/prev.gif\"  alt=\"上一页\"/></a> ";
				}
				$pageString .= '<select name="page" onchange="this.form.submit()">';
				for($i=1;$i<=$allPages;$i++)
				{
					if($this->CurPage==$i)
					{
						$pageString .= '<option value="'.$i.'" selected>&nbsp;&nbsp;第'.$i.'页&nbsp;&nbsp;</option>';
					}
					else
					{
						$pageString .= '<option value="'.$i.'" >&nbsp;&nbsp;第'.$i.'页&nbsp;&nbsp;</option>';
					}
				}
				$pageString .= '</select>';
				if ($this->CurPage < $allPages) {
					$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr.($this->CurPage+1)):$getStr.($this->CurPage+1);
					$tmpStrArr = explode('?',$tmpStr);
					$tmpStr = $tmpStrArr[0].'.html?'.$tmpStrArr[1];
					$pageString .= "<a href=\"{$tmpStr}\"><img src=\"".PROJECT_ASSET."/hot/images/next.gif\" alt=\"下一页\"/></a> ";
				}
				$pageString .='</form>';
				//$tmpStr = ($urlrewrite)?Waptw_Util_UrlRewrite::Get($getStr):$getStr;
				break;
		}
				
		return $pageString;
	}
	
	/**
	 * 取得分页
	 *
	 * @param int $totalData
	 * @return string
	 */
	public function GetPageLinks($totalData)
	{
		if ($totalData < 0) return '';
		$this->CurPage = (isset($_GET[$this->PageChar]) && intval($_GET[$this->PageChar]) > 0) ? intval($_GET[$this->PageChar]) : 1;
		$_GET[$this->PageChar] = $this->CurPage;
		
		$allPages = ceil($totalData/$this->DataPerPage);
		if ($allPages == 0) return '';
		if ($this->CurPage < 1) $this->CurPage = 1;
		if ($this->CurPage > $allPages) $this->CurPage = $allPages;
		
		$halfLinkPage = intval($this->LinkPerPage/2);
		$start = $this->CurPage - $halfLinkPage;
		$start = ($start < 1) ? 1 : $start;
		$end   = $this->CurPage + $halfLinkPage;
		$end   = ($end > $allPages) ? $allPages : $end;
		
		
		$overpage = $this->LinkPerPage - 1 - $end + $start;
		if ( $this->LinkPerPage != 0)
		{
			if ($end != $allPages) {
				$end = ($end + $overpage > $allPages) ? $allPages : 
	$end + $overpage;
			}
			if ($start != 1) {
				$start = ($start - $overpage < 1) ? 1 : $start - 
	$overpage;
			}	
		}
		
		$end   += 1;
		$getStr = $this->GetUrlJoin();
		
		$pageString = "<div class=\"pageLinkNavigate\"><ul>";
		if ($this->CurPage > 1)
			$pageString .= "<li class=\"prevpage\"><a href=\"?$getStr" . 
	($this->CurPage - 1) ."\" target=\"_self\">上一页</a></li>";
			
		if ($start > 3)
		{
			$pageString .= "<li><a href=\"?{$getStr}1\" target=\"_self\">1</a></li>";
			$pageString .= "<li class=\"linkdot\">. . .</li>";
		}
		
		for ($i = $start; $i < $end; $i++)
		{
			if ($this->CurPage == $i)
			{
				$pageString .= "<li class=\"currentpage\">{$i}</li>";
				continue;
			}
			$pageString .= "<li><a href=\"?$getStr{$i}\" target=\"_self\">{$i}</a></li>";
		}
		
		if ($end - 1 < $allPages)
		{
			$pageString .= "<li class=\"linkdot\">. . .</li>";
			$pageString .= "<li><a href=\"?{$getStr}
	$allPages\" target=\"_self\">$allPages</a></li>";
		}
		
		if ($this->CurPage < $allPages)
			$pageString .= "<li class=\"nextpage\"><a href=\"?$getStr" . 
	($this->CurPage + 1) ."\" target=\"_self\">下一页</a></li>";
		$pageString .= "</ul>";
		$pageString .= "<input type=\"text\" size=\"3\" name=\"page\" onkeydown=\"javascript: if(event.keyCode==13){ location='?".$getStr."'+this.value+'';return false;}\"><button onclick=\"javascript:  location='?".$getStr."'+this.previousSibling.value+'';return false;\">Go</button>";
		$pageString .= "</div>";
		return $pageString;
	}
	
	/**
	 * 取得URL字串
	 *
	 * @return unknown
	 */
	public function GetUrlJoin($withchar = true)
	{
		$getStr = '';
		$urlParament = $_GET;
		unset($urlParament['sid']);
		unset($urlParament['eid']);
		unset($urlParament['app']);
		unset($urlParament['bro']);
		foreach ($urlParament as $key => $value)
		{
			if ($this->PageChar == $key) continue;
			$getStr .= $key . '=' . $value . '&amp;';
		}
		if ($withchar)
		$getStr .= $this->PageChar . '=';
		return $getStr;
		//$_SERVER["QUERY_STRING"]
	}
	
	/**
	 * 使用分页类需要用到的CSS
	 *
	 * @return unknown
	 */
	public function GetCss()
	{
		return ".pageLinkNavigate ul, .pageLinkNavigate li { list-style:none; float:left;}
.pageLinkNavigate { float:left; }
.pageLinkNavigate li { border:1px solid #6CF; margin:0 3px;}
.pageLinkNavigate .prevpage a, .pageLinkNavigate .nextpage a { font-size:12px; width:45px; text-align:center; line-height:19px;}
.pageLinkNavigate li.currentpage, .pageLinkNavigate a, .pageLinkNavigate .linkdot { text-decoration:none; padding:1px 4px; display:block;}
.pageLinkNavigate li.currentpage, .pageLinkNavigate .linkdot { border:none;}
.pageLinkNavigate a:hover { background-color:#C96;}";
	}
}
?>