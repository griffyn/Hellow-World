<?php
/**
 * 站内分页类,主要提供分页
 *
 * @author wangjun
 * @package Util
 * @copyright UC
 */
if (! defined ( 'TEMPLATE_PREFIX' )) {
	define ( 'TEMPLATE_PREFIX', '.html' );
}
class Waptw_Util_PageNew {
	//
	private $account = null;
	//页数
	private $page = 1;
	//每页数据数
	private $size = 20;
	//总页数
	private $total = null;
	//每页显示页码列表数
	private $numPrePage = 6;
	//url参数
	private $params = null;
	//总页数
	private $allPages = 1;
	//翻页输出
	private $pageString = null;
	//是否重定向
	private $urlrewrite = 1;
	//翻页样式类型
	private $linkType = 1;
	//页数变量名
	private $pageChar = null;
	
	/**
	 *
	 * 构造函数
	 * @param array $parames
	 * @author wangjun
	 * @return void
	 */
	public function __construct(array $parames = array()) {
		$this->page = $parames ['page'] ? $parames ['page'] : Ucweb_Http_Input::GetByInt ( 'page', 1 );
		$this->size = $parames ['size'] ? $parames ['size'] : Ucweb_Http_Input::GetByInt ( 'size', 20 );
		$this->total = $parames ['total'] ? $parames ['total'] : Ucweb_Http_Input::GetByInt ( 'total', 0 );
		$this->params = $parames ['params'] ? $parames ['params'] : Ucweb_Http_Input::GetByString ( 'params', '' );
		$this->urlrewrite = $parames ['urlrewrite'] ? $parames ['urlrewrite'] : Ucweb_Http_Input::GetByInt ( 'urlrewrite', 1 );
		$this->linkType = $parames ['linkType'] ? $parames ['linkType'] : Ucweb_Http_Input::GetByInt ( 'linkType', 1 );
		$this->pageChar = $parames ['pageChar'] ? $parames ['pageChar'] : Ucweb_Http_Input::GetByString ( 'pageChar', 'page' );
	}
	/**
	 * 翻页
	 *
	 * @return string
	 */
	public function GetPage() {
		if ($this->total < 0)
			return '';
		$this->allPages = ceil ( $this->total / $this->size );
		if ($this->allPages < 1)
			return '';
		$this->page = ($this->page > 0 && $this->allPages >= $this->page) ? $this->page : $this->allPages;
		$urlArr = explode ( "/", $_SERVER ['REQUEST_URI'] );
		$aParames = explode ( "?", $_SERVER ['REQUEST_URI'] );
		
		$i_begin = (ceil($this->page/$this->numPrePage)-1)*$this->numPrePage+1;
		$i_end = ceil($this->page/$this->numPrePage)*$this->numPrePage;
		switch ($this->linkType) {
			case 4 :
				$urlParams = $this->getRoute ();
				$getStr = $urlParams ['pre'];
				$sParames = $urlParams ['next'];
				break;
			default :
				if ($aParames [1]) {
					$sParames = "/?" . $aParames [1];
				} else {
					$sParames = "";
				}
				$urlParams = ($urlArr [5] ? $urlArr [5] : "main") . "/" . ($urlArr [6] ? $urlArr [6] : "index") . "/";
				$getStr = $urlParams . "/" . $this->params . "/";
				$postStr = Waptw_Util_UrlRewrite::Get ( $getStr );
				break;
		}
		$this->pageString = '';
		$tmpStr = '';
		switch ($this->linkType) {
			case 1 :
				if ($this->page < $this->allPages) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . ($this->page + 1) ) . $sParames : $getStr . (($this->page + 1)) . $sParames;
					$this->pageString .= "<a href=\"{$tmpStr}\">下页</a> ";
				}
				if ($this->page > 1) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . ($this->page - 1) ) . $sParames : $getStr . (($this->page - 1)) . $sParames;
					$this->pageString .= "<a href=\"{$tmpStr}\">上页</a> ";
				}
				
				if ($this->page != 1) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . "1" ) . $sParames : $getStr . "1" . $sParames;
					$this->pageString .= "<a href=\"{$tmpStr}\">首页</a> ";
				}
				if ($this->page != $this->allPages) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . $this->allPages ) . $sParames : $getStr . $this->allPages . $sParames;
					$this->pageString .= "<a href=\"{$tmpStr}\">尾页</a> ";
				}
				$this->pageString .= $this->pageString ? "<br/>" : '';
				$this->pageString .= "共{$this->total}个 第{$this->page}/{$this->allPages}<br/>";
				$this->pageString = str_replace ( "&", "&amp;", $this->pageString );
				break;
			case 2 :
				$tmpPostStrArr = explode ( '?', $postStr );
				$tmpStr = $tmpPostStrArr [0] . TEMPLATE_PREFIX . '?' . $tmpPostStrArr [1];
				$this->pageString .= "<form name=\"page\" method=\"get\" action=\"" . $postStr . "\"> ";
				$urlParament = array_merge ( $_GET, $_POST );
				unset ( $urlParament ['sid'] );
				unset ( $urlParament ['eid'] );
				unset ( $urlParament ['app'] );
				unset ( $urlParament ['bro'] );
				foreach ( $urlParament as $k => $v ) {
					if ($k != $this->pageChar)
						$this->pageString .= "<input name=\"" . $k . "\" type=\"hidden\" value=\"" . $v . "\">";
				}
				if ($this->page > 1) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . ($this->page - 1) ) : $getStr . ($this->page - 1);
					$tmpStrArr = explode ( '?', $tmpStr );
					$tmpStr = $tmpStrArr [0] . TEMPLATE_PREFIX . '?' . $tmpStrArr [1];
					$this->pageString .= "<a href=\"{$tmpStr}\"><img src=\"" . PROJECT_ASSET . "/hot/images/prev.gif\"  alt=\"上一页\"/></a> ";
				}
				$this->pageString .= '<select name="page" onchange="this.form.submit()">';
				for($i = 1; $i <= $this->allPages; $i ++) {
					if ($this->page == $i) {
						$this->pageString .= '<option value="' . $i . '" selected>&nbsp;&nbsp;第' . $i . '页&nbsp;&nbsp;</option>';
					} else {
						$this->pageString .= '<option value="' . $i . '" >&nbsp;&nbsp;第' . $i . '页&nbsp;&nbsp;</option>';
					}
				}
				$this->pageString .= '</select>';
				if ($this->page < $this->allPages) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . ($this->page + 1) ) : $getStr . ($this->page + 1);
					$tmpStrArr = explode ( '?', $tmpStr );
					$tmpStr = $tmpStrArr [0] . '.html?' . $tmpStrArr [1];
					$this->pageString .= "<a href=\"{$tmpStr}\"><img src=\"" . PROJECT_ASSET . "/hot/images/next.gif\" alt=\"下一页\"/></a> ";
				}
				$this->pageString .= '</form>';
				break;
			case 3 :
				$this->pageString = '<div class="pagebox">';
				if ($this->page < $this->allPages) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . ($this->page + 1) ) . $sParames : $getStr . (($this->page + 1)) . $sParames;
					$this->pageString .= '<span class="btn-gr3"><a href="' . $tmpStr . '">下一页</a></span>';
				}
				if ($this->page > 1) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . ($this->page - 1) ) . $sParames : $getStr . (($this->page - 1)) . $sParames;
					$this->pageString .= '<span class="btn-gr3"><a href="' . $tmpStr . '">上一页</a></span>';
				}
				if ($this->page != 1) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . "1" ) . $sParames : $getStr . "1" . $sParames;
					$this->pageString .= '<span class="btn-gr3"><a href="' . $tmpStr . '">首&nbsp;&nbsp;页</a></span>';
				}
				if ($this->page != $this->allPages) {
					$tmpStr = ($this->urlrewrite) ? Waptw_Util_UrlRewrite::Get ( $getStr . $this->allPages ) . $sParames : $getStr . $this->allPages . $sParames;
					$this->pageString .= '<span class="btn-gr3"><a href="' . $tmpStr . '">末&nbsp;&nbsp;页</a></span>';
				}
				$this->pageString .= '<div class="jump">当前' . $this->page . '/' . $this->allPages . '页 共' . $this->total . '个</div>';
				$this->pageString .= '</div>';
				break;
			case 4 :
				$this->pageString = '<div class="G-pagebar fr">';
				if ($this->page != 1) {
					$this->pageString .= "<a href=\"/" .$getStr. $sParames . "\">首页</a>";
				} else {
					$this->pageString .= "<span>首页</a></span>";
				}
				if ($this->page > 1) {
					$this->pageString .= "<a href=\"/" .$getStr. ($urlParams['page']-1). $sParames  . "\">上一页</a>";
				} else {
					$this->pageString .= "<span>上一页</span>";
				}
//				for($i = $i_begin; $i <= $i_end; $i ++) {
//					if($i<=$this->allPages){
//						if ($this->page == $i) {
//							$this->pageString .= "<span class=\"on\">". $i . "</span>\n";
//						}
//						else{
//							$this->pageString .= "<a href=\"/" .$getStr. $i. $sParames . "\">" . $i . "</a>\n";
//						}
//					}
//				}
				//pc站翻页处理，如果小于6页 或者 大于6页并且当前页小于3页，则直接显示第一页到第六页或者最后一页
				if ($this->allPages <= 6 || ($this->allPages > 6 && $this->page<=3) ) {
					$j = ($this->allPages >=6) ? 6 : $this->allPages;
					for($i=1; $i <= $j; $i++){
						if ($this->page == $i) {
							$this->pageString .= "<span class=\"on\">". $i . "</span>";
						}
						else {
							$this->pageString .= "<a href=\"/" .$getStr. $i. $sParames . "\">" . $i . "</a>";
						}
					}
				}
				//如果当前页是倒数最后四页，则直接显示后面6页
				elseif(($this->allPages - $this->page) <= 3){
					for($i = $this->allPages -6 +1; $i <= $this->allPages; $i++){
						if ($this->page == $i) {
							$this->pageString .= "<span class=\"on\">". $i . "</span>";
						}
						else {
							$this->pageString .= "<a href=\"/" .$getStr. $i. $sParames . "\">" . $i . "</a>";
						}
					}
				}
				//其他情况，均取当前页的前两页到当前页的后三页这六页
				else{
					$j = $this->page +3;
					for($i = $this->page -2; $i <= $this->page +3; $i++){
						if ($this->page == $i) {
							$this->pageString .= "<span class=\"on\">". $i . "</span>";
						}
						else {
							$this->pageString .= "<a href=\"/" .$getStr. $i. $sParames . "\">" . $i . "</a>";
						}
					}
				}
				if ($this->page < $this->allPages) {
					$this->pageString .= "<a href=\"/" .$getStr.($urlParams['page']+1). $sParames . "\">下一页</a>";
				} else {
					$this->pageString .= "<span>下一页</span>";
				}
				if ($this->page != $this->allPages) {
					$this->pageString .= "<a href=\"/" .$getStr.$this->allPages. $sParames . "\">末页</a>";
				} else {
					$this->pageString .= "<span>末页</span>";
				}
				$this->pageString .= "<span class=\"pages\">第".$this->page."/".$this->allPages." 页</span></div>";
				break;

		}
		return $this->pageString;
	}
	/**
	 * 取得开始页面
	 *
	 * @return int
	 */
	public function GetStart() {
		return $this->page;
	}
	/**
	 * 获取路由
	 * 
	 * @return array $result
	 */
	private function getRoute() {
		$s_route = '';
		$i_page = 0;
		$a_route = array ();
		$find_num = 0;
		foreach ( $this->params as $s_pKey => $s_pVal ) {
			
			if ('page' == $s_pKey) {
				$find_num = 1;
				$result ['page'] = $s_pVal;
				continue;
			}
			if ($find_num == 0 ) {
				$result ['pre'] .= $s_pVal.'/';
			} else {
				$result ['next'] = $s_pVal;
			}
		}
		return $result;
	}
}

?>