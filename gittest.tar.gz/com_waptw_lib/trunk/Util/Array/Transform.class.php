<?php
class Waptw_Util_Array_Transform {

	/**
	 * 格式化为xml数据
	 *
	 * @param array $data
	 * @param string $version
	 * @param string $encode
	 * @return string
	 */
	static public function ToXml(array $data,array $arrCdata=array(),$version = '1.0',$encode = 'utf-8'){
		$xmlData = '';
		$xmlHeader = '<?xml version="'.$version.'" encoding="'.$encode.'" ?>';
		$xmlFooter = '';
		foreach ($arrCdata as $key=>$val)
			$arrCdata[$key]--;
	
		if (is_array($data) && 0 <  count($data)) {
			foreach ($data as $k => $v) {
				if (is_array($v)) {
					$xmlData .= "<$k>".self::_xml($v,$arrCdata)."</$k>";
				}else {
					$isCData = isset($arrCdata[$k]) && ($arrCdata[$k]==0);
					$xmlData .= "<$k>".self::_xmlValue($k,$v,$isCData)."</$k>";
				}
			}
			return $xmlHeader.$xmlData.$xmlFooter;
		}else {
			return $xmlHeader;
		}
	}

	/**
	 * array格式化为xml方法,迭代遍历数组
	 *
	 * @param array $data
	 * @return string
	 */
	private function _xml(array $data = array(),array $arrCdata=array()){
		if (count($data) <= 0) {return NULL ;}
		foreach ($arrCdata as $key=>$val)
			$arrCdata[$key]--;
		foreach ($data as $k => $v) {
			$k = self::_xmlKey($k);
			if (is_array($v)) {
				$xmlData .= "<$k>".self::_xml($v,$arrCdata)."</$k>";
			}else {
				$isCData = isset($arrCdata[$k]) && ($arrCdata[$k]==0);
				$xmlData .= "<$k>".self::_xmlValue($k,$v,$isCData )."</$k>";
			}
		}
		return $xmlData;
	}

	/**
	 * 检查xml key的有效性质
	 *
	 * @param string $key
	 * @return string
	 */
	private function _xmlKey($key){
		//$str = str_replace('(*)','',$str);
		if (is_int($key))
		return 'row_'.$key;
		return $key;
	}

	/**
	 * xml变量检查方法
	 *
	 * @param string $key
	 * @param string $value
	 * @return string
	 */
	private function _xmlValue($key,$value = NULL,$isCdata=false){
		//&amp; & 和号 第一步，一定第一步
		//&apos; ' 省略号
		//&quot; " 引号
		//&gt; > 大于
		//&lt; < 小于
		$value = str_replace('>','&gt;',str_replace('<','&lt;',str_replace('"','&quot;',str_replace("'",'&apos;',str_replace('&','&amp;',$value)))));
		if ($isCdata) {
			return '<![CDATA['.$value.']]>';
		}else {
			return $value;
		}
	}

	/**
	 * 将数组转为serialize格式
	 *
	 * @param string $data
	 * @return serialize
	 */
	static public function ToSerialize(array $data){
		return serialize($data);
	}

	/**
	 * Enter description here...
	 *
	 * @param unknown_type $data
	 * @return unknown
	 */
	static public function ToJson(array $data){
		return json_encode($data);
	}


	/**
	 * Enter description here...
	 *
	 * @param unknown_type $data
	 * @return unknown
	 */
	static public function ToHessian(array $data){
		return $data;
	}

	static public function ToString(array $data){
		return print_r($data,true);
	}
	
	/**
	 * 转换成Ini文件内容
	 *
	 * @param array $data
	 */
	static public  function ToIni(array $data)
	{
		$strContent="";
		foreach ($data as $sectionKey=>$sectionVal)
		{
			if(is_array($sectionVal))//section 
			{
				$strContent.="[{$sectionKey}]\r\n";
				foreach ($sectionVal as $Key=>$Val)
				{
					if(!is_array($Val)) $strContent.="{$Key}={$Val}\r\n";
				}
				$strContent.="\r\n";
			}	
		}
		return $strContent;	
	}
}