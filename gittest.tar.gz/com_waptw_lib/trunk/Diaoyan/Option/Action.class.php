<?php
/**
 * 调研选项动作层
 * 
 * @package	Diaoyan
 * @author	mayong
 * @version 20100603
 *
 */
class Waptw_Diaoyan_Option_Action {
	private $_optionModel;
	
	/**
	 * 初始化
	 *
	 * @param unknown_type $option
	 */
	public function __construct($option = array()){
		$this->_optionModel = new Waptw_Diaoyan_Option_Model();
		
		$this->_optionModel->setIdx(Ucweb_Http_Input::GetByInt('id',0));
		$this->_optionModel->setTitle(Ucweb_Http_Input::Admin('title'));
		$this->_optionModel->setQuestionId(Ucweb_Http_Input::GetByInt('questionid',0));
		$this->_optionModel->setOrderNum(Ucweb_Http_Input::GetByInt('orderNum',0));
		$this->_optionModel->setInsertDate(Ucweb_Http_Input::GetByInt('insertDate',0));
		
		$this->_optionModel->setAction(Ucweb_Http_Input::GetByString('action','list'));
		$this->_optionModel->setKeyword(Ucweb_Http_Input::GetByString('keyword',''));
		$this->_optionModel->setPage(Ucweb_Http_Input::GetByInt('page',1));
		$this->_optionModel->setSize(Ucweb_Http_Input::GetByInt('size',10));
		$this->_optionModel->setOrder(Ucweb_Http_Input::GetByString('order',''));
		$this->_optionModel->setCache(Ucweb_Http_Input::GetByInt('cache',0));
		$this->_optionModel->setField(Ucweb_Http_Input::GetByString('field',''));
		
		if(array_key_exists('id',$option)){ $this->_optionModel->setIdx($option['id']);}
		if(array_key_exists('title',$option)){ $this->_optionModel->setTitle($option['title']);}
		if(array_key_exists('questionid',$option)){ $this->_optionModel->setQuestionId($option['questionid']);}
		if(array_key_exists('orderNum',$option)){ $this->_optionModel->setOrderNum($option['orderNum']);}
		if(array_key_exists('insertDate',$option)){ $this->_optionModel->setInsertDate($option['insertDate']);}
		
		if(array_key_exists('action',$option)){ $this->_optionModel->setAction($option['action']);}
		if(array_key_exists('keyword',$option)){ $this->_optionModel->setKeyword($option['keyword']);}
		if(array_key_exists('page',$option)){ $this->_optionModel->setPage($option['page']);}
		if(array_key_exists('size',$option)){ $this->_optionModel->setSize($option['size']);}
		if(array_key_exists('order',$option)){ $this->_optionModel->setOrder($option['order']);}
		if(array_key_exists('cache',$option)){ $this->_optionModel->setCache($option['cache']);}
		if(array_key_exists('field',$option)){ $this->_optionModel->setField($option['field']);}
		
	}
	
	/**
	 * 返回模型
	 *
	 * @return unknown
	 */
	public function GetModel(){
		return  $this->_optionModel;
	}
	
	/**
	 * 添加数据
	 *
	 * @return unknown
	 */
	public function Insert(){
		$this->Clear();
		return  $this->_optionModel->Insert();
	}
	
	/**
	 * 修改数据
	 *
	 * @return unknown
	 */
	public function Edit(){
		$this->Clear();
		return  $this->_optionModel->Edit();
	}
	
	/**
	 * 删除数据
	 *
	 * @return unknown
	 */
	public function Del(){
		$this->Clear();
		return  $this->_optionModel->Del();
	}
	
	/**
	 * 计算总数
	 *
	 * @return unknown
	 */
	public function Count(){
		return  $this->_optionModel->Count();
	}
	
	/**
	 * 获取列表
	 *
	 * @return unknown
	 */
	public function Get(){
		return  $this->_optionModel->Get();
	}
	
	/**
	 * 清除缓存
	 *
	 */
	public function Clear(){
		$this->_optionModel->Clear();
	}
}