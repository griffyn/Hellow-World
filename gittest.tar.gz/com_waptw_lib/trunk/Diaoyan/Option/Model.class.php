<?php
/**
 * 调研选项模型层
 * @package	Waptw_Diaoyan
 * @author	mayong
 * @version 20100603
 *
 */
class Waptw_Diaoyan_Option_Model extends Waptw_Diaoyan_Option_Cache {
	
	private $_idx = null;
	private $_title = null;
	private $_questionId = null;
	private $_orderNum = null;
	private $_insertDate = null;
	
	private $_action = null;
	private $_keyword = null;
	private $_page = NULL;
	private $_size = NULL;
	private $_order = NULL;
	private $_cache = NULL;
	private $_field = NULL;

	/**
	 * 添加数据
	 *
	 * @return unknown
	 */
	public  function Insert(){
		$data['title'] = $this->_title;
		$data['questionId'] = $this->_questionId;
		$data['insertDate'] = time();
		
		$idx = parent::_insert($data);
		return $idx;
	}
	
	/**
	 * 修改数据
	 *
	 * @return unknown
	 */
	public function Edit(){
		if (!$this->_idx){
			throw new Waptw_Diaoyan_Option_Exception(__METHOD__.' => idx is null');
			return FALSE;
		}
		$target['where'] = ' idx='.$this->_idx;
		
		$data['title'] = $this->_title;
		$data['questionId'] = $this->_questionId;
		$result = parent::_edit($data, $target);
		return $result;
	}
	
	/**
	 * 删除数据
	 *
	 * @return unknown
	 */
	public function Del(){
		if (!$this->_idx){
				throw new Waptw_Diaoyan_Option_Exception(__METHOD__.' => idx is null');
				return FALSE;
		}
		$target['where'] = ' idx='.$this->_idx;

		$result = parent::_del($target);
		return $result;	
	}

	/**
	 * 计算总数
	 *
	 * @return unknown
	 */
	public   function Count(){
		$target['where'] = ' idx != 0 ';
		if ($this->_keyword){ $target['where'] .= " and title like ('%".$this->_keyword."%')"; }
		if ($this->_questionId){ $target['where'] .= ' and questionId = '.$this->_questionId; }
		if ($this->_cache){ $target['cache'] = $this->_cache; }
		
		$result = parent::_count($target);
		return $result;
	}

	/**
	 * 获取列表
	 *
	 * @return unknown
	 */
	public function Get(){
		$target['where'] = ' idx!= 0 ';
		if ($this->_idx){ $target['where'] .= ' and idx = '.$this->_idx; }
		if ($this->_questionId){ $target['where'] .= ' and questionId in ( '.$this->_questionId.')'; }
		if ($this->_keyword){ $target['where'] .= " and title like ('%".$this->_keyword."%')"; }
		
		if ($this->_page){ $target['page'] = $this->_page; }
		if ($this->_size){ $target['size'] = $this->_size; }
		if ($this->_order){ $target['order'] = $this->_order; }
		if ($this->_cache){ $target['cache'] = $this->_cache; }
		$result = parent::_get($target);
		return $result;
	}
	
	/**
	 * 清除缓存
	 *
	 * @return unknown
	 */
	public function Clear(){
		parent::_clear();
	}
	
	/**
	 * @return the $_idx
	 */
	public function getIdx() {
		return $this->_idx;
	}

	/**
	 * @param $_idx the $_idx to set
	 */
	public function setIdx($_idx) {
		$this->_idx = $_idx;
	}
	
	/**
	 * @return the $_title
	 */
	public function getTitle() {
		return $this->_title;
	}

	/**
	 * @param $_title the $_title to set
	 */
	public function setTitle($_title) {
		$this->_title = $_title;
	}
	
	/**
	 * @param $_questionId the $_questionId to set
	 */
	public function setQuestionId($_questionId) {
		$this->_questionId = $_questionId;
	}
	
	/**
	 * @return the $_questionId
	 */
	public function getQuestionId() {
		return $this->_questionId;
	}
	
	/**
	 * @param $_questionId the $_questionId to set
	 */
	public function setOrderNum($_orderNum) {
		$this->_orderNum = $_orderNum;
	}
	
	/**
	 * @return the $_questionId
	 */
	public function getOrderNum() {
		return $this->_orderNum;
	}

	/**
	 * @param $_insertDate the $_insertDate to set
	 */
	public function setInsertDate($_insertDate) {
		$this->_insertDate = $_insertDate;
	}
	
	/**
	 * @return the $_insertDate
	 */
	public function getInsertDate() {
		return $this->_insertDate;
	}
	
	/**
	 * @return the $_page
	 */
	public function getPage() {
		return $this->_page;
	}

	/**
	 * @return the $_size
	 */
	public function getSize() {
		return $this->_size;
	}

	/**
	 * @return the $_order
	 */
	public function getOrder() {
		return $this->_order;
	}

	/**
	 * @return the $_cache
	 */
	public function getCache() {
		return $this->_cache;
	}

	/**
	 * @return the $_field
	 */
	public function getField() {
		return $this->_field;
	}

	/**
	 * @param $_page the $_page to set
	 */
	public function setPage($_page) {
		$this->_page = $_page;
	}

	/**
	 * @param $_size the $_size to set
	 */
	public function setSize($_size) {
		$this->_size = $_size;
	}

	/**
	 * @param $_order the $_order to set
	 */
	public function setOrder($_order) {
		$this->_order = $_order;
	}

	/**
	 * @param $_cache the $_cache to set
	 */
	public function setCache($_cache) {
		$this->_cache = $_cache;
	}

	/**
	 * @param $_field the $_field to set
	 */
	public function setField($_field) {
		$this->_field = $_field;
	}
	/**
	 * @return the $_action
	 */
	public function getAction() {
		return $this->_action;
	}

	/**
	 * @param $_action the $_action to set
	 */
	public function setAction($_action) {
		$this->_action = $_action;
	}
	
	/**
	 * @return the $_action
	 */
	public function getKeyword() {
		return $this->_keyword;
	}

	/**
	 * @param $_action the $_action to set
	 */
	public function setKeyword($_keyword) {
		$this->_keyword = $_keyword;
	}


}