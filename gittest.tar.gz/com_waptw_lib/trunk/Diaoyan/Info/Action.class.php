<?php
/**
 * 调研信息动作层
 * 
 * @package	Diaoyan
 * @author	mayong
 * @version 20100603
 *
 */
class Waptw_Diaoyan_Info_Action {
	private $_infoModel;
	
	/**
	 * 初始化
	 *
	 * @param unknown_type $option
	 */
	public function __construct($option = array()){
		$this->_infoModel = new Waptw_Diaoyan_Info_Model();
		
		$this->_infoModel->setIdx(Ucweb_Http_Input::GetByInt('id',0));
		$this->_infoModel->setTitle(Ucweb_Http_Input::Admin('title'));
		$this->_infoModel->setDescript(Ucweb_Http_Input::Admin('descript'));
		$this->_infoModel->setStartDate(Ucweb_Http_Input::GetByString('startdate',0));
		$this->_infoModel->setEndDate(Ucweb_Http_Input::GetByString('enddate',0));
		$this->_infoModel->setInsertDate(Ucweb_Http_Input::GetByInt('insertDate',0));
		
		$this->_infoModel->setT(Ucweb_Http_Input::GetByInt('t',time()));		
		$this->_infoModel->setAction(Ucweb_Http_Input::GetByString('action','list'));
		$this->_infoModel->setKeyword(Ucweb_Http_Input::GetByString('keyword',''));
		$this->_infoModel->setPage(Ucweb_Http_Input::GetByInt('page',1));
		$this->_infoModel->setSize(Ucweb_Http_Input::GetByInt('size',10));
		$this->_infoModel->setOrder(Ucweb_Http_Input::GetByString('order',''));
		$this->_infoModel->setCache(Ucweb_Http_Input::GetByInt('cache',0));
		$this->_infoModel->setField(Ucweb_Http_Input::GetByString('field',''));
		
		if(array_key_exists('id',$option)){ $this->_infoModel->setIdx($option['id']);}
		if(array_key_exists('title',$option)){ $this->_infoModel->setTitle($option['title']);}
		if(array_key_exists('descript',$option)){ $this->_infoModel->setDescript($option['descript']);}
		if(array_key_exists('startdate',$option)){ $this->_infoModel->setStartDate($option['startdate']);}
		if(array_key_exists('startdate',$option)){ $this->_infoModel->setEndDate($option['startdate']);}
		if(array_key_exists('enddate',$option)){ $this->_infoModel->setInsertDate($option['enddate']);}
		
		if(array_key_exists('t',$option)){ $this->_infoModel->setT($option['t']);}
		if(array_key_exists('action',$option)){ $this->_infoModel->setAction($option['action']);}
		if(array_key_exists('keyword',$option)){ $this->_infoModel->setKeyword($option['keyword']);}
		if(array_key_exists('page',$option)){ $this->_infoModel->setPage($option['page']);}
		if(array_key_exists('size',$option)){ $this->_infoModel->setSize($option['size']);}
		if(array_key_exists('order',$option)){ $this->_infoModel->setOrder($option['order']);}
		if(array_key_exists('cache',$option)){ $this->_infoModel->setCache($option['cache']);}
		if(array_key_exists('field',$option)){ $this->_infoModel->setField($option['field']);}
		
	}
	
	/**
	 * 返回模型
	 *
	 * @return unknown
	 */
	public function GetInfoModel(){
		return  $this->_infoModel;
	}
	
	/**
	 * 添加数据
	 *
	 * @return unknown
	 */
	public function Insert(){
		$this->Clear();
		return  $this->_infoModel->Insert();
	}
	
	/**
	 * 修改数据
	 *
	 * @return unknown
	 */
	public function Edit(){
		$this->Clear();
		return  $this->_infoModel->Edit();
	}
	
	/**
	 * 删除数据
	 *
	 * @return unknown
	 */
	public function Del(){
		$this->Clear();
		return  $this->_infoModel->Del();
	}
	
	/**
	 * 计算总数
	 *
	 * @return unknown
	 */
	public function Count(){
		return  $this->_infoModel->Count();
	}
	
	/**
	 * 获取列表
	 *
	 * @return unknown
	 */
	public function Get(){
		return  $this->_infoModel->Get();
	}
	
	/**
	 * 清除缓存
	 *
	 */
	public function Clear(){
		$this->_infoModel->Clear();
	}
	/**
	 * 过滤返回的的列表
	 *
	 * @return unknown
	 */
	public function FliterList(){
		$list=$this->Get();
		$temp=array();
		
		foreach ($list as $k=>$v){
			if ($this->_infoModel->getT()>=$v['startDate']&&$this->_infoModel->getT()<=$v['endDate']){
				$temp[]=$v;
			}
		}
		return $temp;
	}
}