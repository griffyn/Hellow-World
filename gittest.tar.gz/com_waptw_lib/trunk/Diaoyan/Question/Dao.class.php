<?php
/**
 * 调研问题数据层
 * 
 * @package	Waptw_Diaoyan
 * @author	mayong
 * @version 20100603
 *
 */
abstract class Waptw_Diaoyan_Question_Dao {
	public function __construct() {;}
	
	/**
	 * 获取数据表名称
	 * @return string
	 */
	protected function getTable(){
		return 'diaoyan_question';
	}
	
	/**
	 * 获取表字段列表，用半角逗号分隔
	 * @return string
	 */
	protected function getField(){
		return 'idx,diaoyanId,title,descript,orderNum,insertDate';
	}
	
	/**
	 * 插入数据
	 * @param array $data 插入的数据
	 * @return int 返回受last_insert_id
	 */
	protected function _insert(array $data){
		$db = Ucweb_Db_Adapter::factory('com_waptw_business');
		$db->T($this->getTable())->pk('idx');
		$result = $db->UcAdd($data);
		return $result;
	}
	
	/**
	 * 删除数据
	 * @param array $target 删除的条件
	 * @example $target['where'] = 'idx = ?'
	 * @return NULL
	 */
	protected function _del(array $target){
		$db = Ucweb_Db_Adapter::factory('com_waptw_business');
		$db->T($this->getTable())->pk('idx');
		if ($target['where']) {$db->where($target['where']);}
		$result = $db->UcDelete();
		return $result;
	}
	
	/**
	 * 修改数据
	 * @param array $target 修改对象的约束条件
	 * @param array $data 修改对象的数据
	 * @return NULL
	 */
	protected function _edit(array $data ,array $target){
		$db = Ucweb_Db_Adapter::factory('com_waptw_business');
		$db->T($this->getTable())->pk('idx');
		if ($target['where']) { $db->where($target['where']); }
		$result = $db->UcSave($data);
		return $result;
	}
	
	/**
	 * 统计数据综合
	 * @param array $target 统计数据的约束条件
	 * @return int 
	 */
	protected function _count(array $target){
		$db = Ucweb_Db_Adapter::factory('com_waptw_business');
		$db->T($this->getTable())->pk('idx')->field("count(*) as count");
		if ($target['where']) {$db->where($target['where']);}
		$result = $db->findAll();
		//print $db->getLastSql();
		return $result;
	}
	
	/**
	 * 根据约束条件获取数据
	 * @param array $target 约束条件
	 * @return array 多维数组
	 */
	protected function _get(array $target){
		$db = Ucweb_Db_Adapter::factory('com_waptw_business');
		$db->T($this->getTable())->pk('idx')->field($this->getField());
		if ($target['where']) {$db->where($target['where']);}
		if ($target['order']) {$db->order($target['order']);}
		if ($target['page']) {$db->page($target['page']);}
		if ($target['size']) {$db->size($target['size']);}
		
		$result = $db->findAll();
		return $result;
	}
	
}