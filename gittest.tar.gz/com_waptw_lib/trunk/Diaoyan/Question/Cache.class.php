<?php
/**
 * 调研问题缓存层
 *
 * @package	Diaoyan
 * @author	mayong
 * @version 20100603
 *
 */
abstract class Waptw_Diaoyan_Question_Cache extends Waptw_Diaoyan_Question_Dao {
	/**
	 * 初始化
	 *
	 * @param unknown_type $option
	 */
	public function __construct() { parent::__construct(); }

	/**
	 * 添加数据
	 *
	 * @return unknown
	 */
	protected function _insert(array $data){
		if(!$data) {throw new Waptw_Diaoyan_Question_Exception(__METHOD__.' => target error'. explode(',',$data));}
		$idx = parent::_insert($data);
		return $idx;
	}

	/**
	 * 删除数据
	 *
	 * @return unknown
	 */
	protected function _del(array $target){
		if(!$target) {throw new Waptw_Diaoyan_Question_Exception(__METHOD__.' => target error'. explode(',',$target));}
		$result = parent::_del($target);
		return $result;
	}

	/**
	 * 修改数据
	 *
	 * @return unknown
	 */
	protected function _edit(array $data, array $target){
		if(!$data) {throw new Waptw_Diaoyan_Question_Exception(__METHOD__.' => data error'. explode(',',$data));}
		if(!$target) {throw new Waptw_Diaoyan_Question_Exception(__METHOD__.' => target error'. explode(',',$target));}
		$result = parent::_edit($data ,$target);
		return $result;
	}

	/**
	 * 获取列表
	 *
	 * @return unknown
	 */
	protected function _get(array $target){
		if(!$target) {throw new Waptw_Diaoyan_Question_Exception(__METHOD__.' => target error'. explode(',',$target));}
		$key = Ucweb_Cache_Key::Get(parent::getTable(), array(__FUNCTIN___,$target));
		if ( $target['cache'] && is_array($result = Ucweb_Cache_Adapter::Get($key))) {
			return $result;
		}

		$result = parent::_get($target);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 计算总数
	 *
	 * @return unknown
	 */
	protected function _count(array $target){
		if(!$target) {throw new Waptw_Diaoyan_Question_Exception(__METHOD__.' => target error'. explode(',',$target));}
		$key = Ucweb_Cache_Key::Get(parent::getTable(), array(__FUNCTIN___,$target));
		if ( $target['cache'] && is_array($result = Ucweb_Cache_Adapter::Get($key))) {
			return $result;
		}
	
		$result = parent::_count($target);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
	
	/**
	 * 清除缓存
	 *
	 * @return unknown
	 */
	protected function _clear(){
		Ucweb_Cache_Key::Update(parent::getTable());
	}

}
