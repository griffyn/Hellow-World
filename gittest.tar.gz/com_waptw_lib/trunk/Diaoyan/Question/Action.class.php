<?php
/**
 * 调研问题动作层
 * 
 * @package	Diaoyan
 * @author	mayong
 * @version 20100603
 *
 */
class Waptw_Diaoyan_question_Action {
	private $_questionModel;
	
	/**
	 * 初始化
	 *
	 * @param unknown_type $option
	 */
	public function __construct($option = array()){
		$this->_questionModel = new Waptw_Diaoyan_Question_Model();

		$this->_questionModel->setIdx(Ucweb_Http_Input::GetByInt('id',0));
		$this->_questionModel->setDiaoyanId(Ucweb_Http_Input::GetByInt('diaoyanid',0));
		$this->_questionModel->setTitle(Ucweb_Http_Input::Admin('title'));
		$this->_questionModel->setType(Ucweb_Http_Input::GetByInt('type',1));
		$this->_questionModel->setOrderNum(Ucweb_Http_Input::GetByInt('orderNum',0));
		$this->_questionModel->setInsertDate(Ucweb_Http_Input::GetByInt('insertDate',0));
		
		$this->_questionModel->setAction(Ucweb_Http_Input::GetByString('action','list'));
		$this->_questionModel->setKeyword(Ucweb_Http_Input::GetByString('keyword',''));
		$this->_questionModel->setPage(Ucweb_Http_Input::GetByInt('page',1));
		$this->_questionModel->setSize(Ucweb_Http_Input::GetByInt('size',10));
		$this->_questionModel->setOrder(Ucweb_Http_Input::GetByString('order',''));
		$this->_questionModel->setCache(Ucweb_Http_Input::GetByInt('cache',0));
		$this->_questionModel->setField(Ucweb_Http_Input::GetByString('field',''));
		
		if(array_key_exists('id',$option)){ $this->_questionModel->setIdx($option['id']);}
		if(array_key_exists('title',$option)){ $this->_questionModel->setTitle($option['title']);}
		if(array_key_exists('diaoyanid',$option)){ $this->_questionModel->setDiaoyanId($option['diaoyanid']);}
		if(array_key_exists('type',$option)){ $this->_questionModel->setType($option['type']);}
		if(array_key_exists('orderNum',$option)){ $this->_questionModel->setOrderNum($option['orderNum']);}
		if(array_key_exists('insertDate',$option)){ $this->_questionModel->setInsertDate($option['insertDate']);}
		
		if(array_key_exists('action',$option)){ $this->_questionModel->setAction($option['action']);}
		if(array_key_exists('keyword',$option)){ $this->_questionModel->setKeyword($option['keyword']);}
		if(array_key_exists('page',$option)){ $this->_questionModel->setPage($option['page']);}
		if(array_key_exists('size',$option)){ $this->_questionModel->setSize($option['size']);}
		if(array_key_exists('order',$option)){ $this->_questionModel->setOrder($option['order']);}
		if(array_key_exists('cache',$option)){ $this->_questionModel->setCache($option['cache']);}
		if(array_key_exists('field',$option)){ $this->_questionModel->setField($option['field']);}
		
	}
	
	/**
	 * 返回模型
	 *
	 * @return unknown
	 */
	public function GetModel(){
		$this->Clear();
		return  $this->_questionModel;
	}
	
	/**
	 * 添加数据
	 *
	 * @return unknown
	 */
	public function Insert(){
		$this->Clear();
		return  $this->_questionModel->Insert();
	}
	
	/**
	 * 修改数据
	 *
	 * @return unknown
	 */
	public function Edit(){
		$this->Clear();
		return  $this->_questionModel->Edit();
	}
	
	/**
	 * 删除数据
	 *
	 * @return unknown
	 */
	public function Del(){
		return  $this->_questionModel->Del();
	}
	
	/**
	 * 计算总数
	 *
	 * @return unknown
	 */
	public function Count(){
		return  $this->_questionModel->Count();
	}
	
	/**
	 * 获取列表
	 *
	 * @return unknown
	 */
	public function Get(){
		return  $this->_questionModel->Get();
	}
	
	/**
	 * 清除缓存
	 *
	 */
	public function Clear(){
		$this->_questionModel->Clear();
	}
}