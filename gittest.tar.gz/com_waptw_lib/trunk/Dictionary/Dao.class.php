<?php
/**
 * 账号数据类
 * 使用方式是，先 Waptw_Account_Dao::Instance()初始化父类的表名和字段属性
 * Waptw_Account_Dao:Add 之类方法
 *
 */
class Waptw_Dictionary_Dao extends Waptw_Abstract_Dao {
	/**
	 * 获取数据库表名字
	 *
	 * @return unknown
	 */
	protected function getTable(){
		return 'dictionary';
	}
	
	protected function getField(){
		return 'idx,root,isDel,orderNum,insertDate,title';
	}
	
	public static function Instance(){
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	

	public static function GetByIdx($idx ,$where = FALSE){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$db->T(self::$_table)->pk("idx");
		if ($where) $db->where('isDel = 0');
		$result=$db->where("idx = $idx")->findAll();
		return $result;
	}

	public static function GetByTitle($title ,$root = 0){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$result=$db->T(self::$_table)->pk("idx")->where("root = $root and title = '$title'")->findAll();
		return $result;
	}
	
	public static function GetByRoot($root ,$page=1 ,$size=20,$order=''){
		$db = Ucweb_Db_Adapter::factory('com_waptw_down');
		$db->T(self::$_table)->pk("idx")->field(self::$_field);
		$db->page($page)->size($size);
		if($order) $db->order($order);
		$result=$db->where("root = ".$root." and isDel=0")->findAll();
		return $result;
	}
}