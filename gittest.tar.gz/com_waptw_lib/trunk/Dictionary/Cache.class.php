<?php
/**
 * 账号数据类
 * 使用方式是，先 Waptw_Account_Dao::Instance()初始化父类的表名和字段属性
 * Waptw_Account_Dao:Add 之类方法
 *
 */
class Waptw_Dictionary_Cache extends  Waptw_Dictionary_Dao {
	public static function GetByIdx($idx ,$cache = TRUE){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array(__CLASS__,__FUNCTION__,$idx));
		if($cache && $result = Ucweb_Cache_Adapter::Get($key)){return $result;}
		
		Waptw_Dictionary_Dao::Instance();
		$result = Waptw_Dictionary_Dao::GetByIdx($idx);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}

	public static function GetByRoot($root ,$page=1 ,$size=20 ,$cache = TRUE){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array(__CLASS__,__FUNCTION__,$root,$page,$size));
		if($cache && $result = Ucweb_Cache_Adapter::Get($key)){return $result;}
		
		Waptw_Dictionary_Dao::Instance();
		$result = Waptw_Dictionary_Dao::GetByRoot($root ,$page ,$size);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
        public static function GetByTitle($title ,$root = 0,$cache = TRUE){
		$key = Ucweb_Cache_Key::Get(parent::getTable(),array(__CLASS__,__FUNCTION__,$title ,$root));
		if($cache && $result = Ucweb_Cache_Adapter::Get($key)){return $result;}

		Waptw_Dictionary_Dao::Instance();
		$result = parent::GetByTitle($title ,$root);
		Ucweb_Cache_Adapter::Set($key,$result);
		return $result;
	}
}