<?php
/**
 ** 字典类
 * @package Dictionary
 * @author fuqiang
 * 2010.11.30
 *
 */
class Waptw_Dictionary_Model extends Waptw_Dictionary_Cache {

    public $page = 1;	//页码
    public $size = 20;	//每页的数据行数
    public $order = 'idx desc';

    public static function GetByTitle($title ,$root = 0,$cache = TRUE) {
        $result = parent::GetByTitle($title ,$root,$cache);
        return $result;
    }

}