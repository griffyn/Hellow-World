<?php
/**
 * 字典类
 * @package Dictionary
 * @author fuqiang
 * 2010.11.30
 *
 */
class Waptw_Dictionary_Action
{
   	private $_DicModel;


	public function __construct($option='') {
		$this->_DicModel = new Waptw_Dictionary_Model();
		$this->_DicModel->page = ($option['page'])?$option['page']:Ucweb_Http_Input::GetByInt('page',1);
		$this->_DicModel->size = ($option['size'])?$option['size']:Ucweb_Http_Input::GetByInt('size',10);
		$this->_DicModel->order = ($option['order'])?$option['order']:Ucweb_Http_Input::GetByString('order','idx desc');;
		$this->_DicModel->where = $option['where'];
		$this->_DicModel->field = $option['field'];
		$this->_DicModel->idx = ($option['idx'])?$option['idx']:Ucweb_Http_Input::GetByInt('idx','');
	}

	/**
	 * 获取列表内容
	 *
	 * @param array $option
	 * @param cache开关 $cache
	 * @return 列表结果 array
	 */
	public function Get() {

		return $this->_DicModel->Get();

	}

	/**
	 * 获取总条数
	 *
	 * @param 条件 string $where
	 * @param cache开关 $cache
	 * @return int 总数
	 */
	public function Count() {
		return $this->_DicModel->Count();
	}
        /**
	 * 获取总条数
	 *
	 * @param 条件 string $where
	 * @param cache开关 $cache
	 * @return int 总数
	 */
	public static  function GetByTitle($title ,$root = 0,$cache = TRUE){
		return Waptw_Dictionary_Model::GetByTitle($title ,$root,$cache);
	}
}
