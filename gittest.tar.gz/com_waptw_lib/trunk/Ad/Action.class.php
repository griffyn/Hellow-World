<?php
/**
 * 广告方法类
 * @package ad
 * @author mayong@ucweb.cn
 *
 */
class Waptw_Ad_Action  
{
	/**
	 * 获取所有广告
	 * 
	 * @return array
	 */
	public static function GetAll()
	{
		$where='isDel=0';
		$option=Waptw_Ad_Dao::GetList('isDel=0 and isLine=1');
		return $option;
	}
	
	/**
	 * 获取广告与厂商的交集列表
	 *
	 * @param  所有广告信息 array $option1
	 * @param  所有广告厂商信息 array $option2
	 * @return array
	 */
	static public function GetListByMix($option1,$option2) 
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$temp[$val['idx']] = $val['title'];
		}
		foreach ($option1 as $key => $val) {
			$option1[$key]['customerTitle'] = $temp[$val['customerId']];
		}
		return $option1;
	}
	
	/**
	 * 根据广告块和机型信息获取广告
	 *
	 * @param int $pos
	 * @param int $eid
	 * @param bool $cache
	 */
	static public function GetAds($pos,$eid=0,$cache=true) 
	{
		$result2=Waptw_Ad_Position_Cache::GetAdsByPos($pos,$cache);
		$result=self::getAdPosOnLine($result2);
		
		if ($eid) 
		{
			$devPlatform = new Mobile_Devplatform_Action();
			$pid=$devPlatform->GetByEid($eid,$cache);
			if(!$pid) $pid = 68;
		}
		foreach ($result as $k=>$v) 
		{
			$ad=Waptw_Ad_Cache::Get($v['adId'],$cache);
			if ($ad['url']=='' and $eid) 
			{
				$suitPack=Software_Soft_Cache::GetByIdxPlatformId($ad['packId'],$pid,$cache);
			}
			if ($v['isStick']) 
			{
				if ($suitPack||$ad['url']||!$eid)
				{
					$stick[$v['line']][]=$v['adId'];
				}			
			}
			else 
			{
				if ($suitPack||$ad['url']||!$eid)
				{
					$line[$v['line']][]=$v['adId'];
				}
			}
		}
		
		$resultLine=array();
		$stickLine=array();
		$commonLine=array();
		$block=array();
		$block=Waptw_Ad_Block_Cache::Get($pos,$cache);
		if (!$block['isImg']) 
		{

			if ($stick) {
				foreach ($stick as $v) {
						$stickLine[]=self::getBestCombine($v);					
				}
			}
			
			if($line) {
				foreach ($line as $k=>$v) {
							$commonLine[]=self::getBestCombine($v);		
							
				}
			}
		}
		else 
		{
			if ($stick) {
				foreach ($stick as $v) {
						$stickLine[]=self::getImgLine($v);					
				}
			}
			if($line) {
				foreach ($line as $k=>$v) {
							$commonLine[]=self::getImgLine($v);		
							
				}
			}
		}
		
		$row=$block['rows'];
		
		
		shuffle($commonLine);
		
		$resultLine=array_merge($stickLine,$commonLine);
		if (count($resultLine)>$row) 
		{
			$result=array_slice($resultLine,0,$row);
		}
		else
		{
			$result=$resultLine;
		}
		
		return $result;
		
	}
	
	static public function getBestCombine($line) 
	{
		foreach ($line as $k=>$v) 
		{
			$titles=Waptw_Ad_Cache::Get($v);
			
			$result[]=explode(",",$titles['titles']);
		}
		
		$result2=self::SpellWord(count($result),$result);
		
		$countFirst=self::CountWord($v);
		$firstAbs=abs($countFirst-24);
		$first=$countFirst-24;
		$bestCombine=$result2[0];
		
		foreach ($result2 as $k=>$v)
		{
			$count=self::CountWord($v);
			
			$distinceAbs=abs($count-22);
			$distince=$count-22;
			if ($count==22) 
			{
				$bestCombine=$v;
				break;
			}
			elseif ($distinceAbs<$firstAbs and $distince<0)
			{
				$firstAbs=$distinceAbs;
				$bestCombine=$v;
			}
		}
			

		$resultLine=explode('|',$bestCombine);
		unset($complie);
		foreach ($resultLine as $k=>$v)
		{
			$complie[]=array($line[$k]=>$v);
		}
		return $complie;
	}
	
	/**
	 * 拼接广告词
	 *
	 * @param int $count
	 * @param array $ads
	 */
	static public function SpellWord($count,$ads) 
	{
		if ($count>2) 
		{
			return self::CombineWord(self::SpellWord($count-1,$ads),$ads[$count-1]);
		}
		elseif ($count==2)
		{
			return self::CombineWord($ads[0],$ads[1]);
		}
		else 
		{
			return $ads[0];
		}
		
		
	}
	
	/**
	 * 组合两个广告标题数组，得到最小的组合
	 *
	 * @param array $option1
	 * @param array $option2
	 * @return array $option3
	 */
	static public function CombineWord($option1,$option2) 
	{
		foreach ($option1 as $k1=>$v1)
		{
			foreach ($option2 as $k2=>$v2)
			{
				$option3[]=$v1.'|'.$v2;
			}
		}
		return $option3;
	}
	
	/**
	 * 计算汉字的数目
	 *
	 * @param varchar $titles
	 * @return int 
	 */
	static public function CountWord($titles) 
	{
		//$len=strlen(iconv(  "gb2324","UTF-8", $titles2));
		$len=mb_strlen(''.$titles.'','gb2312');
		return $len;
	}
	
	/**
	 * 获取图片列表
	 *
	 * @param array $line
	 */
	static public function getImgLine($line) 
	{
		foreach ($line as $k=>$v) 
		{
			$imgs=Waptw_Ad_Cache::Get($v);
			$ad=array();
			$ad[]=explode(",",$imgs['adPic']);
			shuffle($ad[0]);
			$complie[]=$ad[0][0];
		}
		
		foreach ($complie as $k=>$v)
		{
			$result[]=array($line[$k]=>$v);
		}
		return $result;
	}
	
	/**
	 * 过滤下线广告
	 *
	 * @param array $line
	 */
	static public function getAdPosOnLine($pos) 
	{
		$tmp=array();
		$ad=array();
		foreach ($pos as $k=>$v)
		{
			$ad=Waptw_Ad_Cache::Get($v['adId']);
			if ($ad['isLine']) 
			{
				$tmp[]=$v;	
			}
		}
		return $tmp;
	}
	
	/**
	 *获取在
	 *
	 * @param int $blockId
	 * @return $adIdArray
	 */
	static public function getAdIdsByBlock($blockId) 
	{
		Waptw_Ad_Position_Dao::Instance();
		$where='isDel=0 and pos='.$blockId;
		$adPositionArray=Waptw_Ad_Position_Dao::Get(1,Waptw_Ad_Position_Dao::Count($where),'',$where);
		$adIdArray=array();
		foreach ($adPositionArray as $k=>$v) 
		{
			$adIdArray[]=$v['adId'];
		}
		return $adIdArray;
	}
}