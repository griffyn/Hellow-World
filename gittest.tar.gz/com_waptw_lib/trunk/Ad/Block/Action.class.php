<?php
/**
 * 广告块方法类
 * @package adBlock
 * @author mayong
 *
 */
class Waptw_Ad_Block_Action  
{
	/**
	 * 获取所有投放块
	 * 
	 * @return array
	 */
//	public static function GetAll()
//	{
//		$where='isDel=0';
//		Waptw_Ad_Block_Dao::Instance();
//		$option=Waptw_Ad_Block_Dao::Get(1,$where,'orderNum asc',$where);
//		return $option;
//	}
	
	/**
	 * 获取所有广告块idx和title列表字符串
	 * 
	 * @param array $allBlock
	 * @return varchar
	 */
	public static function getIdxTitleMixList($allBlock)
	{
		$temp=array();
		foreach ($allBlock as $k=>$v) 
		{
			$temp[]=$v['idx'].'`'.$v['title'];
		}
		return join('^',$temp);
	}
	
	/**
	 * 获取所有广告块的idx,title与title组合数组
	 *
	 * @param array $allBlock
	 * @return array
	 */
	public static function getIdxTitleMixOption($allBlock)
	{
		$temp=array();
		foreach ($allBlock as $k=>$v) 
		{
			$temp[$v['idx'].'`'.$v['title']]=$v['title'];
		}
		return $temp;
	}
}