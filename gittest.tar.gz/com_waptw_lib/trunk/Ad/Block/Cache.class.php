<?php
/**
 * 广告块缓存类
 * @package adBlock
 * @author mayong
 *
 */
class Waptw_Ad_Block_Cache extends Waptw_Ad_Block_Dao   {
	
	/**
	 * 根据编号获取广告块信息
	 *
	 * @param int $idx
	 * @param bool $cache
	 * @return array
	 */
	static public function Get($idx,$cache=true) {
		$key=Ucweb_Cache_Key::Get(parent::getTable(),array('Get',$idx));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$result=Waptw_Ad_Block_Dao::GetById($idx);
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	static public function GetAds($pos,$eid=0,$cache=true) {
		$rand=rand(1,2);
		$key=Ucweb_Cache_Key::Get(parent::getTable(),array('GetAds',$pos,$eid,$rand));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$result=Waptw_Ad_Action::GetAds($pos,$eid,$cache);
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
	
}