<?php
/**
 * 广告类缓存
 * @package ad
 * @author mayong
 *
 */
class Waptw_Ad_Cache extends Waptw_Ad_Dao  {
	
	/**
	 * 根据编号获取广告
	 *
	 * @param int $adId
	 * @param bool $cache
	 * @return array
	 */
	static public function Get($adId,$cache=true) {
		$key=Ucweb_Cache_Key::Get(parent::getTable(),$adId);
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$result=Waptw_Ad_Dao::GetById($adId);
			if(!is_array($result)) {
				$result=array();
			}
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	
	/**
	 * 更新缓存
	 */
	
	static public function Update() {
		Ucweb_Cache_Key::Update(parent::getTable());
		
	}

	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
	
}