<?php
/**
 * 广告模块类
 * @package adPosition
 * @author mayong
 *
 */
class Waptw_Ad_Position_Dao  extends  Waptw_Ad_Abstract_Dao 
{
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	private function getTable()
	{
		return 'adPosition';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	protected function getField()
	{
		return 'idx,adId,pos,line,isStick,isDel,insertDate';
	}
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 根据主键返回记录
	 * 
	 * @param int $idx
	 * @return array
	 */
	public static function GetById($idx)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result = $db->T(self::getTable())->field(self::getField())->pk("idx")->where('isDel = 0')->getbyidx($idx);
		return $result;
	}
	
	/**
	 * 记录逻辑删除
	 *
	 * @param int $id
	 * @return 成功返回TRUE,否者返回FALSE
	 */
	public static function LogicDel($where,$option)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result = $db->T(self::$_table)->where($where)->UcSave($option);
		return $result;
	}
	
	/**
	 * 修改数据
	 *
	 * @param int $idx 单个idx
	 * @param array $option 修改的数据
	 * 成功返回TRUE,否者返回FALSE
	 */
	public static function Edit($where ,array $option){
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result = $db->T(self::$_table)->where($where)->UcSave($option);
		return $result;
	}
	
	
}
