<?php
/**
 * 广告投放方法类
 * @package adPosition
 * @author mayong
 *
 */
class Waptw_Ad_Position_Action
{
	/**
	 * 获取指定广告的所有投放信息
	 *
	 * @param  int $adId
	 * @return array
	 */
	static public function GetPositionListByAdId($adId) 
	{
		$where=($adId==0)?'isDel=0':'isDel=0 and adId='.$adId;	
		Waptw_Ad_Position_Dao::Instance();
		return Waptw_Ad_Position_Dao::Get(1,Waptw_Ad_Position_Dao::Count($where),'',$where);
	}
	
	/**
	 * 获取所有投放信息与广告信息的组合数组
	 *
	 * @param   array $option1
	 * @param   array $option2
	 * @return array
	 */
	static public function getPositionAdMixOption($option1,$option2) 
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$temp[$val['idx']] = $val['title'];
		}
		foreach ($option1 as $key => $val) {
			$option1[$key]['adTitle'] = $temp[$val['adId']];
		}
		return $option1;
	}
	
	/**
	 * 获取所有投放信息中的广告置顶信息与广告块的信息的组合数组
	 *
	 * @param  array $option1
	 * @param  array $option2
	 * @return array
	 */
	static public function getPositionLineMixOption($option1,$option2) 
	{
		$temp = array();
		
		foreach ($option2 as $key => $val) {
			$temp[$val['idx']] = $val['title'];
		}
		foreach ($option1 as $key => $val) {
			$option1[$key]['blockTitle'] = $temp[$val['pos']];
		}
		foreach ($option1 as $k=>$v) 
		{
			if ($v['isStick']) 
			{
				$option1[$k]['stickTitle']='置顶';
			}
			else 
			{
				$option1[$k]['stickTitle']='普通';
			}
		}
		return $option1;
	}
	
	/**
	 * 获取广告块与广告行的对应关系
	 *
	 * @param  array $option
	 * @return varchar
	 */
	static public function getBlockLineRelation($option) 
	{
		$temp=array();
		foreach ($option as $k=>$v) 
		{
			$temp[$v['pos'].'`'.$v['blockTitle'].'`'.$v['line']][]=$v['adTitle'];
		}
		$temp2=array();
		foreach ($temp as $k=>$v) 
		{
			$temp3=explode('`',$k);
			$temp2[$k]=$temp3[0].'`'.$temp3[1].'~'.$k.'`'.join('|',$temp[$k]);
		}
		return join('^',$temp2);
	}
	
	/**
	 * 获取广告行与置顶的对应关系
	 *
	 * @param  array $option1
	 * @param  array $option2
	 * @return varchar
	 */
	static public function getLineStickRelation($option1,$option2) 
	{
		$temp=explode('^',$option1);
		$temp4=array();
		foreach ($temp as $k=>$v) 
		{
			$temp2=explode('~',$v);
			$temp3=explode('`',$temp2[1]);
			foreach ($option2 as $k2=>$v2) 
			{
				if ($v2['pos']==$temp3[0] and $v2['line']==$temp3[2]) 
				{
					$temp4[]=$temp2[1].'~'.$temp2[1].'`'.$v2['isStick'].'`'.$v2['stickTitle'];
					break;
				}
			}
		}
		return join('^',$temp4);
	}
	
	/**
	 * 获取所有投放行信息
	 *
	 * @param  varchar $option
	 * @return array
	 */
	static public function getMenu2List($option) 
	{
		$temp=explode('^',$option);
		$temp2=array();
		foreach ($temp as $k=>$v) 
		{
			$temp3=explode('~',$v);
			$temp4=explode('`',$temp3[1]);
			$temp2[$temp3[1]]['preValue']=$temp3[0];
			$temp2[$temp3[1]]['localTitle']=$temp4[3];
		}
		return $temp2;
	}
	
	/**
	 *  获取所有置顶信息
	 *
	 * @param  varchar $option
	 * @return array
	 */
	static public function getMenu3List($option) 
	{
		$temp=explode('^',$option);
		$temp2=array();
		foreach ($temp as $k=>$v) 
		{
			$temp3=explode('~',$v);
			$temp4=explode('`',$temp3[1]);
			$temp2[$temp3[1]]['preValue']=$temp3[0];
			$temp2[$temp3[1]]['localTitle']=$temp4[5];
		}
		return $temp2;
	}
	
	
	/**
	 * 获取已经投放广告的投放行信息
	 * @param  某广告的广告行与广告置顶信息的对应关系字符串 varchar $option
	 * @param  所有广告行与广告置顶信息的对应关系字符串 varchar $option
	 * @return array
	 *
	 */
	static public function getMenu($option1,$option2) 
	{
		$temp=explode('^',$option1);
		$temp7=array();
		$i=0;
		foreach ($temp as $k=>$v)
		{
			$temp2=explode('~',$v);
			$temp3=explode('`',$temp2[1]);
			$temp4=explode('^',$option2);
			
			foreach ($temp4 as $k2=>$v2) 
			{
				$temp5=explode('~',$v2);
				$temp6=explode('`',$temp5[1]);
				if ($temp3[0]==$temp6[0] and $temp3[2]==$temp6[2]) 
				{
					$temp7[$i]['menu_1_value']=$temp3[0].'`'.$temp3[1];
					$temp7[$i]['menu_2_value']=$temp5[0];
					$temp7[$i]['menu_3_value']=$temp5[1];
					$i=$i+1;
				}
			}
		}
		return $temp7;
	}
	
	/**
	 * 获取指定广告位的每行广告
	 *
	 * @param 广告位置 int $pos
	 * @param 机型id  int $eid
	 * @param 缺省为soft string $type
	 * @return array
	 */
	static public function GetAd($pos,$eid='') {
		$result=Waptw_Ad_Position_Dao::GetListByPos($pos);
		foreach ($result as $k=>$v) {
			if ($eid) {
				$devPlatform = new Mobile_Devplatform_Action();
				$pid= new $devPlatform->GetIdx($eid);
				$pid=str_ireplace('_',',',$pid);
			}
			$productId=Waptw_Ad_Dao::GetById($v['adId']);
			if ($productId['col']<0) {
				$pack=Software_Game_Dao::GetByPackId($productId['packId'],$pid,'1');
			}
			if ($productId['col']>0) {
				$pack=Software_Soft_Dao::GetByPackId($productId['packId'],$pid,'1');
			}
			
			if ($v['isStick']==1) {
				if ($pack||$productId['url']||!$eid)
					$stick[$v['line']][]=$v['adId'];					
			} else {
				
				if ($pack||$productId['url']||!$eid)
					$line[$v['line']][]=$v['adId'];
					
			}
			++$i;			
		}
		if ($stick) {
			foreach ($stick as $v) {
				
				if (self::getline($v)) {
					$resultLine[]=self::getline($v);					
				}
			}
		}
		if($line) {
			foreach ($line as $v) {
				if (self::getline($v)) {
					$resultLine[]=self::getline($v);					
				}
			}
		}
		
		$row=Waptw_Ad_Block_Dao::GetById($pos);
		$row=$row['rows'];		
		if (count($resultLine)>$row) {
			if (is_array($resultLine)&&$row) {
				$array_rand=array_rand($resultLine,$row);
				foreach ($array_rand as $v) {
					$resultarray[]=$resultLine[$v];
				}
			}
		} else {
			$resultarray=$resultLine;
		}
		
		return $resultarray;
	}
	
	/**
	 * 获取行拼接后的广告内容
	 *
	 * @param array $option
	 * @return array
	 */
	
	static private function getline(array $option) {
		
	if (is_array($option)) {
		foreach ($option as $v) {
			$titles=Waptw_Ad_Dao::GetById($v);
			$result[]=explode(",",$titles['titles']);
		}
		switch (count($option)) {
			case 1:
				$contents=self::arr1($result[0]);
				break;
			case 2:
				$contents=self::arr2($result[0],$result[1]);
				break;
			case 3:
				$contents=self::arr3($result[0],$result[1],$result[2]);
				break;
		}
			$contents=explode('|',$contents);
		unset($complie);
		foreach ($contents as $k=>$v) {
			if ($v) {
				$complie[]=array($option[$k]=>$v);
			}	
		}
		
	} else {
		$titles=Waptw_Ad_Dao::GetById($option);
		$complete=self::arr1($titles['titles']);
		if ($titles['url']) {
			$complie[]=array($option[$k]=>$v);
		}
		
	}
		$merge=count($complie);
		switch ($merge){
			case 1:
				$complie=$complie[0];
				break;
			case 2:
				$complie=$complie[0]+$complie[1];				
				break;
			case 3:
				$complie=$complie[0]+$complie[1]+$complie[2];
				break;
		}
		return $complie;
	}

	static private function arr1($op) {
		$l=99;
		foreach ($op as $v){
			++$i;
			$len=strlen(iconv( "UTF-8", "gb2312" , $v));
			if ($i==1) {
				$r=$v;		
			}
			if ($len==25||$len==24) {	
				$r=$v;
				break 1;
			} else {
				$k=25-$len;
				if ($k<$l&&$k>0) {
					$r=$v;
					$l=$k;
				}
			}
			$last=$v;
		}
		return $r;
	}


	static private function arr2($op1,$op2) {
		$l=99;
		
		foreach ($op1 as $k1=>$v1) {		
			foreach ($op2 as $k2=>$v2) {
				++$i;
				$len=strlen(iconv( "UTF-8", "gb2312" , $v1.'|'.$v2));
				if ($i==1) {
					$r=$v1.'|'.$v2;		
				}
				if ($len==25||$len==24) {				
					$r=$v1.'|'.$v2;
					break 2;
				} else {
					$k=25-$len;
					if ($k<$l&&$k>0) {
						$r=$v1.'|'.$v2;
						$l=$k;
					}
					//echo $v1.'|'.$v2."<br/>";
				}
				$last=$v1.'|'.$v2;
			}		
		}
		return $r;
	}



	static private function arr3($op1,$op2,$op3) {
		$l=99;
		foreach ($op1 as $k1=>$v1) {	
			foreach ($op2 as $k2=>$v2) {		
				foreach ($op3 as $k3=>$v3) {
					++$i;
					$len=strlen(iconv( "UTF-8", "gb2312" , $v1.'|'.$v2.'|'.$v3));
					if ($i==1) {
						$r=$v1.'|'.$v2.'|'.$v3;		
					}
					if ($len==25||$len==24) {
						
						$r=$v1.'|'.$v2.'|'.$v3;
						break 3;
					} else {
						$k=25-$len;
						if ($k<$l&&$k>0) {
							$r=$v1.'|'.$v2.'|'.$v3;
							$l=$k;
						}
						//echo $v1.'|'.$v2.$v3."<br/>";
					}
					
					$last=$v1.'|'.$v2.'|'.$v3;
				}			
			}	
		}
		return $r;
	}
	
	/**
	 * 获取广告位置适配机型后所有广告
	 *
	 * @param 广告位置 int $pos
	 * @param 机型id号 int $eid
	 */
	
	static public function GetAllAd($pos,$eid='',$size=5) {
		$result=Waptw_Ad_Position_Dao::GetListByPos($pos,$size);
		foreach ($result as $k=>$v) {
			if ($eid) {
				$devPlatform = new Mobile_Devplatform_Action();
				$pid=$devPlatform->GetIdx($eid);
				$pid=str_ireplace('_',',',$pid);
			}
			$productId=Waptw_Ad_Dao::GetById($v['adId']);
			
			if ($productId['col']<0) {
				$pack=Software_Game_Dao::GetByPackId($productId['packId'],$pid,'1');
			}
			if ($productId['col']>0) {
				$pack=Software_Soft_Dao::GetByPackId($productId['packId'],$pid,'1');
			}
			
			
			if ($pack||$productId['url']||!$eid) {
				$ad[]=array(
					'adId'=>$v['adId'],
					'title'=>$productId['title'],				
				);
			}
		}
		return $ad;		
	}
	
		/**
	 * 获取指定广告位的每行广告
	 *
	 * @param 广告位置 int $pos
	 * @param 机型id  int $eid
	 * @param 缺省为soft string $type
	 * @return array
	 */
	static public function GetImgAd($pos) {
		$result=Waptw_Ad_Position_Dao::GetListByPos($pos);
		$ad=Waptw_Ad_Dao::GetById($result[0]['adId']);
		$arr=explode(',',$ad[adPic]);
		foreach ($arr as $v){
			$option[]=array(
				'idx'=>$ad['idx'],
				'adPic'=>$v,
			);
		}
		return $option;
	}
}
