<?php
/**
 * 广告类缓存
 * @package Ad
 * @author xiangxs
 *
 */
class Waptw_Ad_Position_Cache extends Waptw_Ad_Dao  {
	
	static public function GetAd($pos,$eid='',$cache='true') {
		$key=Ucweb_Cache_Key::Get('ad-adposition',array($pos,$eid));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$result=Waptw_Ad_Position_Action::GetAd($pos,$eid);
			if(!is_array($result)) {
				$result=array();
			}
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	static public function GetImgAd($pos,$cache='true') {
		$key=Ucweb_Cache_Key::Get('ad-adposition',array($pos));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			$result=Waptw_Ad_Position_Action::GetImgAd($pos);
			if(!is_array($result)) {
				$result=array();
			}
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	
	static public function GetAllAd($pos,$eid='',$size=5,$cahe='true') {
		$key=Ucweb_Cache_Key::Get('ad',array($pos,$eid));
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			if(!is_array($result)) {
				$result=array();
			}
			$result=Waptw_Ad_Position_Action::GetAllAd($pos,$eid='',$size);
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	/**
	 * 获得某个广告块的所有广告
	 *
	 * @param int $pos
	 * @param bool $cache
	 * @return array
	 */
	
	static public function GetAdsByPos($pos,$cache='true') {
		$key=Ucweb_Cache_Key::Get(parent::getTable(),$pos);
		$result = Ucweb_Cache_Adapter::Get($key);
		if ($cache && is_array($result)) {
			return $result;
		} else {
			if(!is_array($result)) {
				$result=array();
			}
			$where='isDel=0 and pos='.$pos;
			Waptw_Ad_Position_Dao::Instance();
			$result=Waptw_Ad_Position_Dao::Get(1,Waptw_Ad_Position_Dao::Count($where),'',$where);
			Ucweb_Cache_Adapter::Set($key,$result);
			return $result;			
		}		
	}
	
	/**
	 * 更新缓存
	 */
	
	public static function UpdateCache()
	{
		Ucweb_Cache_Key::Update(parent::getTable());
	}
	
	/**
	 * 更新缓存
	 * yuwei
	 *
	 */
	static public function Update() {
		Ucweb_Cache_Key::Update(parent::getTable());
		
	}
	
	
}