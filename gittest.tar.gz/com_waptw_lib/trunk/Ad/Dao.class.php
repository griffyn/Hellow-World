<?php
/**
 * 广告类
 * @package ad
 * @author mayong
 *
 */
class Waptw_Ad_Dao  extends Waptw_Ad_Abstract_Dao
{
	/**
	 * 获取数据库表名字
	 *
	 * @return string
	 */
	protected  static function getTable()
	{
		return 'ad';
	}
	
	/**
	 * 获取Query字段
	 *
	 * @return string
	 */
	private static function getField()
	{
		return 'idx,packId,title,titles, col,productId,url,customerId, explainInfo,isLine,isDel,insertDate ,updateDate,lineTime,adPic';
	}
	
	
	/**
	 * 为父类属性赋值
	 *
	 */
	public static function Instance()
	{
		parent::$_table = self::getTable();
		parent::$_field = self::getField();
	}
	
	/**
	 * 根据主键返回记录
	 * 
	 * @param int $idx
	 * @return array
	 */
	public static function GetById($idx)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result = $db->T(self::getTable())->where("isDel=0")->pk("idx")->getbyidx($idx);
		return $result;
	}
	
	/**
	 * 记录逻辑删除
	 *
	 * @param int $id
	 * @return 成功返回TRUE,否者返回FALSE
	 */
	public static function LogicDel($idx)
	{
		return parent::Edit($idx,array('isDel'=>1));
	}
	
}
