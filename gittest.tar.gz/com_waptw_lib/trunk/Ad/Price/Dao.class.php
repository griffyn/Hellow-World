<?php
class Waptw_Ad_Price_Dao 
{
	static private function getTable()
	{
		return 'adPrice';
	}
	
	static private function getDelField()
	{
		return ' isDel=0 ';
	}
	
	static public function GetByAdId($adId)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result=$db->T(self::getTable())->pk("idx")->where("adId=".$adId." and ".self::getDelField())->findAll();
		return $result;
	}
	
	static public function Add(array $option)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$idx = $db->T(self::getTable())->pk("idx")->UcAdd($option);
	}
	
	static public function Del($adId)
	{
		$db = Ucweb_Db_Adapter::factory('com_waptw_ads');
		$result=$db->T(self::getTable())->where("adId=".$adId)->UcSave(array('isDel'=>1));
	}

}